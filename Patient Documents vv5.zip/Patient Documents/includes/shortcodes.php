<?php
add_shortcode('patient_documents', 'pd_patient_documents_shortcode');
function pd_patient_documents_shortcode($atts) {
    // Security check
    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        return '<div class="pd-error">Access denied. You must be a healthcare provider to view this content.</div>';
    }

    // Get shortcode attributes
    $atts = shortcode_atts([
        'patient_id' => 0,
        'show_header' => true
    ], $atts, 'patient_documents');

    $patient_id = (int) $atts['patient_id'];
    
    // Fallback to URL parameter if not set in shortcode
    if(!$patient_id && isset($_GET['patient_id'])) {
        $patient_id = (int) $_GET['patient_id'];
    }

    // Validate patient ID
    if(!$patient_id || !get_user_by('ID', $patient_id)) {
        return '<div class="pd-error">Invalid patient ID. Please specify a valid patient using: [patient_documents patient_id="123"]</div>';
    }

    // Add these before localizing the script
    $db = PD_Database::get_instance();
$patient_info = $db->get_patient_basic_info($patient_id);

    // Combine into single localization
    wp_localize_script('pd-script', 'pd_ajax', [
        'url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pd-nonce'),
        'patient_id' => $patient_id,
        'patient_name' => $patient_info->patient_name ?? '',
        'encounter_date' => $patient_info->encounter_date ? 
            date('F j, Y', strtotime($patient_info->encounter_date)) : '',
        'plugin_url' => PD_PLUGIN_URL // Add this for JS access
    ]);

    // Get patient data
    $db = PD_Database::get_instance();
    $data = $db->get_patient_data($patient_id);

    // Start output buffering
    ob_start();
    
    // Include template
    include PD_PLUGIN_PATH . 'includes/templates/patient-view.php';
    
    // Return captured output
    return ob_get_clean();
}

add_action('wp_ajax_save_clinical_notes', 'pd_save_clinical_notes');
function pd_save_clinical_notes() {
    check_ajax_referer('pd-nonce', 'nonce');
    
    $patient_id = (int) $_POST['patient_id'];
    $data = array_map('sanitize_textarea_field', $_POST['data']);
    
    $db = PD_Database::get_instance();
    $encounter = $db->get_encounter_details($patient_id);
    
    if($encounter && $encounter->id) {
        $result = $db->save_clinical_notes($encounter->id, $data);
        wp_send_json_success($result);
    }
    
    wp_send_json_error('No encounter found');
}

// Handle template loading
add_action('wp_ajax_load_template', 'pd_load_template');
function pd_load_template() {
    check_ajax_referer('pd-nonce', 'nonce');
    
    $template_id = (int) $_POST['template_id'];
    $db = PD_Database::get_instance();
    $template = $db->get_template($template_id);

    if($template) {
        wp_send_json_success([
            'content' => $template->content
        ]);
    }
    
    wp_send_json_error('Template not found');
}

// Handle template saving
add_action('wp_ajax_save_template', 'pd_save_template');
function pd_save_template() {
    check_ajax_referer('pd-nonce', 'nonce');
    
    if(!current_user_can('edit_posts')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $db = PD_Database::get_instance();
    $result = $db->save_template(
        sanitize_text_field($_POST['type']),
        sanitize_text_field($_POST['name']),
        wp_kses_post($_POST['content'])
    );

    if($result) {
        wp_send_json_success([
            'message' => 'Template saved successfully'
        ]);
    }
    
    wp_send_json_error('Template save failed');
}

// Add shortcode for frontend encounter list
add_shortcode('encounter_list', 'pd_encounter_list_shortcode');
function pd_encounter_list_shortcode($atts) {
    if(!current_user_can('manage_options')) {
        return '<div class="notice notice-error">You must be an administrator to view this content.</div>';
    }

    ob_start();
    ?>
    <div class="pd-encounter-list">
        <div class="encounter-filters">
            <select class="status-filter">
                <option value="all">All Statuses</option>
                <option value="upcoming">Upcoming</option>
                <option value="checked_in">Checked In</option>
                <option value="completed">Completed</option>
            </select>
            <button class="pd-filter-button">Filter</button>
        </div>
        
        <div class="encounter-list-content">
            <?php pd_render_encounter_list(); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Shared render function
function pd_render_encounter_list($status = 'all') {
    $db = PD_Database::get_instance();
    $encounters = $db->get_encounters($status);
    
    if(empty($encounters)) {
        echo '<p>No encounters found.</p>';
        return;
    }
    ?>
    <table class="pd-encounter-table">
        <thead>
            <tr>
                <th>Doctor</th>
                <th>Patient</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($encounters as $encounter) : ?>
            <tr>
                <td><?php echo esc_html($encounter->doctor_name); ?></td>
                <td><?php echo esc_html($encounter->patient_name); ?></td>
                <td><?php echo date_i18n('M j, Y H:i', strtotime($encounter->date)); ?></td>
                <td>
                    <span class="status-<?php echo esc_attr($encounter->status); ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $encounter->status)); ?>
                    </span>
                </td>
                <td class="actions">
    <a href="<?php echo admin_url('admin.php?page=patient-view&patient_id=' . $encounter->patient_id); ?>" 
       target="_blank"
       class="pd-action-button profile">
        <span class="dashicons dashicons-admin-users"></span>
    </a>
    <button class="pd-action-button view" 
            data-patient="<?php echo $encounter->patient_id; ?>">
        <span class="dashicons dashicons-visibility"></span>
    </button>
    <button class="pd-action-button bill" 
            data-appointment="<?php echo $encounter->appointment_id; ?>">
        <span class="dashicons dashicons-money-alt"></span>
    </button>
    <button class="pd-action-button delete" 
            data-id="<?php echo $encounter->appointment_id; ?>">
        <span class="dashicons dashicons-trash"></span>
    </button>
</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php
}


// Update the encounter_list_v2 shortcode
add_shortcode('encounter_list_v2', 'pd_encounter_list_shortcode_v2');
function pd_encounter_list_shortcode_v2($atts) {
    if (!current_user_can('edit_posts')) {
        return '<div class="error">Access denied</div>';
    }

    // Enqueue necessary scripts and styles
    wp_enqueue_style('pd-encounter-list');
    wp_enqueue_script('pd-encounter-list');
    
    // Add necessary data for JavaScript
    wp_localize_script('pd-encounter-list', 'pdEncounterData', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pd-encounter-nonce'),
        'printCss' => PD_PLUGIN_URL . 'assets/css/print.css'
    ]);

    $db = PD_Database::get_instance();
    $encounters = $db->get_encounters();

    ob_start();
    include PD_PLUGIN_PATH . 'includes/templates/encounter-list-template.php';
    return ob_get_clean();
}

// Add invoice shortcode
add_shortcode('pd_invoice', 'pd_invoice_shortcode');
function pd_invoice_shortcode($atts) {
    // Parse attributes
    $atts = shortcode_atts([
        'encounter_id' => 0,
        'show_header' => true
    ], $atts, 'pd_invoice');

    if (!current_user_can('edit_posts')) {
        return '<div class="pd-error">Access denied. You must be a healthcare provider to view invoices.</div>';
    }

    $encounter_id = intval($atts['encounter_id']);
    if (!$encounter_id) {
        return '<div class="pd-error">Invalid encounter ID</div>';
    }

    $db = PD_Database::get_instance();
    $bill = $db->get_bill_details($encounter_id);

    if (!$bill) {
        return '<div class="pd-error">No invoice found for this encounter</div>';
    }

    ob_start();
    include PD_PLUGIN_PATH . 'includes/templates/invoice-popup.php';
    return ob_get_clean();
}

// Add bill shortcode
add_shortcode('pd_bill', 'pd_bill_shortcode');
function pd_bill_shortcode($atts) {
    // Parse attributes
    $atts = shortcode_atts([
        'encounter_id' => 0,
        'show_header' => true
    ], $atts, 'pd_bill');

    if (!current_user_can('edit_posts')) {
        return '<div class="pd-error">Access denied. You must be a healthcare provider to view bills.</div>';
    }

    $encounter_id = intval($atts['encounter_id']);
    if (!$encounter_id) {
        return '<div class="pd-error">Invalid encounter ID</div>';
    }

    $db = PD_Database::get_instance();
    $bill = $db->get_bill_details($encounter_id);

    if (!$bill) {
        return '<div class="pd-error">No bill found for this encounter</div>';
    }

    ob_start();
    include PD_PLUGIN_PATH . 'includes/templates/bill-popup.php';
    return ob_get_clean();
}

// Example usage:
// [pd_invoice encounter_id="123"]
// [pd_bill encounter_id="123"]

// Add a helper function to get encounter ID from appointment
function pd_get_encounter_id_from_appointment($appointment_id) {
    global $wpdb;
    return $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}kc_patient_encounters 
         WHERE appointment_id = %d",
        $appointment_id
    ));
}

// Add shortcode for bill button
add_shortcode('pd_bill_button', 'pd_bill_button_shortcode');
function pd_bill_button_shortcode($atts) {
    $atts = shortcode_atts([
        'encounter_id' => 0,
        'text' => 'View Bill',
        'class' => 'button'
    ], $atts, 'pd_bill_button');

    if (!$atts['encounter_id']) {
        return '';
    }

    return sprintf(
        '<button class="pd-action bill %s" data-encounter="%d">%s</button>',
        esc_attr($atts['class']),
        intval($atts['encounter_id']),
        esc_html($atts['text'])
    );
}

// Add shortcode for invoice button
add_shortcode('pd_invoice_button', 'pd_invoice_button_shortcode');
function pd_invoice_button_shortcode($atts) {
    $atts = shortcode_atts([
        'encounter_id' => 0,
        'text' => 'View Invoice',
        'class' => 'button'
    ], $atts, 'pd_invoice_button');

    if (!$atts['encounter_id']) {
        return '';
    }

    return sprintf(
        '<button class="pd-action invoice %s" data-encounter="%d">%s</button>',
        esc_attr($atts['class']),
        intval($atts['encounter_id']),
        esc_html($atts['text'])
    );
}

// Add new shortcode
add_shortcode('patient_view', 'pd_patient_view_shortcode');
function pd_patient_view_shortcode($atts) {
    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        return '<div class="error">Access denied</div>';
    }

    $patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
    $encounter_id = isset($_GET['encounter_id']) ? intval($_GET['encounter_id']) : 0;

    if (!$patient_id || !$encounter_id) {
        return '<div class="error">Invalid parameters</div>';
    }

    $db = PD_Database::get_instance();
    $patient = $db->get_patient_details($patient_id);
    $encounter = $db->get_full_encounter_details($encounter_id);
    
    if (!$patient || !$encounter) {
        return '<div class="error">Patient or encounter not found</div>';
    }

    ob_start();
    include PD_PLUGIN_PATH . 'includes/templates/patient-view.php';
    return ob_get_clean();
}





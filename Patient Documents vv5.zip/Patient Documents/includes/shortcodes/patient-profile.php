<?php
if (!defined('ABSPATH')) exit;

function pd_patient_profile_shortcode($atts) {
    // Security check
    if (!is_user_logged_in()) {
        return '<p class="error">Please login to view patient profiles.</p>';
    }

    // Check if user has permission
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        return '<p class="error">You do not have permission to view patient profiles.</p>';
    }

    // Get patient ID from URL
    $patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
    
    // Validate patient ID
    if (!$patient_id) {
        return '<p class="error">Invalid patient ID. Please provide a valid patient ID in the URL.</p>';
    }

    // Enqueue required assets
    wp_enqueue_style('pd-patient-profile', PD_PLUGIN_URL . 'assets/css/patient-profile.css');
    wp_enqueue_script('pd-patient-profile', PD_PLUGIN_URL . 'assets/js/patient-profile.js', ['jquery'], false, true);
    
    // Localize script
    wp_localize_script('pd-patient-profile', 'pdData', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pd-nonce'),
        'patient_id' => $patient_id,
        'printCss' => PD_PLUGIN_URL . 'assets/css/print.css',
        'debug' => defined('WP_DEBUG') && WP_DEBUG
    ]);

    // Get database instance
    $db = PD_Database::get_instance();

    try {
        // Get patient data
        $patient = $db->get_patient_details($patient_id);
        if (!$patient) {
            throw new Exception('Patient not found');
        }

        // Get all patient data
        $encounters = $db->get_patient_encounters($patient_id);
        $prescriptions = $db->get_patient_prescriptions($patient_id);
        $documents = $db->get_patient_all_documents($patient_id);

        // Get current active tab
        $current_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'consultations';

        // Start output buffer
        ob_start();

        // Include template
        include PD_PLUGIN_PATH . 'templates/patient-profile.php';

        // Return the buffered content
        return ob_get_clean();

    } catch (Exception $e) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Patient Profile Error: ' . $e->getMessage());
        }
        return '<p class="error">Error loading patient profile: ' . esc_html($e->getMessage()) . '</p>';
    }
}
add_shortcode('patient_profile', 'pd_patient_profile_shortcode');

// Add AJAX handler for loading encounter details
add_action('wp_ajax_pd_load_encounter', 'pd_load_encounter_details');
function pd_load_encounter_details() {
    check_ajax_referer('pd-nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Access denied');
    }

    $encounter_id = isset($_POST['encounter_id']) ? intval($_POST['encounter_id']) : 0;
    if (!$encounter_id) {
        wp_send_json_error('Invalid encounter ID');
    }

    $db = PD_Database::get_instance();
    $encounter = $db->get_full_encounter_details($encounter_id);
    
    if ($encounter) {
        wp_send_json_success([
            'encounter' => $encounter,
            'html' => pd_render_encounter_details($encounter)
        ]);
    } else {
        wp_send_json_error('Encounter not found');
    }
}

// Helper function to render encounter details
function pd_render_encounter_details($encounter) {
    ob_start();
    ?>
    <div class="encounter-details">
        <h3>Encounter Details</h3>
        <div class="encounter-info">
            <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($encounter->encounter_date)); ?></p>
            <p><strong>Doctor:</strong> <?php echo esc_html($encounter->doctor_name); ?></p>
            <p><strong>Clinic:</strong> <?php echo esc_html($encounter->clinic_name); ?></p>
        </div>
        <?php if ($encounter->reason): ?>
            <div class="encounter-reason">
                <h4>Reason for Visit</h4>
                <?php echo wp_kses_post($encounter->reason); ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// Add filter for page title
add_filter('the_title', 'pd_modify_patient_profile_title', 10, 2);
function pd_modify_patient_profile_title($title, $post_id = null) {
    if (is_page() && has_shortcode(get_post_field('post_content', $post_id), 'patient_profile')) {
        $patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
        if ($patient_id) {
            $db = PD_Database::get_instance();
            $patient = $db->get_patient_details($patient_id);
            if ($patient) {
                return esc_html($patient->display_name) . '\'s Profile';
            }
        }
    }
    return $title;
}

// Add breadcrumb navigation
add_action('pd_before_patient_profile', 'pd_add_profile_breadcrumbs');
function pd_add_profile_breadcrumbs() {
    $encounters_page = get_permalink(get_option('pd_encounters_page_id'));
    ?>
    <div class="pd-breadcrumbs">
        <a href="<?php echo esc_url($encounters_page); ?>">← Back to Encounters</a>
    </div>
    <?php
}

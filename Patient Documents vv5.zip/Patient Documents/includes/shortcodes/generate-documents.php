<?php
if (!defined('ABSPATH')) exit;

function pd_generate_documents_shortcode($atts) {
    // Explicitly dequeue script.js if it was somehow enqueued
    wp_dequeue_script('pd-script');
    
    // Enqueue only the documents-specific scripts
    wp_enqueue_editor();
    wp_enqueue_media();
    wp_enqueue_style('pd-documents', PD_PLUGIN_URL . 'assets/css/documents.css');
    wp_enqueue_script('pd-documents', 
        PD_PLUGIN_URL . 'assets/js/documents.js', 
        ['jquery', 'wp-editor'], 
        filemtime(PD_PLUGIN_PATH . 'assets/js/documents.js'), 
        true
    );

    // Localize script
    wp_localize_script('pd-documents', 'pdDocuments', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pd-documents-nonce'),
        'templates' => [
            'certificate' => pd_get_templates('certificate'),
            'letter' => pd_get_templates('letter'),
            'report' => pd_get_templates('report')
        ]
    ]);

    // Start output buffer
    ob_start();

    // Include template
    include PD_PLUGIN_PATH . 'includes/templates/generate-documents.php';

    // Return buffered content
    return ob_get_clean();
}
add_shortcode('generate_documents', 'pd_generate_documents_shortcode');

function pd_get_templates($type) {
    $db = PD_Database::get_instance();
    return $db->get_templates($type);
}

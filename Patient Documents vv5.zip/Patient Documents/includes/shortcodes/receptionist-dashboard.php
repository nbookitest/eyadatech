<?php

add_shortcode('receptionist_dashboard', 'pd_render_receptionist_dashboard');

function pd_render_receptionist_dashboard($atts) {
    // Check user permissions
    if (!current_user_can('edit_posts')) {
        return '<p>Access denied. You do not have permission to view this content.</p>';
    }

    // Enqueue required assets
    wp_enqueue_style('pd-receptionist-dashboard');
    wp_enqueue_style('dashicons');
    wp_enqueue_script('pd-receptionist-dashboard');
    
    // Get the current view (calendar/grid)
    $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'calendar';
    
    // Get current month's appointments
    global $wpdb;
    $current_month = date('n');
    $current_year = date('Y');
    
    // Start output buffering
    ob_start();
    
    // Include the template
    include PD_PLUGIN_PATH . 'includes/templates/receptionist-dashboard.php';
    
    // Return the buffered content
    return ob_get_clean();
}

// Add AJAX handler for appointments
add_action('wp_ajax_pd_get_appointments', 'pd_get_appointments');
function pd_get_appointments() {
    try {
        check_ajax_referer('pd-receptionist-nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            throw new Exception('Access denied');
        }
        
        $month = isset($_POST['month']) ? intval($_POST['month']) : date('n');
        $year = isset($_POST['year']) ? intval($_POST['year']) : date('Y');
        
        // Debug log
        pd_log("Fetching appointments for $month/$year");
        
        $db = PD_Database::get_instance();
        $appointments = $db->get_appointments_for_month($month, $year);
        
        // Debug log
        pd_log("Found appointments: " . print_r($appointments, true));
        
        wp_send_json_success($appointments);
        
    } catch (Exception $e) {
        pd_log("Error in pd_get_appointments: " . $e->getMessage(), 'error');
        wp_send_json_error(['message' => $e->getMessage()]);
    }
}

<?php
class PD_Database {
    private static $instance = null;
    private $wpdb;
    private $connected = false;
    private $last_error = '';

    private function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->check_connection();
    }

    private function check_connection() {
        try {
            $test_query = $this->wpdb->get_var("SELECT 1");
            $this->connected = ($test_query === '1');
            if (!$this->connected) {
                $this->last_error = $this->wpdb->last_error;
                error_log('Database connection failed: ' . $this->last_error);
            }
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Database error: ' . $this->last_error);
            $this->connected = false;
        }
    }

    public function get_last_error() {
        return $this->last_error;
    }

    public function is_connected() {
        return $this->connected;
    }

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function get_patient_data($patient_id) {
        // Get clinical details from existing tables
        $encounter = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM wp_kc_patient_encounters WHERE patient_id = %d ORDER BY id DESC LIMIT 1",
            $patient_id
        ));

        $prescriptions = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM wp_kc_prescription WHERE patient_id = %d",
            $patient_id
        ));

        // Add other data queries as needed...

        return [
            'encounter' => $encounter,
            'prescriptions' => $prescriptions,
            'documents' => $this->get_documents($patient_id) ?? [] // Add fallback
        ];
    }

    public function save_document($patient_id, $type, $content) {
        return $this->wpdb->replace(
            $this->wpdb->prefix . 'kc_patient_documents',
            [
                'patient_id' => $patient_id,
                'document_type' => $type,
                'content' => wp_kses_post($content)
            ],
            ['%d', '%s', '%s']
        );
    }

    private function get_documents($patient_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_patient_documents WHERE patient_id = %d",
            $patient_id
        ));
    }

    public function get_encounter_details($patient_id, $encounter_id) {
        try {
            // Debug log
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Getting encounter details - Patient: $patient_id, Encounter: $encounter_id");
            }

            $encounter = $this->wpdb->get_row($this->wpdb->prepare(
                "SELECT e.*, 
                        u.display_name as patient_name,
                        u.user_email as patient_email,
                        d.display_name as doctor_name,
                        m.meta_value as patient_phone,
                        c.name as clinic_name
                 FROM {$this->wpdb->prefix}kc_patient_encounters e
                 LEFT JOIN {$this->wpdb->users} u ON e.patient_id = u.ID
                 LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
                 LEFT JOIN {$this->wpdb->usermeta} m ON e.patient_id = m.user_id AND m.meta_key = 'phone'
                 LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
                 WHERE e.patient_id = %d 
                 AND e.id = %d",
                $patient_id,
                $encounter_id
            ));

            if (!$encounter && $this->wpdb->last_error) {
                throw new Exception($this->wpdb->last_error);
            }

            // Debug log
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Found encounter data: " . print_r($encounter, true));
            }

            return $encounter;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Error in get_encounter_details: ' . $this->last_error);
            return null;
        }
    }

   /**
     * Get clinical notes from static_data table
     */
    public function get_clinical_notes($encounter_id) {
        $notes = [
            'problems' => [],
            'observations' => [],
            'notes' => []
        ];

        // Get Problems
        $notes['problems'] = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT label, value 
             FROM {$this->wpdb->prefix}kc_static_data
             WHERE type = 'clinical_problems'
             AND parent_id = %d
             AND status = 1",
            $encounter_id
        ));

        // Get Observations
        $notes['observations'] = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT label, value 
             FROM {$this->wpdb->prefix}kc_static_data
             WHERE type = 'clinical_observations'
             AND parent_id = %d
             AND status = 1",
            $encounter_id
        ));

        // Get Notes
        $notes['notes'] = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT label, value 
             FROM {$this->wpdb->prefix}kc_static_data
             WHERE type = 'clinical_notes'
             AND parent_id = %d
             AND status = 1",
            $encounter_id
        ));

        return $notes;
    }

    /**
     * Save clinical notes to static_data table
     */
    public function save_clinical_notes($encounter_id, $data) {
        // Save Problems
        if(!empty($data['problems'])) {
            $this->wpdb->insert(
                "{$this->wpdb->prefix}kc_static_data",
                [
                    'type' => 'clinical_problems',
                    'label' => 'Problem',
                    'value' => sanitize_textarea_field($data['problems']),
                    'parent_id' => $encounter_id,
                    'status' => 1,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%d', '%d', '%s']
            );
        }

        // Save Observations
        if(!empty($data['observations'])) {
            $this->wpdb->insert(
                "{$this->wpdb->prefix}kc_static_data",
                [
                    'type' => 'clinical_observations',
                    'label' => 'Observation',
                    'value' => sanitize_textarea_field($data['observations']),
                    'parent_id' => $encounter_id,
                    'status' => 1,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%d', '%d', '%s']
            );
        }

        // Save Notes
        if(!empty($data['notes'])) {
            $this->wpdb->insert(
                "{$this->wpdb->prefix}kc_static_data",
                [
                    'type' => 'clinical_notes',
                    'label' => 'Note',
                    'value' => sanitize_textarea_field($data['notes']),
                    'parent_id' => $encounter_id,
                    'status' => 1,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%d', '%d', '%s']
            );
        }

        return true;
    }

    public function get_document_template($type) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_patient_documents
             WHERE document_type = %s AND is_template = 1
             ORDER BY id DESC LIMIT 1",
            $type
        ));
    }

    public function save_document_template($type, $content, $name = 'Default') {
        return $this->wpdb->replace(
            $this->wpdb->prefix . 'kc_patient_documents',
            [
                'document_type' => $type,
                'content' => wp_kses_post($content),
                'is_template' => 1,
                'template_name' => $name,
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%d', '%s', '%s']
        );
    }
    public function get_patient_basic_info($patient_id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT 
                u.ID as patient_id,
                u.display_name as patient_name,
                u.user_email as patient_email,
                m.meta_value as patient_phone,
                e.encounter_date
             FROM {$this->wpdb->users} u
             LEFT JOIN {$this->wpdb->usermeta} m 
                ON u.ID = m.user_id AND m.meta_key = 'phone'
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e 
                ON u.ID = e.patient_id
             WHERE u.ID = %d
             ORDER BY e.id DESC
             LIMIT 1",
            $patient_id
        ));
    }

    /**
     * Get single template by ID
     */
    public function get_template($template_id) {
        try {
            // Log template retrieval if debugging is enabled
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Fetching template ID: " . $template_id);
            }

            $template = $this->wpdb->get_row($this->wpdb->prepare(
                "SELECT id, document_type, template_name, content, created_at 
                 FROM {$this->wpdb->prefix}kc_document_templates 
                 WHERE id = %d AND is_template = 1
                 LIMIT 1",
                $template_id
            ));

            if ($template === null && $this->wpdb->last_error) {
                throw new Exception($this->wpdb->last_error);
            }

            return $template;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Error retrieving template: ' . $this->last_error);
            return null;
        }
    }

    /**
     * Get complete encounter details
     */
    public function get_full_encounter_details($encounter_id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT e.*, 
                    p.display_name as patient_name,
                    p.user_email as patient_email,
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    c.address as clinic_address,
                    (SELECT meta_value FROM {$this->wpdb->usermeta} 
                     WHERE user_id = e.patient_id AND meta_key = 'basic_data' LIMIT 1) as patient_basic_data
             FROM {$this->wpdb->prefix}kc_patient_encounters e
             LEFT JOIN {$this->wpdb->users} p ON e.patient_id = p.ID
             LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
             WHERE e.id = %d",
            $encounter_id
        ));
    }

    /**
     * Get all prescriptions for encounter
     */
    public function get_encounter_prescriptions($encounter_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT p.*, 
                    u.display_name as patient_name,
                    d.display_name as doctor_name,
                    c.name as clinic_name
             FROM {$this->wpdb->prefix}kc_prescriptions p
             LEFT JOIN {$this->wpdb->users} u ON p.patient_id = u.ID
             LEFT JOIN {$this->wpdb->users} d ON p.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON p.clinic_id = c.id
             WHERE p.encounter_id = %d 
             ORDER BY p.created_at DESC",
            $encounter_id
        ));
    }

    public function get_encounters($status_filter = 'all') {
        $status_conditions = [
            'active' => [1],
            'closed' => [0]
        ];

        $where = '';
        if (array_key_exists($status_filter, $status_conditions)) {
            $placeholders = implode(',', array_fill(0, count($status_conditions[$status_filter]), '%d'));
            $where = $this->wpdb->prepare(" WHERE e.status IN ($placeholders)", $status_conditions[$status_filter]);
        }

        // Add debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Fetching encounters with service info");
        }

        $query = "
            SELECT 
                e.id as encounter_id,
                e.encounter_date as date,
                e.patient_id,
                e.doctor_id,
                e.clinic_id,
                e.status,
                e.appointment_id,
                p.display_name as patient_name,
                d.display_name as doctor_name,
                c.name as clinic_name,
                CASE 
                    WHEN bi.item_id IS NOT NULL THEN s.name
                    WHEN a.visit_type IS NOT NULL THEN a.visit_type
                    ELSE NULL 
                END as service_name
            FROM {$this->wpdb->prefix}kc_patient_encounters e
            LEFT JOIN {$this->wpdb->users} p ON e.patient_id = p.ID
            LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
            LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
            LEFT JOIN {$this->wpdb->prefix}kc_appointments a ON e.appointment_id = a.id
            LEFT JOIN {$this->wpdb->prefix}kc_bills b ON e.id = b.encounter_id
            LEFT JOIN {$this->wpdb->prefix}kc_bill_items bi ON b.id = bi.bill_id
            LEFT JOIN {$this->wpdb->prefix}kc_services s ON bi.item_id = s.id
            $where
            GROUP BY e.id
            ORDER BY e.encounter_date DESC";

        $results = $this->wpdb->get_results($query);

        // Debug output
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Encounters query: " . $query);
            error_log("Found encounters: " . print_r($results, true));
        }

        return $results;
    }

    // Update the get_bill_details method to handle errors better
    public function get_bill_details($encounter_id) {
        if (!$this->connected) {
            $this->last_error = "Database not connected";
            return null;
        }

        try {
            // First get encounter details
            $encounter = $this->wpdb->get_row($this->wpdb->prepare(
                "SELECT e.*, 
                        p.display_name as patient_name,
                        p.user_email as patient_email,
                        d.display_name as doctor_name,
                        c.name as clinic_name,
                        c.email as clinic_email,
                        c.address as clinic_address
                 FROM {$this->wpdb->prefix}kc_patient_encounters e
                 LEFT JOIN {$this->wpdb->users} p ON e.patient_id = p.ID
                 LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
                 LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
                 WHERE e.id = %d",
                $encounter_id
            ));

            if (!$encounter) {
                $this->last_error = "Encounter not found";
                return null;
            }

            // Get bill with calculated totals
            $bill = $this->wpdb->get_row($this->wpdb->prepare(
                "SELECT b.*, 
                        SUM(bi.price * bi.qty) as total_amount
                 FROM {$this->wpdb->prefix}kc_bills b
                 LEFT JOIN {$this->wpdb->prefix}kc_bill_items bi ON b.id = bi.bill_id
                 WHERE b.encounter_id = %d
                 GROUP BY b.id",
                $encounter_id
            ));

            if (!$bill) {
                // Create new bill
                $this->wpdb->insert(
                    $this->wpdb->prefix . 'kc_bills',
                    [
                        'encounter_id' => $encounter_id,
                        'clinic_id' => $encounter->clinic_id,
                        'title' => 'Bill for ' . $encounter->patient_name,
                        'total_amount' => '0',
                        'discount' => '0',
                        'actual_amount' => '0',
                        'status' => 1,
                        'payment_status' => 'unpaid',
                        'created_at' => current_time('mysql')
                    ],
                    ['%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
                );

                $bill_id = $this->wpdb->insert_id;
                $bill = $this->wpdb->get_row($this->wpdb->prepare(
                    "SELECT * FROM {$this->wpdb->prefix}kc_bills WHERE id = %d",
                    $bill_id
                 ));
                $bill->total_amount = 0;
            }

            // Add encounter and clinic details to bill
            $bill->patient_name = $encounter->patient_name;
            $bill->patient_email = $encounter->patient_email;
            $bill->doctor_name = $encounter->doctor_name;
            $bill->clinic_name = $encounter->clinic_name;
            $bill->clinic_email = $encounter->clinic_email;
            $bill->clinic_address = $encounter->clinic_address;

            // Get bill items
            $bill->items = $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT bi.*, s.name as service_name 
                 FROM {$this->wpdb->prefix}kc_bill_items bi
                 LEFT JOIN {$this->wpdb->prefix}kc_services s ON bi.item_id = s.id
                 WHERE bi.bill_id = %d",
                $bill->id
            ));

            // Calculate totals
            $bill->total_amount = 0;
            foreach ($bill->items as $item) {
                $item->price = (float)$item->price;
                $item->qty = (int)$item->qty;
                $bill->total_amount += $item->price * $item->qty;
            }

            // Get taxes
            $bill->taxes = $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}kc_tax_data 
                 WHERE module_type = 'encounter' AND module_id = %d",
                $encounter_id
            ));

            // Calculate tax amounts and final total
            $total_tax = 0;
            foreach ($bill->taxes as $tax) {
                $tax_amount = 0;
                if ($tax->tax_type === 'percentage') {
                    $tax_amount = ($bill->total_amount * floatval($tax->tax_value)) / 100;
                } else {
                    $tax_amount = floatval($tax->tax_value);
                }
                $total_tax += $tax_amount;
                $tax->amount = $tax_amount;
            }

            $bill->tax_total = $total_tax;
            $bill->discount = (float)$bill->discount;
            $bill->final_total = $bill->total_amount + $total_tax - $bill->discount;
            
            // Update the bill totals in database
            $this->wpdb->update(
                $this->wpdb->prefix . 'kc_bills',
                [
                    'total_amount' => $bill->total_amount,
                    'actual_amount' => $bill->final_total
                ],
                ['id' => $bill->id],
                ['%f', '%f'],
                ['%d']
            );

            return $bill;
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log("Error in get_bill_details: " . $this->last_error);
            return null;
        }
    }

    // Add method to get applicable taxes
    public function get_applicable_taxes($encounter_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT t.* 
             FROM {$this->wpdb->prefix}kc_taxes t
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e ON e.clinic_id = t.clinic_id
             WHERE (t.clinic_id = e.clinic_id OR t.clinic_id IS NULL)
             AND (t.doctor_id = e.doctor_id OR t.doctor_id IS NULL)
             AND t.status = 1
             AND e.id = %d",
            $encounter_id
        ));
    }

    // Add these methods to your PD_Database class
    public function get_patient_document($encounter_id, $type) {
        try {
            // Log request details if debugging is enabled
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf(
                    'Loading document for encounter: %d, type: %s',
                    $encounter_id,
                    $type
                ));
            }

            $document = $this->wpdb->get_row($this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}kc_patient_documents 
                 WHERE encounter_id = %d 
                 AND document_type = %s
                 ORDER BY id DESC 
                 LIMIT 1",
                $encounter_id,
                $type
            ));

            if ($document === null && $this->wpdb->last_error) {
                throw new Exception($this->wpdb->last_error);
            }

            return $document;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Error loading patient document: ' . $this->last_error);
            return null;
        }
    }

    public function save_patient_document($encounter_id, $type, $content) {
        // Get patient_id from encounter
        $patient_id = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT patient_id 
             FROM {$this->wpdb->prefix}kc_patient_encounters 
             WHERE id = %d",
            $encounter_id
        ));

        if (!$patient_id) {
            $this->last_error = 'Could not find patient ID for encounter';
            return false;
        }

        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_patient_documents',
            [
                'encounter_id' => $encounter_id,
                'patient_id' => $patient_id,  // Add patient_id
                'document_type' => $type,
                'content' => wp_kses_post($content),
                'created_at' => current_time('mysql')
            ],
            ['%d', '%d', '%s', '%s', '%s']
        );
    }

    public function get_consultation_details($encounter_id) {
        // Add debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Fetching consultation for encounter_id: " . $encounter_id);
        }

        $consultation = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_medical_consultations 
             WHERE encounter_id = %d 
             LIMIT 1",
            $encounter_id
        ));

        // Log what we found
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Found consultation data: " . print_r($consultation, true));
        }

        return $consultation;
    }

    public function get_patient_documents($encounter_id, $type = null) {
        $sql = "SELECT * FROM {$this->wpdb->prefix}kc_patient_documents 
                WHERE encounter_id = %d";
        $params = [$encounter_id];
        
        if ($type) {
            $sql .= " AND document_type = %s";
            $params[] = $type;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        return $this->wpdb->get_results($this->wpdb->prepare($sql, $params));
    }

    public function save_consultation($encounter_id, $patient_id, $data) {
        try {
            // Debug logging
            error_log('=== Save Consultation Debug ===');
            error_log('Encounter ID: ' . $encounter_id);
            error_log('Patient ID: ' . $patient_id);
            error_log('Data: ' . print_r($data, true));

            // Validate input
            if (!$encounter_id || !$patient_id) {
                throw new Exception('Missing required IDs');
            }

            // Prepare data
            $fields = array(
                'encounter_id' => (int)$encounter_id,
                'patient_id' => (int)$patient_id,
                'reason' => isset($data['reason']) ? wp_kses_post($data['reason']) : '',
                'background' => isset($data['background']) ? wp_kses_post($data['background']) : '',
                'symptoms' => isset($data['symptoms']) ? wp_kses_post($data['symptoms']) : '',
                'current_treatment' => isset($data['current_treatment']) ? wp_kses_post($data['current_treatment']) : '',
                'interrogation' => isset($data['interrogation']) ? wp_kses_post($data['interrogation']) : '',
                'updated_at' => current_time('mysql')
            );

            error_log('Prepared fields: ' . print_r($fields, true));

            // Check if consultation exists
            $existing = $this->wpdb->get_var($this->wpdb->prepare(
                "SELECT id FROM {$this->wpdb->prefix}kc_medical_consultations WHERE encounter_id = %d",
                $encounter_id
            ));

            if ($existing) {
                // Update existing record
                $result = $this->wpdb->update(
                    $this->wpdb->prefix . 'kc_medical_consultations',
                    $fields,
                    ['encounter_id' => $encounter_id],
                    ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s'],
                    ['%d']
                );
                error_log('Update result: ' . var_export($result, true));
            } else {
                // Insert new record
                $fields['created_at'] = current_time('mysql');
                $result = $this->wpdb->insert(
                    $this->wpdb->prefix . 'kc_medical_consultations',
                    $fields,
                    ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
                );
                error_log('Insert result: ' . var_export($result, true));
            }

            if ($result === false) {
                throw new Exception($this->wpdb->last_error ?: 'Database error occurred');
            }

            return true;

        } catch (Exception $e) {
            error_log('Save consultation error: ' . $e->getMessage());
            $this->last_error = $e->getMessage();
            return false;
        }
    }

    public function add_prescription($data) {
        try {
            // Log the incoming data if debug is enabled
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Adding prescription with data: ' . print_r($data, true));
            }

            $result = $this->wpdb->insert(
                $this->wpdb->prefix . 'kc_prescriptions',
                [
                    'encounter_id' => $data['encounter_id'],
                    'patient_id' => $data['patient_id'],
                    'medication_name' => $data['medication_name'],
                    'dosage' => $data['dosage'],
                    'frequency' => $data['frequency'],
                    'duration' => $data['duration'],
                    'instructions' => $data['instructions'],
                    'doctor_id' => $data['doctor_id'],
                    'clinic_id' => $data['clinic_id'],
                    'created_at' => $data['created_at']
                ],
                [
                    '%d', // encounter_id
                    '%d', // patient_id
                    '%s', // medication_name
                    '%s', // dosage
                    '%s', // frequency
                    '%s', // duration
                    '%s', // instructions
                    '%d', // doctor_id
                    '%d', // clinic_id
                    '%s'  // created_at
                ]
            );

            if ($result === false) {
                throw new Exception($this->wpdb->last_error);
            }

            return $this->wpdb->insert_id;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Database error adding prescription: ' . $this->last_error);
            return false;
        }
    }

    public function delete_prescription($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . 'kc_prescriptions',
            ['id' => $id],
            ['%d']
        );
    }

    // Add to your PD_Database class
    public function get_patient_details($patient_id) {
        $patient = get_userdata($patient_id);
        if (!$patient) return null;

        // Get the JSON data from basic_data meta
        $basic_data_json = get_user_meta($patient_id, 'basic_data', true);
        if ($basic_data_json) {
            $basic_data = json_decode($basic_data_json, true);
            
            // Map the JSON data to patient object
            $patient->phone = $basic_data['mobile_number'] ?? '';
            $patient->gender = $basic_data['gender'] ?? '';
            $patient->dob = $basic_data['dob'] ?? '';
            $patient->address = $basic_data['address'] ?? '';
            $patient->city = $basic_data['city'] ?? '';
            $patient->country = $basic_data['country'] ?? '';
            $patient->basic_data = $basic_data; // Store full data
        }

        return $patient;
    }

    // Add method to get full patient info
    public function get_full_patient_info($patient_id) {
        $basic_data = get_user_meta($patient_id, 'basic_data', true);
        if ($basic_data) {
            return json_decode($basic_data, true);
        }
        return null;
    }

    public function save_prescription($data) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_prescriptions',
            [
                'encounter_id' => $data['encounter_id'],
                'patient_id' => $data['patient_id'],
                'medication_name' => $data['medication_name'],
                'dosage' => $data['dosage'],
                'frequency' => $data['frequency'],
                'duration' => $data['duration'],
                'instructions' => $data['instructions'],
                'doctor_id' => get_current_user_id(),
                'clinic_id' => $data['clinic_id'],
                'created_at' => current_time('mysql')
            ],
            ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s']
        );
    }

    public function get_prescription_templates($doctor_id, $clinic_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_prescription_templates
             WHERE doctor_id = %d 
             AND clinic_id = %d
             ORDER BY name ASC",
            $doctor_id,
            $clinic_id
        ));
    }

    public function save_prescription_template($data) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_prescription_templates',
            [
                'name' => $data['name'],
                'medication_name' => $data['medication_name'],
                'dosage' => $data['dosage'],
                'frequency' => $data['frequency'],
                'duration' => $data['duration'],
                'instructions' => $data['instructions'],
                'doctor_id' => get_current_user_id(),
                'clinic_id' => $data['clinic_id'],
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s']
        );
    }

    public function get_prescription($prescription_id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT p.*, 
                    u.display_name as patient_name,
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    c.address as clinic_address,
                    c.phone as clinic_phone,
                    m.meta_value as doctor_specialty
             FROM {$this->wpdb->prefix}kc_prescriptions p
             LEFT JOIN {$this->wpdb->users} u ON p.patient_id = u.ID
             LEFT JOIN {$this->wpdb->users} d ON p.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON p.clinic_id = c.id
             LEFT JOIN {$this->wpdb->usermeta} m ON p.doctor_id = m.user_id AND m.meta_key = 'specialty'
             WHERE p.id = %d",
            $prescription_id
        ));
    }
    public function get_patient_encounters($patient_id) {
        // Add debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Fetching encounters for patient: " . $patient_id);
        }

        $query = $this->wpdb->prepare(
            "SELECT e.*, 
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    CASE 
                        WHEN bi.item_id IS NOT NULL THEN s.name
                        WHEN a.visit_type IS NOT NULL THEN a.visit_type
                        ELSE NULL 
                    END as service_name,
                    mc.reason,
                    mc.symptoms,
                    mc.background,
                    mc.current_treatment,
                    mc.interrogation
             FROM {$this->wpdb->prefix}kc_patient_encounters e
             LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
             LEFT JOIN {$this->wpdb->prefix}kc_medical_consultations mc ON e.id = mc.encounter_id
             LEFT JOIN {$this->wpdb->prefix}kc_appointments a ON e.appointment_id = a.id
             LEFT JOIN {$this->wpdb->prefix}kc_bills b ON e.id = b.encounter_id
             LEFT JOIN {$this->wpdb->prefix}kc_bill_items bi ON b.id = bi.bill_id
             LEFT JOIN {$this->wpdb->prefix}kc_services s ON bi.item_id = s.id
             WHERE e.patient_id = %d
             GROUP BY e.id
             ORDER BY e.encounter_date DESC",
            $patient_id
        );

        // Debug output
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Patient encounters query: " . $query);
        }

        $results = $this->wpdb->get_results($query);

        // Debug output
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Found patient encounters: " . print_r($results, true));
        }

        return $results;
    }

    public function get_patient_prescriptions($patient_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT p.*, 
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    e.encounter_date
             FROM {$this->wpdb->prefix}kc_prescriptions p
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e ON p.encounter_id = e.id
             LEFT JOIN {$this->wpdb->users} d ON p.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON p.clinic_id = c.id
             WHERE p.patient_id = %d
             ORDER BY p.created_at DESC",
            $patient_id
        ));
    }

    public function get_patient_prescriptions_by_encounters($patient_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT p.*, 
                    e.encounter_date,
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    c.address as clinic_address,
                    c.phone as clinic_phone
             FROM {$this->wpdb->prefix}kc_prescriptions p
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e ON p.encounter_id = e.id
             LEFT JOIN {$this->wpdb->users} d ON p.doctor_id = d.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON p.clinic_id = c.id
             WHERE p.patient_id = %d
             ORDER BY e.encounter_date DESC, p.created_at DESC",
            $patient_id
        ));
    }

    public function get_patient_all_documents($patient_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT d.*, 
                    e.encounter_date,
                    u.display_name as doctor_name,
                    c.name as clinic_name
             FROM {$this->wpdb->prefix}kc_patient_documents d
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e ON d.encounter_id = e.id
             LEFT JOIN {$this->wpdb->users} u ON e.doctor_id = u.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
             WHERE d.patient_id = %d 
             AND d.is_template = 0
             ORDER BY d.created_at DESC",
            $patient_id
        ));
    }
    public function get_encounter_documents($encounter_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_patient_documents 
             WHERE encounter_id = %d 
             ORDER BY document_type ASC, created_at DESC",
            $encounter_id
        ));
    }

    public function get_document_by_id($document_id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT d.*, 
                    e.encounter_date,
                    u.display_name as doctor_name,
                    p.display_name as patient_name,
                    c.name as clinic_name,
                    c.address as clinic_address
             FROM {$this->wpdb->prefix}kc_patient_documents d
             LEFT JOIN {$this->wpdb->prefix}kc_patient_encounters e ON d.encounter_id = e.id
             LEFT JOIN {$this->wpdb->users} u ON e.doctor_id = u.ID
             LEFT JOIN {$this->wpdb->users} p ON d.patient_id = p.ID
             LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
             WHERE d.id = %d",
            $document_id
        ));
    }

    /**
     * Save new template
     */
    // Update the save_template method
    public function save_template($data) {
        try {
            // Log incoming data
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Saving template with data: ' . print_r($data, true));
            }

            // Validate required fields
            if (empty($data['document_type']) || empty($data['template_name']) || empty($data['content'])) {
                $this->last_error = 'Missing required template fields';
                return false;
            }

            $result = $this->wpdb->insert(
                $this->wpdb->prefix . 'kc_document_templates',
                [
                    'document_type' => sanitize_text_field($data['document_type']),
                    'template_name' => sanitize_text_field($data['template_name']),
                    'content' => wp_kses_post($data['content']),
                    'is_template' => 1,
                    'created_by' => get_current_user_id(),
                    'created_at' => current_time('mysql')
                ],
                [
                    '%s', // document_type
                    '%s', // template_name
                    '%s', // content
                    '%d', // is_template
                    '%d', // created_by
                    '%s'  // created_at
                ]
            );

            if ($result === false) {
                $this->last_error = $this->wpdb->last_error;
                return false;
            }

            return true;
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Template save error: ' . $this->last_error);
            return false;
        }
    }

    public function get_templates($type) {
        try {
            return $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT id, template_name, document_type, content, created_at 
                 FROM {$this->wpdb->prefix}kc_document_templates 
                 WHERE document_type = %s AND is_template = 1
                 ORDER BY template_name ASC",
                $type
            ));
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Get templates error: ' . $this->last_error);
            return [];
        }
    }

    public function get_medications() {
        try {
            return $this->wpdb->get_results(
                "SELECT id, name 
                 FROM {$this->wpdb->prefix}kc_medications 
                 ORDER BY name ASC"
            );
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Get medications error: ' . $this->last_error);
            return [];
        }
    }

    public function add_medication($name) {
        try {
            // Check if medication already exists
            $exists = $this->wpdb->get_var($this->wpdb->prepare(
                "SELECT id FROM {$this->wpdb->prefix}kc_medications WHERE name = %s",
                $name
            ));

            if ($exists) {
                return $exists; // Return existing ID
            }

            // Add new medication
            $result = $this->wpdb->insert(
                $this->wpdb->prefix . 'kc_medications',
                [
                    'name' => $name,
                    'created_by' => get_current_user_id(),
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%d', '%s']
            );

            if ($result === false) {
                throw new Exception($this->wpdb->last_error);
            }

            return $this->wpdb->insert_id;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Add medication error: ' . $this->last_error);
            return false;
        }
    }

    public function get_filtered_encounters($search = '', $date_filter = 'all', $date_from = null, $date_to = null, $status = 'all') {
        try {
            $where = [];
            $params = [];
            
            // Search condition
            if (!empty($search)) {
                $where[] = "(p.display_name LIKE %s OR d.display_name LIKE %s OR e.id LIKE %s)";
                $search_term = '%' . $this->wpdb->esc_like($search) . '%';
                $params = array_merge($params, [$search_term, $search_term, $search_term]);
            }
            
            // Status filter
            if ($status !== 'all') {
                $where[] = "e.status = %d";
                $params[] = ($status === 'active') ? 1 : 0;
            }
            
            // Date filtering
            switch ($date_filter) {
                case 'today':
                    $where[] = "DATE(e.encounter_date) = CURDATE()";
                    break;
                case 'week':
                    $where[] = "YEARWEEK(e.encounter_date, 1) = YEARWEEK(CURDATE(), 1)";
                    break;
                case 'month':
                    $where[] = "YEAR(e.encounter_date) = YEAR(CURDATE()) AND MONTH(e.encounter_date) = MONTH(CURDATE())";
                    break;
                case 'custom':
                    if ($date_from && $date_to) {
                        $where[] = "DATE(e.encounter_date) BETWEEN %s AND %s";
                        $params[] = $date_from;
                        $params[] = $date_to;
                    }
                    break;
            }

            $where_clause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
            
            $query = $this->wpdb->prepare(
                "SELECT 
                    e.id as encounter_id,
                    e.encounter_date,
                    e.patient_id,
                    e.doctor_id,
                    e.clinic_id,
                    e.status,
                    e.appointment_id,
                    p.display_name as patient_name,
                    d.display_name as doctor_name,
                    c.name as clinic_name,
                    CASE 
                        WHEN bi.item_id IS NOT NULL THEN s.name
                        WHEN a.visit_type IS NOT NULL THEN a.visit_type
                        ELSE NULL 
                    END as service_name
                FROM {$this->wpdb->prefix}kc_patient_encounters e
                LEFT JOIN {$this->wpdb->users} p ON e.patient_id = p.ID
                LEFT JOIN {$this->wpdb->users} d ON e.doctor_id = d.ID
                LEFT JOIN {$this->wpdb->prefix}kc_clinics c ON e.clinic_id = c.id
                LEFT JOIN {$this->wpdb->prefix}kc_appointments a ON e.appointment_id = a.id
                LEFT JOIN {$this->wpdb->prefix}kc_bills b ON e.id = b.encounter_id
                LEFT JOIN {$this->wpdb->prefix}kc_bill_items bi ON b.id = bi.bill_id
                LEFT JOIN {$this->wpdb->prefix}kc_services s ON bi.item_id = s.id
                $where_clause
                GROUP BY e.id
                ORDER BY e.encounter_date DESC",
                $params
            );

            // Debug logging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Filter Query: " . $query);
            }

            return $this->wpdb->get_results($query);

        } catch (Exception $e) {
            error_log('Filter encounters error: ' . $e->getMessage());
            return [];
        }
    }

    public function save_driver_license_report($data) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_driver_license_reports',
            [
                'patient_id' => $data['patient_id'],
                'encounter_id' => $data['encounter_id'],
                'file_name' => $data['file_name'],
                'file_path' => $data['file_path'],
                'file_type' => $data['file_type'],
                'uploaded_by' => get_current_user_id(),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%d']
        );
    }

    public function get_driver_license_reports($patient_id) {
        try {
            return $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT r.*, u.display_name as uploaded_by_name 
                 FROM {$this->wpdb->prefix}kc_driver_license_reports r
                 LEFT JOIN {$this->wpdb->users} u ON r.uploaded_by = u.ID
                 WHERE r.patient_id = %d
                 ORDER BY r.created_at DESC",
                $patient_id
            ));
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Error getting driver license reports: ' . $this->last_error);
            return [];
        }
    }

    public function get_patients_list($search = '', $page = 1, $per_page = 20) {
        global $wpdb;
    
        // Calculate offset for pagination
        $offset = ($page - 1) * $per_page;
    
        // Base WHERE clause to filter patients
        $where = "WHERE um.meta_key = '{$wpdb->prefix}capabilities' AND um.meta_value LIKE '%kiviCare_patient%'";
    
        // Add search conditions if provided
        $params = [];
        if (!empty($search)) {
            $where .= " AND (u.display_name LIKE %s OR phone.meta_value LIKE %s OR basic.fields_data LIKE %s)";
            $search_term = '%' . $wpdb->esc_like($search) . '%';
            $params = array_merge($params, [$search_term, $search_term, $search_term]);
        }
    
        // Main query to fetch patients with phone and CIN
        $query = $wpdb->prepare(
            "SELECT DISTINCT 
                u.ID, 
                u.display_name,
                phone.meta_value AS phone_data,
                basic.fields_data AS basic_data,
                cin.fields_data AS cin_data
             FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
             LEFT JOIN {$wpdb->usermeta} phone ON u.ID = phone.user_id AND phone.meta_key = 'basic_data'
             LEFT JOIN {$wpdb->prefix}kc_custom_fields_data basic ON u.ID = basic.module_id AND basic.field_id = 1
             LEFT JOIN {$wpdb->prefix}kc_custom_fields_data cin ON u.ID = cin.module_id AND cin.field_id = 1
             $where
             ORDER BY u.display_name ASC
             LIMIT %d OFFSET %d",
            array_merge($params, [$per_page, $offset])
        );
    
        // Execute the query
        $patients = $wpdb->get_results($query);
    
        // Process each patient to extract phone and CIN
        foreach ($patients as &$patient) {
            // Extract phone number from basic_data JSON
            if (!empty($patient->phone_data)) {
                $phone_data = json_decode($patient->phone_data, true);
                $patient->phone = isset($phone_data['mobile_number']) ? $phone_data['mobile_number'] : 'N/A';
            } else {
                $patient->phone = 'N/A';
            }
    
            // Extract CIN from fields_data
            if (!empty($patient->cin_data)) {
                $cin_data = maybe_unserialize($patient->cin_data);
                $patient->cin = is_array($cin_data) ? $cin_data[0] : $cin_data; // Assuming CIN is stored as an array or string
            } else {
                $patient->cin = 'N/A';
            }
        }
    
        return $patients;
    }

    public function get_total_patients($search = '') {
        $where = "WHERE um.meta_key = '{$this->wpdb->prefix}capabilities' AND um.meta_value LIKE '%kiviCare_patient%'";
        $params = [];

        if ($search) {
            $where .= " AND (u.display_name LIKE %s OR m1.meta_value LIKE %s OR m2.meta_value LIKE %s)";
            $search_term = '%' . $this->wpdb->esc_like($search) . '%';
            $params = array($search_term, $search_term, $search_term);
        }

        $query = $this->wpdb->prepare(
            "SELECT COUNT(DISTINCT u.ID)
             FROM {$this->wpdb->users} u
             INNER JOIN {$this->wpdb->usermeta} um ON u.ID = um.user_id
             LEFT JOIN {$this->wpdb->usermeta} m1 ON u.ID = m1.user_id AND m1.meta_key = 'cin'
             LEFT JOIN {$this->wpdb->usermeta} m2 ON u.ID = m2.user_id AND m2.meta_key = 'phone'
             $where",
            $params
        );

        return $this->wpdb->get_var($query);
    }

    public function save_accounting($data, $id = null) {
        try {
            $fields = [
                'date' => $data['date'],
                'invoice_number' => $data['invoice_number'],
                'beneficiary' => $data['beneficiary'],
                'payment_method' => $data['payment_method'],
                'payment_reference' => $data['payment_reference'],
                'amount' => $data['amount']
            ];

            if ($id) {
                // Update existing entry
                $result = $this->wpdb->update(
                    $this->wpdb->prefix . 'kc_accounting',
                    $fields,
                    ['id' => $id],
                    ['%s', '%s', '%s', '%s', '%s', '%f'],
                    ['%d']
                );
            } else {
                // Insert new entry
                $result = $this->wpdb->insert(
                    $this->wpdb->prefix . 'kc_accounting',
                    $fields,
                    ['%s', '%s', '%s', '%s', '%s', '%f']
                );
            }

            if ($result === false) {
                throw new Exception($this->wpdb->last_error);
            }

            return true;

        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            return false;
        }
    }

    public function get_accounting_entry($id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_accounting WHERE id = %d",
            $id
        ));
    }

    public function get_accounting_list() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}kc_accounting 
             ORDER BY date DESC, id DESC"
        );
    }

    public function delete_accounting($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . 'kc_accounting',
            ['id' => $id],
            ['%d']
        );
    }

    public function save_medical_report($data) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_medical_reports',
            [
                'patient_id' => $data['patient_id'],
                'encounter_id' => $data['encounter_id'],
                'file_name' => $data['file_name'],
                'file_path' => $data['file_path'],
                'file_type' => $data['file_type'],
                'uploaded_by' => get_current_user_id(),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%d']
        );
    }

    public function get_medical_reports($patient_id) {
        try {
            return $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT r.*, u.display_name as uploaded_by_name 
                 FROM {$this->wpdb->prefix}kc_medical_reports r
                 LEFT JOIN {$this->wpdb->users} u ON r.uploaded_by = u.ID
                 WHERE r.patient_id = %d
                 ORDER BY r.created_at DESC",
                $patient_id
            ));
        } catch (Exception $e) {
            $this->last_error = $e->getMessage();
            error_log('Error getting medical reports: ' . $this->last_error);
            return [];
        }
    }

    public function get_driver_license_records($search = '', $date_filter = 'all', $date_from = null, $date_to = null) {
        $where = [];
        $params = [];
        
        if ($search) {
            $where[] = "(patient_name LIKE %s OR cin LIKE %s OR order_number LIKE %s)";
            $search_term = '%' . $this->wpdb->esc_like($search) . '%';
            $params = array_merge($params, [$search_term, $search_term, $search_term]);
        }
        
        switch ($date_filter) {
            case 'today':
                $where[] = "DATE(date) = CURDATE()";
                break;
            case 'week':
                $where[] = "YEARWEEK(date) = YEARWEEK(CURDATE())";
                break;
            case 'month':
                $where[] = "MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())";
                break;
            case 'year':
                $where[] = "YEAR(date) = YEAR(CURDATE())";
                break;
            case 'custom':
                if ($date_from && $date_to) {
                    $where[] = "date BETWEEN %s AND %s";
                    $params[] = $date_from;
                    $params[] = $date_to;
                }
                break;
        }
        
        $where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_driver_license_records 
             $where_clause 
             ORDER BY date DESC",
            $params
        ));
    }

    public function save_driver_license_record($data, $id = null) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'kc_driver_license_records';

        // Prepare data for insertion/update
        $prepared_data = [
            'order_number'   => sanitize_text_field($data['order_number']),
            'date'           => sanitize_text_field($data['date']),
            'patient_name'   => sanitize_text_field($data['patient_name']),
            'cin'            => sanitize_text_field($data['cin']),
            'license_type'   => sanitize_text_field($data['license_type']),
            'interest_status'=> sanitize_text_field($data['interest_status']),
        ];

        // If ID is provided, update the record; otherwise, insert a new one
        if ($id) {
            $result = $wpdb->update(
                $table_name,
                $prepared_data,
                ['id' => $id],
                ['%s', '%s', '%s', '%s', '%s', '%s'], // Format for columns
                ['%d'] // Format for WHERE clause
            );
        } else {
            $prepared_data['created_at'] = current_time('mysql'); // Add created timestamp
            $result = $wpdb->insert(
                $table_name,
                $prepared_data,
                ['%s', '%s', '%s', '%s', '%s', '%s'] // Format for columns
            );
        }

        return $result !== false; // Return true if successful
    }

    public function delete_driver_license_record($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . 'kc_driver_license_records',
            ['id' => $id],
            ['%d']
        );
    }

    public function get_driver_license_record($id) {
        return $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->wpdb->prefix}kc_driver_license_records WHERE id = %d",
            $id
        ));
    }

    // Ultrasound Methods
    public function get_ultrasounds() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}kc_ultrasounds ORDER BY name ASC"
        );
    }

    public function add_ultrasound($name, $description = '') {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_ultrasounds',
            [
                'name' => $name,
                'description' => $description
            ],
            ['%s', '%s']
        );
    }

    public function get_patient_ultrasounds($encounter_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT pu.*, u.name as ultrasound_name 
             FROM {$this->wpdb->prefix}kc_patient_ultrasounds pu
             LEFT JOIN {$this->wpdb->prefix}kc_ultrasounds u ON pu.ultrasound_id = u.id
             WHERE pu.encounter_id = %d
             ORDER BY pu.created_at DESC",
            $encounter_id
        ));
    }

    public function add_patient_ultrasound($patient_id, $encounter_id, $ultrasound_id) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_patient_ultrasounds',
            [
                'patient_id' => $patient_id,
                'encounter_id' => $encounter_id,
                'ultrasound_id' => $ultrasound_id
            ],
            ['%d', '%d', '%d']
        );
    }

    // Analyse & Radio Methods
    public function get_analyse_radio() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}kc_analyse_radio ORDER BY name ASC"
        );
    }

    public function add_analyse_radio($name, $description = '') {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_analyse_radio',
            [
                'name' => $name,
                'description' => $description
            ],
            ['%s', '%s']
        );
    }

    public function get_patient_analyse_radio($encounter_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT par.*, ar.name as analyse_radio_name 
             FROM {$this->wpdb->prefix}kc_patient_analyse_radio par
             LEFT JOIN {$this->wpdb->prefix}kc_analyse_radio ar ON par.analyse_radio_id = ar.id
             WHERE par.encounter_id = %d
             ORDER BY par.created_at DESC",
            $encounter_id
        ));
    }

    public function add_patient_analyse_radio($patient_id, $encounter_id, $analyse_radio_id) {
        return $this->wpdb->insert(
            $this->wpdb->prefix . 'kc_patient_analyse_radio',
            [
                'patient_id' => $patient_id,
                'encounter_id' => $encounter_id,
                'analyse_radio_id' => $analyse_radio_id
            ],
            ['%d', '%d', '%d']
        );
    }

    public function delete_patient_ultrasound($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . 'kc_patient_ultrasounds',
            ['id' => $id],
            ['%d']
        );
    }

    public function delete_patient_analyse_radio($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . 'kc_patient_analyse_radio',
            ['id' => $id],
            ['%d']
        );
    }

    public function get_appointments_for_month($month, $year, $search = '') {
        try {
            $start_date = sprintf('%d-%02d-01', $year, $month);
            $end_date = sprintf('%d-%02d-31', $year, $month);
            
            // Build search condition
            $search_condition = '';
            $search_params = [];
            if (!empty($search)) {
                $search_condition = "AND (u.display_name LIKE %s OR cfd_info.fields_data LIKE %s)";
                $search_term = '%' . $this->wpdb->esc_like($search) . '%';
                $search_params = [$search_term, $search_term];
            }

            $query = $this->wpdb->prepare(
                "SELECT 
                    e.id as encounter_id,
                    p.ID as patient_id,
                    p.display_name as patient_name,
                    cfd4.fields_data as more_info,
                    cfd5.fields_data as next_appointment_date,
                    (SELECT CONCAT('/wp-admin/admin.php?page=dashboard#/patient-appointment-list/', p.ID) ) as appointment_link
                FROM {$this->wpdb->prefix}kc_patient_encounters e
                INNER JOIN {$this->wpdb->users} p
                    ON e.patient_id = p.ID
                INNER JOIN {$this->wpdb->prefix}kc_custom_fields_data cfd5
                    ON e.id = cfd5.module_id
                    AND cfd5.field_id = 5
                LEFT JOIN {$this->wpdb->prefix}kc_custom_fields_data cfd4
                    ON e.id = cfd4.module_id
                    AND cfd4.field_id = 4
                WHERE DATE(cfd5.fields_data) BETWEEN %s AND %s
                ORDER BY cfd5.fields_data ASC",
                $start_date,
                $end_date
            );

            $results = $this->wpdb->get_results($query);

            // Debug log
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Appointments query: " . $this->wpdb->last_query);
                error_log("Found " . count($results) . " appointments");
            }

            // Process results
            foreach ($results as &$result) {
                $result->appointment_link = admin_url("admin.php?page=dashboard#/patient-appointment-list/{$result->patient_id}");
                if ($result->more_info) {
                    $result->more_info = maybe_unserialize($result->more_info);
                }
            }

            return $results;

        } catch (Exception $e) {
            error_log('Error getting appointments: ' . $e->getMessage());
            return [];
        }
    }

    public function create_patient_encounter($patient_id) {
        try {
            $this->wpdb->insert(
                $this->wpdb->prefix . 'kc_patient_encounters',
                [
                    'patient_id' => $patient_id,
                    'created_at' => current_time('mysql')
                ],
                ['%d', '%s']
            );
            return $this->wpdb->insert_id;
        } catch (Exception $e) {
            error_log('DB Error: ' . $e->getMessage());
            return 0;
        }
    }
    
    public function save_encounter_custom_fields($encounter_id, $more_info, $next_appointment) {
        try {
            // Save More Information (Field 4)
            $this->wpdb->replace(
                $this->wpdb->prefix . 'kc_custom_fields_data',
                [
                    'module_type' => 'encounter_module',
                    'module_id' => $encounter_id,
                    'field_id' => 4,
                    'fields_data' => $more_info,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%d', '%d', '%s', '%s']
            );
    
            // Save Next Appointment (Field 5)
            $result = $this->wpdb->replace(
                $this->wpdb->prefix . 'kc_custom_fields_data',
                [
                    'module_type' => 'encounter_module',
                    'module_id' => $encounter_id,
                    'field_id' => 5,
                    'fields_data' => $next_appointment,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%d', '%d', '%s', '%s']
            );
    
            return $result !== false;
        } catch (Exception $e) {
            error_log('Error saving fields: ' . $e->getMessage());
            return false;
        }
    }

}
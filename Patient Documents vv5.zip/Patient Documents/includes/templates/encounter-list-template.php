<?php
$db = PD_Database::get_instance();
$current_date = current_time('Y-m-d');

// Get filter parameters
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$date_filter = isset($_GET['date_filter']) ? sanitize_text_field($_GET['date_filter']) : 'today';
$date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : $current_date;
$date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : $current_date;

// Get filtered encounters
$encounters = $db->get_filtered_encounters($search, $date_filter, $date_from, $date_to);
?>
<div class="pd-encounter-list-container">
    <!-- Search and Filter Controls -->
    <div class="encounter-filters">
        <div class="search-box">
            <input type="text" id="encounter-search" 
                   placeholder="Rechercher par nom de patient..." 
                   value="<?php echo esc_attr($search); ?>">
        </div>

        <div class="date-filters">
            <select id="date-filter" class="date-filter">
                <option value="all" <?php selected($date_filter, 'all'); ?>>Toutes les rencontres</option>
                <option value="today" <?php selected($date_filter, 'today'); ?>>Aujourd'hui</option>
                <option value="week" <?php selected($date_filter, 'week'); ?>>Cette semaine</option>
                <option value="month" <?php selected($date_filter, 'month'); ?>>Ce mois-ci</option>
                <option value="custom" <?php selected($date_filter, 'custom'); ?>>Gamme personnalisée</option>
            </select>

            <div class="custom-date-range" style="display: <?php echo $date_filter === 'custom' ? 'inline-flex' : 'none'; ?>">
                <input type="date" id="date-from" value="<?php echo esc_attr($date_from); ?>">
                <span>to</span>
                <input type="date" id="date-to" value="<?php echo esc_attr($date_to); ?>">
            </div>
        </div>

        <select class="status-filter">
            <option value="all">Tous les statuts</option>
            <option value="active">Active</option>
            <option value="closed">Fermée</option>
        </select>

        <button class="pd-filter-button button"><?php esc_html_e('Appliquer les filtres', 'textdomain'); ?></button>
    </div>

    <!-- Results Count -->
    <div class="results-count">
        <?php printf(
            _n(
                '%s rencontre trouvée',
                '%s rencontres trouvées',
                count($encounters),
                'textdomain'
            ),
            number_format_i18n(count($encounters))
        ); ?>
    </div>

    <table class="pd-encounter-table">
        <thead>
            <tr>
                <th>Doctor</th>
                <th>Patient</th>
                <th>Service</th>  <!-- Add this line -->
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($encounters as $encounter) : ?>
            <tr data-appointment="<?php echo esc_attr($encounter->appointment_id); ?>">
                <td><?php echo esc_html($encounter->doctor_name); ?></td>
                <td><?php echo esc_html($encounter->patient_name); ?></td>
                <td>
                    <?php 
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("Service for encounter {$encounter->encounter_id}: " . 
                                 print_r($encounter->service_name, true));
                    }
                    echo esc_html($encounter->service_name ?: 'N/A'); 
                    ?>
                </td>
                <td><?php echo date_i18n('M j, Y H:i', strtotime($encounter->encounter_date)); ?></td>
                <td>
                    <span class="status-label status-<?php echo esc_attr($encounter->status); ?>">
                         <?php echo ($encounter->status == 1) ? 'Active' : 'Closed'; ?>
                    </span>
                </td>
                <td class="actions" data-label="Actions">
                    <?php if (pd_can_view_buttons()): ?>
                    <div class="action-buttons">
                        <!-- Profile KC -->
                        <a href="<?php echo admin_url("/admin.php?page=dashboard#/patient/edit/{$encounter->patient_id}"); ?>" 
                           class="pd-action profile" 
                           target="_blank"
                           title="Modifier le profil du patient">
                            <span class="dashicons dashicons-edit"></span>
                        </a>

                        <!-- Profile View -->
                    <a href="<?php echo admin_url("/patient-profile/?patient_id={$encounter->patient_id}"); ?>" 
                       class="pd-action profile" 
                       target="_blank"
                       title="Vue de profil du patient">
                        <span class="dashicons dashicons-admin-users"></span>
                    </a> 

                        <!-- Patient View -->
                        <a href="<?php 
                            echo esc_url(site_url('/patient-view-page/') . '?' . http_build_query([
                                'patient_id' => $encounter->patient_id,
                                'encounter_id' => $encounter->encounter_id
                            ])); ?>" 
                           class="pd-action view"
                           title="consultation pour patient">
                            <span class="dashicons dashicons-visibility"></span>
                        </a>

                        <!-- Bill Button 
                        <button class="pd-action bill" 
                                data-encounter="<?php echo esc_attr($encounter->encounter_id); ?>"
                                data-patient="<?php echo esc_attr($encounter->patient_id); ?>"
                                data-clinic="<?php echo esc_attr($encounter->clinic_id); ?>"
                                title="View Bill">
                            <span class="dashicons dashicons-money-alt"></span>
                        </button> -->

                        <!-- Invoice Button -->
                        <button class="pd-action invoice" 
                            data-encounter="<?php echo esc_attr($encounter->encounter_id); ?>"
                            data-patient="<?php echo esc_attr($encounter->patient_id); ?>"
                            data-clinic="<?php echo esc_attr($encounter->clinic_id); ?>"
                            data-nonce="<?php echo wp_create_nonce('pd-nonce'); ?>"
                            type="button"
                            title="Afficher et imprimer la facture">
                        <span class="dashicons dashicons-media-text"></span>
                        
                    </button>

                        <!-- Delete Button -->
                        <button class="pd-action delete" 
                                data-appointment="<?php echo esc_attr($encounter->appointment_id); ?>"
                                title="Supprimer">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </div>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
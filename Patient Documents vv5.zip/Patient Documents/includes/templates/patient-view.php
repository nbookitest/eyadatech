<?php if (!defined('ABSPATH')) exit;

// Verify parameters
$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
$encounter_id = isset($_GET['encounter_id']) ? intval($_GET['encounter_id']) : 0;

if (!$patient_id || !$encounter_id) {
    wp_die('Invalid parameters');
}

// Get specific encounter data
$encounter = $db->get_encounter_details($patient_id, $encounter_id); // Changed to include both IDs
if (!$encounter) {
    wp_die('Encounter not found');
}

// Get encounter-specific data
$full_encounter = $db->get_full_encounter_details($encounter_id);
$consultation = $db->get_consultation_details($encounter_id);
$prescriptions = $db->get_encounter_prescriptions($encounter_id);
$templates = $db->get_templates($type ?? 'certificate');
$encounters = $db->get_patient_encounters($patient_id);

// Debug log for encounter data
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log(sprintf(
        'Loading encounter data - Patient: %d, Encounter: %d',
        $patient_id,
        $encounter_id
    ));
    error_log('Encounter data: ' . print_r($encounter, true));
}

// Initialize pdData with specific encounter information
?>
<script type="text/javascript">
window.pdData = {
    ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
    nonce: '<?php echo wp_create_nonce('pd-nonce'); ?>',
    patient_id: <?php echo intval($patient_id); ?>,
    encounter_id: <?php echo intval($encounter_id); ?>,
    patient_name: '<?php echo esc_js($encounter->patient_name); ?>',
    doctor_name: '<?php echo esc_js($encounter->doctor_name); ?>',
    encounter_date: '<?php echo esc_js(date('Y-m-d', strtotime($encounter->encounter_date))); ?>',
    current_date: '<?php echo esc_js(date('Y-m-d')); ?>',
    debug: <?php echo defined('WP_DEBUG') && WP_DEBUG ? 'true' : 'false'; ?>
};

// Debug log
if (window.pdData.debug) {
    console.log('pdData initialized for encounter:', window.pdData);
}
</script>

<?php

wp_enqueue_style('pd-patient-view', PD_PLUGIN_URL . 'assets/css/patient-view.css');

// Fetch custom form data for the patient
$custom_fields = array();
if ($patient_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'kc_custom_fields_data';
    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT field_id, fields_data 
             FROM $table_name 
             WHERE module_id = %d AND field_id IN (1, 2, 3, 6, 8, 11)",
            $patient_id
        ),
        ARRAY_A
    );

    // Map field_id to form_data
    foreach ($results as $row) {
        $custom_fields[$row['field_id']] = maybe_unserialize($row['fields_data']);
    }
}
?>

<div class="patient-documents modal-view" 
     data-patient="<?php echo esc_attr($patient_id); ?>" 
     data-encounter="<?php echo esc_attr($encounter_id); ?>">
    
    <!-- Add encounter information display -->
  <div class="encounter-view" style="
    display: flex;
">
    <div class="encounter-info">
        <h3>Visite # <?php echo count($encounters); ?> </h3>
        <p>Date: <?php echo esc_html(date('F j, Y', strtotime($encounter->encounter_date))); ?></p>
    </div>
   <div class="button-view-profile">
    <button 
        class="pd-action profile" 
        onclick="window.open('<?php echo admin_url("/patient-profile/?patient_id={$encounter->patient_id}"); ?>', '_blank')"
        title="Vue de profil du patient"
    >
        <span class="dashicons dashicons-admin-users"></span> <!-- Icon -->
        voir toutes les informations pour ce patient <!-- Text -->
    </button>
</div>
    
    
    </div>

    <!-- Tab Navigation -->
    <div class="pd-tabs">
        <button class="tab-link active" data-tab="info">Consultation</button>
        <button class="tab-link" data-tab="prescriptions">Ordonnances</button>
        <button class="tab-link" data-tab="ultrasounds">Examen Radiologique</button>
        <button class="tab-link" data-tab="analyse-radio">Examen Biologique</button>
        <?php foreach (['certificate', 'letter', 'report'] as $type): ?>
            <button class="tab-link" data-tab="<?php echo esc_attr($type); ?>">
                <?php echo esc_html(ucfirst($type)); ?>
            </button>
        <?php endforeach; ?>
        <button class="tab-link" data-tab="medical-report">Rapport médical</button>
    </div>

    <!-- Get consultation data for this specific encounter -->
    <?php
    $consultation = $db->get_consultation_details($encounter_id);

    // Debug logging
    if(defined('WP_DEBUG') && WP_DEBUG) {
        error_log('Loading consultation for encounter: ' . $encounter_id);
        error_log('Consultation data: ' . print_r($consultation, true));
    }
    ?>

    <!-- Add this before the consultation form -->
    <script>
    var pdData = pdData || {};
    pdData.consultationData = <?php echo json_encode([
        'reason' => $consultation ? $consultation->reason : '',
        'background' => $consultation ? $consultation->background : '',
        'symptoms' => $consultation ? $consultation->symptoms : '',
        'current_treatment' => $consultation ? $consultation->current_treatment : '',
        'interrogation' => $consultation ? $consultation->interrogation : ''
    ]); ?>;
    </script>

    <!-- Consultation Tab Content -->
    <div id="info" class="pd-tab-content active">
        <!-- Basic Info -->
        <div class="patient-info mb-4">
            <h3>Informations destinées aux patients</h3>
            <div class="info-grid">
                <div class="info-row">
                    <label>Nom:</label>
                    <span><?php echo esc_html($encounter->patient_name); ?></span>
                </div>
                 <div class="info-row">
                    <label>CIN:</label>
                    <span><?php echo isset($custom_fields[1]) ? esc_html($custom_fields[1]) : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Phone:</label>
                    <span><?php echo esc_html($patient->phone); ?></span>
                </div>
                <div class="info-row">
                    <label>Genre:</label>
                    <span><?php echo esc_html(ucfirst($patient->gender)); ?></span>
                </div>
                <div class="info-row">
                    <label>Date de naissance:</label>
                    <span><?php 
                        echo $patient->dob ? date('F j, Y', strtotime($patient->dob)) : 'N/A';
                    ?></span>
                </div>
                <div class="info-row">
                    <label>Address:</label>
                    <span><?php echo esc_html($patient->address); ?></span>
                </div>
                <!--<div class="info-row">
                    <label>Ville:</label>
                    <span><?php echo esc_html($patient->city); ?></span>
                </div>-->
                <div class="info-row">
                    <label>Date:</label>
                    <span><?php echo date_i18n('M j, Y H:i', strtotime($encounter->date)); ?></span>
                </div>
                <?php if ($patient->encounter): ?>
                <div class="info-row">
                    <label>Doctor:</label>
                    <span><?php echo esc_html($patient->encounter->doctor_name); ?></span>
                </div>
                <div class="info-row">
                    <label>Clinic:</label>
                    <span><?php echo esc_html($patient->encounter->clinic_name); ?></span>
                </div>
                <div class="info-row">
                    <label>Last Visit:</label>
                    <span><?php echo date('F j, Y', strtotime($patient->encounter->encounter_date)); ?></span>
                </div>
                <?php endif; ?>
              
              <!-- Display Custom Fields --> 
               <div class="info-row">
                    <label>Mutuelle:</label>
                    <span><?php echo isset($custom_fields[2]) ? esc_html($custom_fields[2]) : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Situation:</label>
                    <span><?php echo isset($custom_fields[3]) ? esc_html($custom_fields[3]) : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Poids:</label>
                    <span><?php echo isset($custom_fields[6]) ? esc_html($custom_fields[6]) . ' kg' : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Taille:</label>
                    <span><?php echo isset($custom_fields[8]) ? esc_html($custom_fields[8]) . ' cm' : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Tension</label>
                    <span><?php echo isset($custom_fields[11]) ? esc_html($custom_fields[11]) . ' mmHg' : 'N/A'; ?></span>
                </div>
              
            </div>
        </div>


        <!-- Consultation Form -->
        <form id="consultation-form" class="consultation-form" method="post">
            <?php wp_nonce_field('pd-nonce'); ?>
            <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient_id); ?>">
            <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter_id); ?>">
            <?php 
            $fields = [
                'reason' => 'Motif de la consultation',
                'background' => 'Antécédents',
                'symptoms' => 'Symptmes',
                'current_treatment' => 'Traitement actuel',
                'interrogation' => 'Modèle d\'interrogatoire',
            ];
          
          // Group fields into pairs
        $field_pairs = array_chunk($fields, 5);

        foreach ($field_pairs as $pair): ?>
            <div class="field-pair">
            
          <?php  foreach ($fields as $field => $label): 
                $content = $consultation ? $consultation->$field : '';
            ?>
                <div class="consultation-field">
                    <h4><?php echo esc_html($label); ?></h4>
                    <?php 
                    wp_editor(
                        $content,
                        'editor_' . $field,
                        array(
                            'textarea_name' => 'data[' . $field . ']',
                            'textarea_rows' => 10,
                            'media_buttons' => true,
                            'teeny' => true,
                            'quicktags' => true,
                            'editor_class' => 'consultation-editor'
                          
                        )
                    );
                    ?>
                </div>
            <?php endforeach; ?>
              </div>
        <?php endforeach; ?>

            <div class="form-actions">
                <button type="submit" class="button button-primary">Enregistrer la consultation</button>
            </div>
        </form>
    </div>


    <!-- Prescriptions Tab -->
    <div id="prescriptions" class="pd-tab-content">
        <div class="prescriptions-form">
            <h3>Ajouter une ordonnance</h3>
            <form id="prescription-form">
                <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient_id); ?>">
                <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter_id); ?>">
                <input type="hidden" name="clinic_id" value="<?php echo esc_attr($encounter->clinic_id); ?>">
                <div class="prescription-grid">
                    <div class="form-field">
                        <label>Nom du médicament</label>
                        <select name="medication_name" class="medication-select" required>
                            <option value="">Sélectionnez ou saisissez le nom du médicament</option>
                            <?php 
                            $medications = $db->get_medications();
                            foreach ($medications as $med): ?>
                                <option value="<?php echo esc_attr($med->name); ?>">
                                    <?php echo esc_html($med->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-field">
                        <label>Dosage</label>
                        <select name="dosage" class="dosage-select" required>
                            <option value="">Sélectionnez ou saisissez le dosage</option>
                            <?php
                            $dosages = ['1cp', '2cp', '3cp', '1càc', '2càc', '3càc', '1càs', '2càs', '1sachet', '2sachets'];
                            foreach ($dosages as $dosage): ?>
                                <option value="<?php echo esc_attr($dosage); ?>"><?php echo esc_html($dosage); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-field">
                        <label>Frquence</label>
                        <select name="frequency" class="frequency-select" required>
                            <option value="">Sélectionnez ou saisissez la fréquence</option>
                            <?php
                            $frequencies = ['1fois/j', '2fois/j', '3fois/j', '4fois/j', 'Au coucher', 'Avant les repas', 'Après les repas'];
                            foreach ($frequencies as $freq): ?>
                                <option value="<?php echo esc_attr($freq); ?>"><?php echo esc_html($freq); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-field">
                        <label>Durée</label>
                        <select name="duration" class="duration-select" required>
                            <option value="">Sélectionnez ou saisissez la durée</option>
                            <?php
                            $durations = ['3 jours', '5 jours', '7 jours', '10 jours', '15 jours', '1 mois', '2 mois', '3 mois'];
                            foreach ($durations as $duration): ?>
                                <option value="<?php echo esc_attr($duration); ?>"><?php echo esc_html($duration); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-field">
                    <label>Instructions</label>
                    <textarea name="instructions" rows="3"></textarea>
                </div>
                <button type="submit" class="button button-primary">Ajouter un médicament</button>
            </form>
        </div>

        <div class="prescriptions-list">
            <h3>Ordonnance actuelles pour cette visite</h3>
            <?php 
            // Debug
            if(defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Loading prescriptions for encounter: ' . $encounter_id);
            }
            
            // Get prescriptions specifically for this encounter
            $encounter_prescriptions = $db->get_encounter_prescriptions($encounter_id);
            
            if(!empty($encounter_prescriptions)): ?>
                <table class="prescription-table">
                    <thead>
                        <tr>
                            <th>Médicament</th>
                            <th>Dosage</th>
                            <th>Fréquence</th>
                            <th>Durée</th>
                            <th>Instructions</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($encounter_prescriptions as $prescription): ?>
                            <tr>
                                <td><?php echo esc_html($prescription->medication_name); ?></td>
                                <td><?php echo esc_html($prescription->dosage); ?></td>
                                <td><?php echo esc_html($prescription->frequency); ?></td>
                                <td><?php echo esc_html($prescription->duration); ?></td>
                                <td><?php echo esc_html($prescription->instructions); ?></td>
                                <td>
                                    <button class="button delete-prescription" 
                                            data-id="<?php echo esc_attr($prescription->id); ?>">
                                            Supprimer
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="prescription-actions">
                    <button class="button print-all-prescriptions" 
                            data-encounter="<?php echo esc_attr($encounter_id); ?>">
                            Imprimer
                    </button>
                </div>
            <?php else: ?>
                <p class="no-prescriptions">Aucune prescription n'a ét ajoutée pour cette visite pour le moment.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- After Prescriptions Tab Content -->
    <div id="ultrasounds" class="pd-tab-content">
        <div class="ultrasound-form">
            <h3>Ajouter un Examen Radiologique</h3>
            <form id="ultrasound-form">
                <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient_id); ?>">
                <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter_id); ?>">
                
                <div class="form-field">
                    <label>Type d'Examen Radiologique</label>
                    <select name="ultrasound_id" class="ultrasound-select" required>
                        <option value="">Sélectionnez ou saisissez le type d'Examen Radiologique</option>
                        <?php 
                        $ultrasounds = $db->get_ultrasounds();
                        foreach ($ultrasounds as $us): ?>
                            <option value="<?php echo esc_attr($us->id); ?>">
                                <?php echo esc_html($us->name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="button button-primary">Ajouter</button>
            </form>
        </div>

        <div class="ultrasounds-list">
            <h3>Examen Radiologique</h3>
            <?php 
            $patient_ultrasounds = $db->get_patient_ultrasounds($encounter_id);
            if (!empty($patient_ultrasounds)): ?>
                <table class="ultrasound-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patient_ultrasounds as $us): ?>
                            <tr>
                                <td><?php echo esc_html($us->ultrasound_name); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($us->created_at)); ?></td>
                                <td>
                                    <button class="button delete-ultrasound" 
                                            data-id="<?php echo esc_attr($us->id); ?>">
                                        Supprimer
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="ultrasound-actions">
                    <button class="button print-all-ultrasounds" 
                            data-encounter="<?php echo esc_attr($encounter_id); ?>">
                        Imprimer
                    </button>
                </div>
            <?php else: ?>
                <p class="no-ultrasounds">Aucune Examen Radiologique n'a été demandée pour cette visite.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- After Ultrasounds Tab Content -->
    <div id="analyse-radio" class="pd-tab-content">
        <div class="analyse-radio-form">
            <h3>Ajouter un Examen Biologique</h3>
            <form id="analyse-radio-form">
                <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient_id); ?>">
                <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter_id); ?>">
                
                <div class="form-field">
                    <label>Type d'Examen Biologique</label>
                    <select name="analyse_radio_id" class="analyse-radio-select" required>
                        <option value="">Sélectionnez ou saisissez le type d'Examen Biologique</option>
                        <?php 
                        $analyse_radios = $db->get_analyse_radio();
                        foreach ($analyse_radios as $ar): ?>
                            <option value="<?php echo esc_attr($ar->id); ?>">
                                <?php echo esc_html($ar->name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="button button-primary">Ajouter</button>
            </form>
        </div>

        <div class="analyse-radio-list">
            <h3>Examen Biologique demandées</h3>
            <?php 
            $patient_analyse_radios = $db->get_patient_analyse_radio($encounter_id);
            if (!empty($patient_analyse_radios)): ?>
                <table class="analyse-radio-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Date de demande</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patient_analyse_radios as $ar): ?>
                            <tr>
                                <td><?php echo esc_html($ar->analyse_radio_name); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($ar->created_at)); ?></td>
                                <td>
                                    <button class="button delete-analyse-radio" 
                                            data-id="<?php echo esc_attr($ar->id); ?>">
                                        Supprimer
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="analyse-radio-actions">
                    <button class="button print-all-analyse-radio" 
                            data-encounter="<?php echo esc_attr($encounter_id); ?>">
                        Imprimer
                    </button>
                </div>
            <?php else: ?>
                <p class="no-analyse-radio">Aucune Examen Biologique n'a été demandée pour cette visite.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Document Type Tabs -->
    <?php foreach (['certificate', 'letter', 'report'] as $type): ?>
    <div id="<?php echo esc_attr($type); ?>" class="pd-tab-content">
        <div class="document-wrapper" 
             data-patient="<?php echo esc_attr($patient_id); ?>" 
             data-encounter="<?php echo esc_attr($encounter_id); ?>">
            <div class="template-manager">
                <select class="template-selector" data-type="<?php echo esc_attr($type); ?>">
                    <option value="">Select a template</option>
                    <?php 
                    $templates = $db->get_templates($type);
                    foreach ($templates as $template): ?>
                        <option value="<?php echo esc_attr($template->id); ?>">
                            <?php echo esc_html($template->template_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button class="save-as-template button" data-type="<?php echo esc_attr($type); ?>">
                    Save as Template
                </button>
            </div>

            <!-- Editor and actions -->
            <div class="editor-wrapper">
                <?php 
                wp_editor('', 'editor_' . $type, [
                    'textarea_name' => 'content_' . $type,
                    'media_buttons' => true,
                    'textarea_rows' => 15,
                    'editor_class' => 'pd-document-editor',
                    'quicktags' => true,
                    'tinymce' => true
                ]);
                ?>
            </div>
            
            <div class="document-actions">
                <button class="save-document button button-primary" data-type="<?php echo esc_attr($type); ?>">
                Sauvegarder <?php echo esc_html(ucfirst($type)); ?>
                </button>
                <button class="print-document button" data-type="<?php echo esc_attr($type); ?>">
                Imprimer <?php echo esc_html(ucfirst($type)); ?>
                </button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <div id="medical-report" class="pd-tab-content">
    <div class="driver-license-header">
        <h3>Rapport médical</h3>
        <div class="patient-info-summary">
        <div class="info-row">
                    <label>Nom du patient:</label>
                    <span><?php echo esc_html($encounter->patient_name); ?></span>
                </div>
                <div class="info-row">
                    <label>CIN:</label>
                    <span><?php echo isset($custom_fields[1]) ? esc_html($custom_fields[1]) : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <label>Phone:</label>
                    <span><?php echo esc_html($patient->phone); ?></span>
                </div>
                <div class="info-row">
                    <label>Date:</label>
                    <span><?php echo date('F j, Y'); ?></span>
                </div>
        </div>
    </div>

    <div class="file-upload-section">
        <h4>Télécharger des rapports médicaux</h4>
        <form id="medical-report-form" enctype="multipart/form-data">
            <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient_id); ?>">
            <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter_id); ?>">
            
            <div class="file-input-wrapper">
                <input type="file" name="medical_report" id="medical-report-input" 
                       accept=".pdf,.png" required>
                <p class="file-help">Formats acceptés : PDF, PNG</p>
            </div>

            <div class="uploaded-files">
                <h4>Fichiers tléchargés</h4>
                <div class="files-list">
                    <?php
                    $reports = $db->get_medical_reports($patient_id);
                    if (!empty($reports)): ?>
                        <table class="reports-table">
                            <thead>
                                <tr>
                                    <th>Nom de fichier</th>
                                    <th>Type</th>
                                    <th>Téléchargé par</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $report): ?>
                                    <tr>
                                        <td><?php echo esc_html($report->file_name); ?></td>
                                        <td><?php echo esc_html(strtoupper($report->file_type)); ?></td>
                                        <td><?php echo esc_html($report->uploaded_by_name); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($report->created_at)); ?></td>
                                        <td>
                                            <a href="<?php echo esc_url($report->file_path); ?>" 
                                               class="button" target="_blank">
                                               Télcharger
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="no-files">Aucun fichier n'a encore été téléchargé.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="button button-primary">Enregistrer le rapport</button>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
// Only keep patient view specific initialization
document.addEventListener('DOMContentLoaded', function() {
    if (typeof pdData === 'undefined') {
        console.error('Patient View: pdData not initialized correctly');
    }
});
</script>

</div>


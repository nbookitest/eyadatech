<div class="wrap">
    <h1>Document Templates</h1>
    
    <?php
    $types = ['certificate', 'letter', 'report'];
    $db = PD_Database::get_instance();
    
    foreach ($types as $type) : 
        $templates = $db->get_templates($type);
    ?>
        <div class="template-type-section">
            <h2><?php echo ucfirst($type); ?> Templates</h2>
            
            <ul class="template-list">
                <?php foreach ($templates as $template) : ?>
                    <li>
                        <strong><?php echo esc_html($template->template_name); ?></strong>
                        <small><?php echo date('M j, Y', strtotime($template->created_at)); ?></small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endforeach; ?>
</div>
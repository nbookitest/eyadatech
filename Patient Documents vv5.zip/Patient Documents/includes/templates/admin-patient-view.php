<div class="wrap">
    <h1>Patient Details</h1>
    
    <!-- Patient Info Section -->
    <div class="patient-info-section">
        <h2>Patient Information</h2>
        <div class="info-grid">
            <div class="info-row">
                <label>Name:</label>
                <span><?php echo esc_html($patient->display_name); ?></span>
            </div>
            <div class="info-row">
                <label>Phone:</label>
                <span><?php echo esc_html(get_user_meta($patient->ID, 'phone', true)); ?></span>
            </div>
            <div class="info-row">
                <label>Email:</label>
                <span><?php echo esc_html($patient->user_email); ?></span>
            </div>
            <div class="info-row">
                <label>Gender:</label>
                <span><?php echo esc_html(get_user_meta($patient->ID, 'gender', true)); ?></span>
            </div>
            <div class="info-row">
                <label>Date of Birth:</label>
                <span><?php 
                    $dob = get_user_meta($patient->ID, 'dob', true);
                    echo $dob ? date('F j, Y', strtotime($dob)) : 'N/A';
                ?></span>
            </div>
            <div class="info-row">
                <label>Age:</label>
                <span><?php 
                    if ($dob) {
                        $age = date_diff(date_create($dob), date_create('today'))->y;
                        echo $age . ' years';
                    } else {
                        echo 'N/A';
                    }
                ?></span>
            </div>
            <div class="info-row">
                <label>Registration Date:</label>
                <span><?php echo date('F j, Y', strtotime($patient->user_registered)); ?></span>
            </div>
        </div>
    </div>

    <!-- Tabs Section -->
    <div class="pd-tabs-wrapper">
        <?php include PD_PLUGIN_PATH . 'includes/templates/patient-view-tabs.php'; ?>
    </div>
</div>

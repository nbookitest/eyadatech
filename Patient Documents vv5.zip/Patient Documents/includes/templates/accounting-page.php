<?php if (!defined('ABSPATH')) exit; ?>

<div class="pd-accounting-page">
    <!-- Page Header -->
    <div class="pd-page-header">
        <h2>Comptabilité</h2>
        <div class="pd-header-actions">
            <button class="pd-button add-new">
                <span class="dashicons dashicons-plus-alt"></span>
                Nouvelle facture
            </button>
            <button class="pd-button print">
                <span class="dashicons dashicons-printer"></span>
                Imprimer
            </button>
        </div>
    </div>

    <!-- Table Container -->
    <div class="pd-table-container">
        <table class="pd-accounting-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>N° de Facture</th>
                    <th>Bénéficiaire</th>
                    <th>Mode de Règlement</th>
                    <th>N° Rglement</th>
                    <th>Montant</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data will be loaded dynamically via JavaScript -->
            </tbody>
        </table>
    </div>

    <!-- Total Display -->
    <div class="pd-total-display">
        <strong>Total:</strong>
        <span class="total-amount">0.00</span> MAD
    </div>
</div>

<!-- Add/Edit Form Modal -->
<div class="pd-modal" id="accounting-form-modal">
    <div class="pd-modal-content">
        <button class="pd-modal-close">&times;</button>
        <h3 class="pd-modal-title">Add New Facture</h3>
        
        <form id="accounting-form">
            <div class="form-row">
                <label for="date">Date</label>
                <input type="date" id="date" name="date" required>
            </div>
            
            <div class="form-row">
                <label for="invoice_number">N° de Facture</label>
                <input type="text" id="invoice_number" name="invoice_number" required>
            </div>
            
            <div class="form-row">
                <label for="beneficiary">Bénéficiaire</label>
                <input type="text" id="beneficiary" name="beneficiary" required>
            </div>
            
            <div class="form-row">
                <label for="payment_method">Mode de Règlement</label>
                <select id="payment_method" name="payment_method" required>
                    <option value="">Mode de paiement</option>
                    <option value="cash">Espèces</option>
                    <option value="check">Chèque</option>
                    <option value="bank_transfer">Virement</option>
                </select>
            </div>
            
            <div class="form-row">
                <label for="payment_reference">N° Règlement</label>
                <input type="text" id="payment_reference" name="payment_reference">
            </div>
            
            <div class="form-row">
                <label for="amount">Montant</label>
                <input type="number" id="amount" name="amount" step="0.01" required>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="pd-button save">Enregistrer</button>
                <button type="button" class="pd-button cancel">Annuler</button>
            </div>
        </form>
    </div>
</div>

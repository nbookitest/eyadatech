<?php if (!defined('ABSPATH')) exit; ?>

<div class="driver-license-report-container">
    <div class="report-header">
        <h2>Rapport médical pour permis de conduire</h2>
        
        <div class="report-actions">
            <button id="add-new-record" class="button button-primary">
                <span class="dashicons dashicons-plus"></span> Nouveau rapport
            </button>
            <button id="print-records" class="button">
                <span class="dashicons dashicons-printer"></span> Imprimer
            </button>
        </div>
        
        <div class="report-filters">
            <div class="search-box">
                <input type="text" id="search-records" placeholder="Rechercher par nom, CIN...">
            </div>
            
            <div class="date-filter-box">
                <select id="date-filter">
                    <option value="all">Toutes les dates</option>
                    <option value="today">Aujourd'hui</option>
                    <option value="week">Cette semaine</option>
                    <option value="month">Ce mois</option>
                    <option value="year">Cette année</option>
                    <option value="custom">Plage personnalisée</option>
                </select>
            
                <div class="custom-date-range" style="display: none;">
                    <input type="date" id="date-from">
                    <span>à</span>
                    <input type="date" id="date-to">
                </div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th width="10%">Numéro d'ordre</th>
                    <th width="15%">Date</th>
                    <th width="20%">Nom</th>
                    <th width="15%">CIN</th>
                    <th width="10%">Type de permis</th>
                    <th width="15%">Intéresser</th>
                    <th width="15%">Actions</th>
                </tr>
            </thead>
            <tbody id="records-list">
                <!-- Dynamic content will be loaded here -->
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Record Modal -->
<div id="record-modal" class="pd-modal">
    <div class="pd-modal-content">
        <span class="pd-modal-close">&times;</span>
        <h3 id="modal-title">Nouveau rapport médical</h3>
        
        <form id="record-form">
            <input type="hidden" name="record_id" id="record_id">
            
            <div class="form-row">
                <label for="order_number">Numéro d'ordre</label>
                <input type="text" name="order_number" id="order_number" required>
            </div>
            
            <div class="form-row">
                <label for="date">Date</label>
                <input type="date" name="date" id="date" required>
            </div>
            
            <div class="form-row">
                <label for="patient_name">Nom du patient</label>
                <input type="text" name="patient_name" id="patient_name" required>
            </div>
            
            <div class="form-row">
                <label for="cin">CIN</label>
                <input type="text" name="cin" id="cin" required>
            </div>
            
            <div class="form-row">
                <label for="license_type">Type de permis</label>
                <select name="license_type" id="license_type" required>
                    <option value="">Sélectionner le type</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                    <option value="E">E</option>
                </select>
            </div>

            <div class="form-row">
                <label for="interest_status">Intéresser</label>
                <select name="interest_status" id="interest_status" required>
                    <option value="">Sélectionner le statut</option>
                    <option value="APTE">APTE</option>
                    <option value="INAPTE">INAPTE</option>
                    <option value="APTE_SANS_RESTRICTION">APTE AVEC RESTRICTION</option>
                </select>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="button button-primary">Enregistrer</button>
                <button type="button" class="button cancel-modal">Annuler</button>
            </div>
        </form>
    </div>
</div>

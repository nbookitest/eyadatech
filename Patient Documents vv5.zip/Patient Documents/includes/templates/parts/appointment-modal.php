<div class="pd-modal" id="appointment-modal" style="display:none;">
    <div class="pd-modal-content">
        <span class="close">&times;</span>
        <h3>Ajouter un rendez-vous</h3>
        <form id="appointment-form">
            <?php wp_nonce_field('pd-receptionist-nonce'); ?>
            
            <div class="form-row">
                <label>Nom du patient:</label>
                <input type="text" name="patient_name" required>
            </div>
            
            <div class="form-row">
                <label>Informations complémentaires:</label>
                <textarea name="more_info"></textarea>
            </div>
            
            <div class="form-row">
                <label>Date de prise de contact:</label>
                <input type="datetime-local" name="appointment_date" required>
            </div>
            
            <div class="form-row">
                <label>Date du rendez-vous:</label>
                <input type="date" name="next_appointment" required>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="button button-primary">Enregistrer</button>
            </div>
        </form>
    </div>
</div>
<div id="prescriptions" class="pd-tab-content">
    <div class="prescriptions-form">
        <h3>Add Prescription</h3>
        
        <!-- Template Selector -->
        <div class="template-section">
            <select class="prescription-template">
                <option value="">Select Template</option>
                <?php foreach ($prescription_templates as $template): ?>
                    <option value="<?php echo esc_attr($template->id); ?>">
                        <?php echo esc_html($template->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button class="save-as-template button">Save Current as Template</button>
        </div>

        <form id="prescription-form">
            <input type="hidden" name="patient_id" value="<?php echo esc_attr($patient->ID); ?>">
            <input type="hidden" name="encounter_id" value="<?php echo esc_attr($encounter->id); ?>">
            
            <div class="prescription-grid">
                <div class="form-field">
                    <label>Medication Name</label>
                    <input type="text" name="medication_name" required>
                </div>
                <div class="form-field">
                    <label>Dosage</label>
                    <input type="text" name="dosage" required>
                </div>
                <div class="form-field">
                    <label>Frequency</label>
                    <input type="text" name="frequency" required>
                </div>
                <div class="form-field">
                    <label>Duration</label>
                    <input type="text" name="duration" required>
                </div>
            </div>
            
            <div class="form-field">
                <label>Instructions</label>
                <textarea name="instructions" rows="3"></textarea>
            </div>
            
            <button type="submit" class="button button-primary">Add Medication</button>
        </form>
    </div>

    <div class="prescriptions-list">
        <h3>Current Prescriptions</h3>
        <?php if(!empty($prescriptions)): ?>
            <div class="prescription-actions">
                <button class="print-all-prescriptions button">
                    Print All Prescriptions
                </button>
            </div>
            
            <table class="prescription-table">
                <thead>
                    <tr>
                        <th>Medication</th>
                        <th>Dosage</th>
                        <th>Frequency</th>
                        <th>Duration</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($prescriptions as $prescription): ?>
                        <tr>
                            <td><?php echo esc_html($prescription->medication_name); ?></td>
                            <td><?php echo esc_html($prescription->dosage); ?></td>
                            <td><?php echo esc_html($prescription->frequency); ?></td>
                            <td><?php echo esc_html($prescription->duration); ?></td>
                            <td><?php echo date('M j, Y', strtotime($prescription->created_at)); ?></td>
                            <td>
                                <button class="print-prescription button" 
                                        data-id="<?php echo esc_attr($prescription->id); ?>">
                                    Print
                                </button>
                                <button class="delete-prescription button" 
                                        data-id="<?php echo esc_attr($prescription->id); ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-prescriptions">No prescriptions added yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php
/**
 * Plugin Shortcode Reference Page
 */
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Plugin Shortcode Reference</h1>
        <p>This page lists all the available shortcodes provided by the plugin. You can copy and use these shortcodes on any WordPress page or post.</p>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Shortcode</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Define the shortcodes and their descriptions
                $shortcodes = [
                    '[receptionist_dashboard]' => 'Displays the appointment dashboard for receptionists.',
                    '[accounting_page]' => 'Provides access to the accounting page.',
                    '[generate_documents]' => 'Allows users to generate documents.',
                    '[driver_license_report]' => 'Generates a report for driver licenses.',
                    '[encounter_list_v2]' => 'Displays the updated list of patient encounters.',
                    '[patient_profile]' => 'Shows the profile of a specific patient.',
                    '[patient_view]' => 'Displays detailed information about a patient.',
                    '[pd_patients_list]' => 'Lists all patients in the system.',
                ];

                // Loop through the shortcodes and display them in the table
                foreach ($shortcodes as $shortcode => $description) {
                    echo '<tr>';
                    echo '<td><code>' . esc_html($shortcode) . '</code></td>';
                    echo '<td>' . esc_html($description) . '</td>';
                    echo '<td><button class="button copy-shortcode" data-shortcode="' . esc_attr($shortcode) . '">Copy</button></td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Add event listeners to copy buttons
            const copyButtons = document.querySelectorAll('.copy-shortcode');
            copyButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const shortcode = this.getAttribute('data-shortcode');
                    navigator.clipboard.writeText(shortcode).then(() => {
                        this.textContent = 'Copied!';
                        setTimeout(() => {
                            this.textContent = 'Copy';
                        }, 2000);
                    }).catch(err => {
                        console.error('Failed to copy text: ', err);
                    });
                });
            });
        });
    </script>
    <?php


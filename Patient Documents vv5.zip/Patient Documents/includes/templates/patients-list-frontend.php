<?php
if (!defined('ABSPATH')) exit;

// Debugging
if (defined('WP_DEBUG') && WP_DEBUG) {
    echo '<!-- Debug Info:';
    foreach ($patients as $patient) {
        echo "\n Patient ID: {$patient->ID}";
        echo "\n Display Name: {$patient->display_name}";
        echo "\n CIN: {$patient->cin}";
        echo "\n Phone: {$patient->phone}";
        echo "\n Basic Data: " . print_r($patient->basic_data, true);
        echo "\n ----";
    }
    echo ' -->';
}

// Get search parameters
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;

// Get database instance
$db = PD_Database::get_instance();
$patients = $db->get_patients_list($search, $page, $per_page);
$total_patients = $db->get_total_patients($search);
$total_pages = ceil($total_patients / $per_page);
?>

<div class="pd-patients-list-frontend">
    <div class="pd-patients-header">
        <h2>Liste des patients</h2>
        <form method="get" class="pd-search-form">
            <div class="pd-search-box">
                <?php 
                // Preserve existing query parameters
                foreach ($_GET as $key => $value) {
                    if ($key !== 'search' && $key !== 'paged') {
                        echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
                    }
                }
                ?>
                <input type="search" name="search" 
                       value="<?php echo esc_attr($search); ?>" 
                       placeholder="Search patients..."
                       class="pd-search-input">
                <button type="submit" class="pd-search-button">Search</button>
            </div>
        </form>
    </div>

    <!-- Add a summary of total patients -->
    <div class="pd-patients-summary">
        <p>Nombre total de patients : <?php echo esc_html($total_patients); ?></p>
    </div>

    <!-- Patients Table -->
    <div class="pd-table-container">
        <table class="pd-patients-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>CIN</th>
                    <th>Mobile</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($patients)) : ?>
                    <?php foreach ($patients as $patient) : ?>
                        <tr>
                            <td><?php echo esc_html($patient->ID); ?></td>
                            <td><?php echo esc_html($patient->display_name); ?></td>
                            <td><?php echo esc_html($patient->cin); ?></td>
                            <td><?php echo esc_html($patient->phone); ?></td>
                            <td class="pd-actions">
                                <a href="<?php echo admin_url("/admin.php?page=dashboard#/patient/edit/{$patient->ID}"); ?>" 
                                   class="pd-action edit" 
                                   target="_blank"
                                   title="Edit Patient">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>

                                <a href="<?php echo admin_url("/patient-profile/?patient_id={$patient->ID}"); ?>" 
                                   class="pd-action profile" 
                                   target="_blank"
                                   title="View Profile">
                                    <span class="dashicons dashicons-admin-users"></span>
                                </a>

                                <a href="<?php echo admin_url("/admin.php?page=dashboard#/patient-appointment-list/{$patient->ID}"); ?>" 
                                   class="pd-action appointments" 
                                   target="_blank"
                                   title="View Appointments">
                                    <span class="dashicons dashicons-calendar-alt"></span>
                                </a>

                                <a href="<?php echo admin_url("/patient-profile/?patient_id={$patient->ID}&tab=documents"); ?>" 
                                   class="pd-action documents" 
                                   title="View Documents">
                                    <span class="dashicons dashicons-media-default"></span>
                                </a>

                                <?php if (current_user_can('manage_options')) : ?>
                                    <a href="#" 
                                       class="pd-action delete" 
                                       data-id="<?php echo esc_attr($patient->ID); ?>"
                                       title="Delete Patient">
                                        <span class="dashicons dashicons-trash"></span>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">Aucun patient trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1) : ?>
        <div class="pd-pagination">
            <?php
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $page,
                'type' => 'list'
            ]);
            ?>
        </div>
    <?php endif; ?>
</div>

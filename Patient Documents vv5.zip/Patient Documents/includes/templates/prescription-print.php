<div class="prescription-print">
    <div class="clinic-header">
        <h1><?php echo esc_html($clinic->name); ?></h1>
        <p><?php echo esc_html($clinic->address); ?></p>
        <p>Tel: <?php echo esc_html($clinic->phone); ?></p>
    </div>
    
    <div class="doctor-info">
        <p>Dr. <?php echo esc_html($doctor->display_name); ?></p>
        <p><?php echo esc_html($doctor_meta['specialty'] ?? ''); ?></p>
    </div>

    <div class="prescription-date">
        <p>Date: <?php echo date('F j, Y'); ?></p>
    </div>

    <div class="patient-info">
        <p>Patient: <?php echo esc_html($patient->display_name); ?></p>
        <p>Age: <?php echo esc_html($patient_age); ?> years</p>
    </div>

    <div class="prescription-content">
        <h3>Rx</h3>
        <div class="medication-details">
            <p class="medication">
                <?php echo esc_html($prescription->medication_name); ?>
            </p>
            <p class="dosage">
                <?php echo esc_html($prescription->dosage); ?>
            </p>
            <p class="instructions">
                <?php echo esc_html($prescription->frequency); ?>
                <?php echo esc_html($prescription->duration); ?>
            </p>
            <?php if ($prescription->instructions): ?>
                <p class="additional-instructions">
                    <?php echo nl2br(esc_html($prescription->instructions)); ?>
                </p>
            <?php endif; ?>
        </div>
    </div>

    <div class="prescription-footer">
        <div class="doctor-signature">
            <p>Doctor's Signature: _________________</p>
        </div>
        <div class="prescription-notes">
            <p>This prescription is valid for 30 days from the date of issue.</p>
        </div>
    </div>
</div>

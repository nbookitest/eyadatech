<?php
if (!defined('ABSPATH')) exit;

if(!current_user_can('edit_posts')) {
    echo '<p class="invoice-error">' . esc_html__('Access denied', 'textdomain') . '</p>';
    return;
}

$encounter_id = isset($_POST['encounter_id']) ? intval($_POST['encounter_id']) : 0;
$invoice = $db->get_bill_details($encounter_id);

function convert_number_to_french_text($number) {
    $units = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf"];
    $tens = ["", "dix", "vingt", "trente", "quarante", "cinquante", "soixante", "soixante-dix", "quatre-vingt", "quatre-vingt-dix"];
    $teens = ["dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf"];
    
    if ($number < 10) return $units[$number];
    if ($number < 20) return $teens[$number - 10];
    if ($number < 100) {
        $unit = $number % 10;
        $ten = ($number - $unit) / 10;
        return $tens[$ten] . ($unit > 0 ? "-" . $units[$unit] : "");
    }
    
    return $number; // For numbers >= 100, return the number itself
}
?>

<div class="kc-invoice-modal">
    <div class="invoice-content">
        <?php if (!$invoice): ?>
            <div class="no-invoice">
                <h3><?php esc_html_e('No Invoice Found', 'textdomain'); ?></h3>
                <p><?php esc_html_e('No invoice information found for this encounter.', 'textdomain'); ?></p>
            </div>
        <?php else: ?>
            <div class="invoice-wrapper">
                <!-- Header -->
                <div class="invoice-header">
                    <h1 class="invoice-title">FACTURE</h1>
                </div>

                <!-- Amount Statement -->
                <div class="amount-statement">
                    <?php 
                        $amount_in_text = convert_number_to_french_text($invoice->final_total);
                    ?>
                    <p class="statement-text">
                        A arrêté la présente facture à la somme de 
                        <strong><?php echo number_format($invoice->final_total, 2); ?> Dh</strong>
                        (<?php echo ucfirst($amount_in_text); ?> dirhams)
                        en faveur de Mr/Mme <strong><?php echo esc_html($invoice->patient_name); ?></strong>.
                    </p>
                </div>

                <!-- Footer with Signature -->
                <div class="invoice-footer">
                    <div class="signature-section">
                        <p class="date-line">
                            Fait à Temera, le <?php echo date_i18n('d/m/Y'); ?>
                        </p>
                        <p class="doctor-name">
                            Dr. <?php echo esc_html($invoice->doctor_name); ?>
                        </p>
                        <div class="signature-line">
                            Signature et cachet
                        </div>
                    </div>
                </div>
            </div>

            <!-- Print Button -->
            <div class="invoice-actions">
                <button class="button print-invoice">Imprimer Facture</button>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .kc-invoice-modal {
        padding: 20px;
        background: white;
    }

    .invoice-wrapper {
        max-width: 950px;
        margin: 0 auto;
        padding: 20px;
    }

    .invoice-header {
        text-align: center;
        margin-bottom: 40px;
    }

    .invoice-title {
        font-size: 32px;
        font-weight: bold;
        margin: 30px 0;
        text-decoration: underline;
        text-align: center;
        color: #000;
    }

    .invoice-meta {
        margin-top: 20px;
        text-align: right;
    }

    .invoice-meta p {
        margin: 5px 0;
    }

    .amount-statement {
        margin: 60px 0;
        padding: 20px;
        font-size: 18px;
        line-height: 1.8;
    }

    .statement-text {
        text-align: justify;
        margin: 0;
    }

    .invoice-footer {
        margin-top: 30px;
        padding-top: 20px;
    }

    .signature-section {
        float: right;
        text-align: center;
        margin-right: 50px;
    }

    .date-line {
        margin-bottom: 20px;
    }

    .doctor-name {
        margin-bottom: 40px;
        font-weight: bold;
    }

    .signature-line {
        border-top: 1px solid #000;
        padding-top: 10px;
        font-style: italic;
        width: 200px;
    }

    .invoice-actions {
        clear: both;
        padding-top: 20px;
        text-align: center;
    }

    /* Print Styles */
    @media print {
        @page {
            margin: 2cm;
            size: A4;
        }

        body {
            background: white;
        }

        .kc-invoice-modal {
            padding: 0;
            background: white;
            position: relative;
            display: block;
            width: 100%;
            height: auto;
        }

        .invoice-wrapper {
            padding: 0;
        }

        .invoice-content {
            box-shadow: none;
            border: none;
        }

        .invoice-header {
            margin-bottom: 4cm;
        }

        .invoice-title {
            margin: 2cm 0;
        }

        .amount-statement {
            margin: 3cm 0;
        }

        .invoice-footer {
            margin-top: 4cm;
            break-inside: avoid;
        }

        .signature-section {
            margin-right: 0;
        }

        .invoice-actions {
            display: none;
        }

        /* Hide all other page elements */
        body > *:not(.kc-invoice-modal) {
            display: none;
        }
    }
</style>

<div class="bill-popup-content">
    <?php
    if (!defined('ABSPATH')) exit;
    
    if(!current_user_can('edit_posts')) {
        echo '<p class="bill-error">' . esc_html__('Access denied', 'textdomain') . '</p>';
        return;
    }

    $db = PD_Database::get_instance();
    $encounter_id = isset($_POST['encounter_id']) ? intval($_POST['encounter_id']) : 0;
    $bill = $db->get_bill_details($encounter_id);
    
    if (!$bill) : ?>
        <div class="bill-not-found">
            <h3><?php esc_html_e('No Bill Found', 'textdomain'); ?></h3>
            <p><?php esc_html_e('No billing information found for this encounter.', 'textdomain'); ?></p>
            <?php if (WP_DEBUG) : ?>
                <p class="debug-info">Encounter ID: <?php echo esc_html($encounter_id); ?><br>
                    Error: <?php echo esc_html($db->get_last_error()); ?>
                </p>
            <?php endif; ?>
        </div>
    <?php else : ?>
        <div class="bill-details">
            <div class="bill-header">
                <div class="clinic-info">
                    <h2><?php echo esc_html($bill->clinic_name); ?></h2>
                    <p><?php echo esc_html($bill->clinic_address); ?></p>
                </div>
                <div class="bill-meta">
                    <p><strong><?php esc_html_e('Bill #:', 'textdomain'); ?></strong> <?php echo esc_html($bill->id); ?></p>
                    <p><strong><?php esc_html_e('Date:', 'textdomain'); ?></strong> <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($bill->created_at))); ?></p>
                </div>
            </div>

            <div class="patient-info">
                <p><strong><?php esc_html_e('Patient:', 'textdomain'); ?></strong> <?php echo esc_html($bill->patient_name); ?></p>
            </div>

            <table class="bill-items">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Service', 'textdomain'); ?></th>
                        <th><?php esc_html_e('Price', 'textdomain'); ?></th>
                        <th><?php esc_html_e('Quantity', 'textdomain'); ?></th>
                        <th><?php esc_html_e('Total', 'textdomain'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bill->items as $item) : ?>
                        <tr>
                            <td><?php echo esc_html($item->service_name); ?></td>
                            <td><?php echo esc_html(number_format($item->price, 2)); ?></td>
                            <td><?php echo esc_html($item->qty); ?></td>
                            <td><?php echo esc_html(number_format($item->price * $item->qty, 2)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong><?php esc_html_e('Subtotal:', 'textdomain'); ?></strong></td>
                        <td><strong><?php echo esc_html(number_format($bill->total_amount, 2)); ?></strong></td>
                    </tr>
                    <?php if (!empty($bill->taxes)): ?>
                        <?php foreach ($bill->taxes as $tax): ?>
                            <tr>
                                <td colspan="3"><?php echo esc_html($tax['name']); ?> 
                                    (<?php echo esc_html($tax['value'] . ($tax['type'] === 'percentage' ? '%' : '')); ?>)
                                </td>
                                <td><?php echo esc_html(number_format($tax['amount'], 2)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="3"><strong><?php esc_html_e('Tax Total:', 'textdomain'); ?></strong></td>
                            <td><strong><?php echo esc_html(number_format($bill->tax_total, 2)); ?></strong></td>
                        </tr>
                    <?php endif; ?>
                    <?php if ($bill->discount > 0): ?>
                        <tr>
                            <td colspan="3"><?php esc_html_e('Discount:', 'textdomain'); ?></td>
                            <td><?php echo esc_html(number_format($bill->discount, 2)); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="3"><strong><?php esc_html_e('Final Total:', 'textdomain'); ?></strong></td>
                        <td><strong><?php echo esc_html(number_format($bill->final_total, 2)); ?></strong></td>
                    </tr>
                </tfoot>
            </table>

            <div class="bill-footer">
                <p class="payment-status">
                    <strong><?php esc_html_e('Payment Status:', 'textdomain'); ?></strong>
                    <span class="status-<?php echo esc_attr(strtolower($bill->payment_status)); ?>">
                        <?php echo esc_html($bill->payment_status); ?>
                    </span>
                </p>
            </div>
        </div>
    <?php endif; ?>
</div>
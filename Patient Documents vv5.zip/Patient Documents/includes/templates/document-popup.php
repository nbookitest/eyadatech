<?php
if (!defined('ABSPATH')) exit;

$type = sanitize_text_field($_POST['type']);
$templates = $db->get_templates($type);
?>
<div class="document-popup-content">
    <div class="document-header">
        <h2><?php echo ucfirst($type); ?></h2>
        <div class="patient-info">
            <p><strong>Patient:</strong> <?php echo esc_html($patient->display_name); ?></p>
            <p><strong>Date:</strong> <?php echo date_i18n(get_option('date_format')); ?></p>
        </div>
    </div>

    <div class="template-manager">
        <select class="template-selector" data-type="<?php echo esc_attr($type); ?>">
            <option value="">Select Template</option>
            <?php foreach ($templates as $template): ?>
                <option value="<?php echo esc_attr($template->id); ?>">
                    <?php echo esc_html($template->template_name); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button class="save-as-template button" data-type="<?php echo esc_attr($type); ?>">
            Save Current as Template
        </button>
    </div>

    <div class="editor-wrapper">
        <textarea id="document-editor" 
                class="document-editor" 
                data-type="<?php echo esc_attr($type); ?>"><?php 
            echo $document ? esc_textarea($document->content) : '';
        ?></textarea>
    </div>

    <div class="document-actions">
        <button class="button save-document" data-type="<?php echo esc_attr($type); ?>">
            Save <?php echo ucfirst($type); ?>
        </button>
        <button class="button print-document" data-type="<?php echo esc_attr($type); ?>">
            Print <?php echo ucfirst($type); ?>
        </button>
    </div>
</div>

<?php 
if (!defined('ABSPATH')) exit;

// Debug output
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Rendering receptionist dashboard template');
}
?>

<div class="pd-receptionist-dashboard">
    <!-- Top Actions Bar -->
    <div class="dashboard-actions">
        <div class="view-toggles">
            <button class="view-toggle <?php echo $view === 'calendar' ? 'active' : ''; ?>" data-view="calendar">
                <span class="dashicons dashicons-calendar-alt"></span> Affichage du calendrier
            </button>
            <button class="view-toggle <?php echo $view === 'grid' ? 'active' : ''; ?>" data-view="grid">
                <span class="dashicons dashicons-grid-view"></span> Affichage en grille
            </button>
        </div>

        <div class="main-actions">
            <a href="https://doctor.tasweermedia.com/wp-admin/admin.php?page=dashboard#/patient/create" class="button add-patient">
            <span class="dashicons dashicons-plus"></span> Ajouter un nouveau patient
            </a>
                <button class="button add-appointment" id="open-appointment-modal">
                <span class="dashicons dashicons-calendar"></span> Ajouter un rendez-vous
                </button>
          <!--  <button class="button add-appointment">
                <a href="https://doctor.tasweermedia.com/wp-admin/admin.php?page=dashboard#/all-appointment-list">
                <span class="dashicons dashicons-calendar"></span> Ajouter un rendez-vous
                </a>
            </button> 
        </div>

        <div class="filters">
            <input type="text" 
                   id="patient-search" 
                   placeholder="Rechercher par nom ou détails du patient...">
        </div> -->

        <div class="results-count"></div>
    </div>

    <!-- Calendar/Grid View Container -->
    <div class="view-container <?php echo esc_attr($view); ?>-view">
        <?php if ($view === 'calendar'): ?>
            <div class="calendar-navigation">
                <button class="prev-month">&lt;</button>
                <h2 class="current-month"></h2>
                <button class="next-month">&gt;</button>
            </div>
            <div class="calendar-grid"></div>
        <?php else: ?>
            <div class="appointments-grid"></div>
        <?php endif; ?>
    </div>

    <?php include PD_PLUGIN_PATH . 'includes/templates/parts/appointment-modal.php'; ?>
</div>

<!-- Add appointment modal -->
<div class="pd-modal" id="appointment-modal" style="display:none;">
    <!-- Modal content here -->
</div>

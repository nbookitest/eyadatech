<?php if (!defined('ABSPATH')) exit; ?>

<div class="pd-documents-wrapper">
    <div class="pd-documents-tabs">
        <button class="tab-link active" data-tab="certificate">Certificates</button>
        <button class="tab-link" data-tab="letter">Letters</button>
        <button class="tab-link" data-tab="report">Compte Rendu</button>
    </div>

    <?php foreach (['certificate', 'letter', 'report'] as $type): ?>
    <div id="<?php echo esc_attr($type); ?>" class="pd-tab-content <?php echo $type === 'certificate' ? 'active' : ''; ?>">
        <div class="template-controls">
            <select class="template-selector" data-type="<?php echo esc_attr($type); ?>">
                <option value="">Sélectionnez un modèle</option>
                <?php 
                $templates = pd_get_templates($type);
                foreach ($templates as $template): ?>
                    <option value="<?php echo esc_attr($template->id); ?>">
                        <?php echo esc_html($template->template_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button class="button save-as-template" data-type="<?php echo esc_attr($type); ?>">
            Enregistrer comme modèle
            </button>
        </div>

      <!--  <div class="placeholder-values">
            <h4>Document Values</h4>
            <div class="placeholder-fields">
                <div class="field-row">
                    <label>Name:</label>
                    <input type="text" class="placeholder-input" data-placeholder="name">
                </div>
                <div class="field-row">
                    <label>Date:</label>
                    <input type="date" class="placeholder-input" data-placeholder="date" 
                           value="<?php echo date('Y-m-d'); ?>">
                </div>
                
            </div>
        </div> -->

        <div class="editor-wrapper">
            <?php 
            wp_editor('', 'editor_' . $type, [
                'textarea_name' => 'content_' . $type,
                'media_buttons' => true,
                'textarea_rows' => 15,
                'editor_class' => 'pd-document-editor',
                'editor_css' => '<style>.wp-editor-area { height: 400px; }</style>'
            ]);
            ?>
        </div>

        <div class="document-actions">
          <!--  <button class="button preview-document" data-type="<?php echo esc_attr($type); ?>">
                Preview
            </button> -->
            <button class="button button-primary generate-document" data-type="<?php echo esc_attr($type); ?>">
            Imprimer
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Preview Modal -->
<div class="pd-modal" style="display:none;">
    <div class="pd-modal-content">
        <span class="pd-modal-close">&times;</span>
        <div class="pd-modal-body"></div>
    </div>
</div>

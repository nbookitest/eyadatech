jQuery(document).ready(function($) {
    // Filter encounters
    $('#filter-encounters').on('click', function() {
        const status = $('#status-filter').val();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'filter_encounters',
                status: status,
                nonce: pd_admin.nonce
            },
            success: function(response) {
                $('#encounters-list').html(response.data.html);
            }
        });
    });

    // Action handlers
// Update action handlers with proper nonces
$('.encounters-table').on('click', '.edit-patient', function() {
    const id = $(this).data('id');
    window.location.href = ajaxurl + `?action=edit_patient&id=${id}&_wpnonce=${pd_admin.nonce}`;
});

$('.encounters-table').on('click', '.view-patient', function() {
    const id = $(this).data('id');
    window.location.href = ajaxurl + `?action=view_patient&id=${id}&_wpnonce=${pd_admin.nonce}`;
});

$('.encounters-table').on('click', '.bill-details', function() {
    const id = $(this).data('id');
    window.location.href = ajaxurl + `?action=bill_details&id=${id}&_wpnonce=${pd_admin.nonce}`;
});
    $('.encounters-table').on('click', '.delete-patient', function() {
        if(!confirm('Are you sure you want to delete this encounter?')) return;
        
        const row = $(this).closest('tr');
        const id = $(this).data('id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_encounter',
                appointment_id: id,
                nonce: pd_admin.nonce
            },
            success: function() {
                row.fadeOut();
            }
        });
    });
});
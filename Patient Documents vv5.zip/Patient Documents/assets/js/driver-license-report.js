jQuery(document).ready(function($) {
    const ajaxUrl = pd_driver_license.ajaxurl;
    const nonce = pd_driver_license.nonce;
    const $tableBody = $('#records-list');
    let isLoading = false;

    // Show loading indicator
    function showLoading() {
        if (!isLoading) {
            isLoading = true;
            $('.loader').show(); // Add a loader element in your HTML
        }
    }

    // Hide loading indicator
    function hideLoading() {
        if (isLoading) {
            isLoading = false;
            $('.loader').hide();
        }
    }

    // Load records on page load
    loadRecords();

    // Add new record button click
    $('#add-new-record').on('click', function() {
        resetModal();
        $('#modal-title').text('Nouveau rapport médical');
        $('#record-modal').addClass('active');
    });

    // Close modal
    $('.pd-modal-close, .cancel-modal').on('click', function() {
        $('#record-modal').removeClass('active');
    });

    // Handle form submission
    $('#record-form').on('submit', function(e) {
        e.preventDefault();

        // Validate form fields
        const formData = {
            action: 'pd_save_driver_license_record',
            nonce: nonce,
            id: $('#record_id').val(), // Include the ID in the form data
            order_number: $('#order_number').val(),
            date: $('#date').val(),
            patient_name: $('#patient_name').val(),
            cin: $('#cin').val(),
            license_type: $('#license_type').val(),
            interest_status: $('#interest_status').val()
        };

        // Validate required fields
        for (let key in formData) {
            if (!formData[key] && key !== 'id') {
                alert(`Veuillez remplir tous les champs obligatoires (${key})`);
                return;
            }
        }

        showLoading();
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: formData,
            success: function(response) {
                hideLoading();
                if (response.success) {
                    alert(response.data.message);
                    $('#record-modal').removeClass('active');
                    loadRecords();
                } else {
                    alert(response.data.message || 'Échec de l\'enregistrement');
                }
            },
            error: function(xhr, status, error) {
                hideLoading();
                console.error('Erreur Ajax:', { xhr, status, error });
                alert('Une erreur réseau est survenue. Veuillez réessayer.');
            }
        });
    });

    // Edit record button click
    $(document).on('click', '.edit-record', function() {
        const id = $(this).data('id');
        showLoading();
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'pd_get_driver_license_record',
                nonce: nonce,
                id: id
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    populateModal(response.data);
                    $('#modal-title').text('Modifier le rapport médical');
                    $('#record-modal').addClass('active');
                } else {
                    alert(response.data.message || 'Échec de la récupération du rapport');
                }
            }
        });
    });

    // Delete record button click
    $(document).on('click', '.delete-record', function() {
        if (!confirm('Êtes-vous sûr de vouloir supprimer ce rapport ?')) {
            return;
        }
        const id = $(this).data('id');
        showLoading();
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'pd_delete_driver_license_record',
                nonce: nonce,
                id: id
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    loadRecords();
                } else {
                    alert(response.data.message || 'Échec de la suppression du rapport');
                }
            }
        });
    });

    // Print button click
    $('#print-records').on('click', function() {
        const printContent = $('.driver-license-report-container').clone();
        printContent.find('.report-actions, .report-filters').remove();
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Rapports médicaux pour permis de conduire</title>
                <style>
                    body { font-family: Arial, sans-serif; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { padding: 8px; border: 1px solid #ddd; }
                    th { background-color: #f5f5f5; }
                    @media print {
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                ${printContent.html()}
                <script>
                    window.onload = function() { 
                        window.print();
                        window.onfocus = function() { window.close(); }
                    }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    });

    // Date filter change
    $('#date-filter').on('change', function() {
        $('.custom-date-range').toggle($(this).val() === 'custom');
        loadRecords();
    });

    // Search input keyup
    $('#search-records').on('keyup', function() {
        loadRecords();
    });

    // Custom date range change
    $('.custom-date-range input').on('change', function() {
        const dateFrom = $('#date-from').val();
        const dateTo = $('#date-to').val();

        if (dateFrom > dateTo) {
            alert('La date "de" ne peut pas être postérieure à la date "à".');
            return;
        }

        loadRecords();
    });

    // Load records function
    function loadRecords() {
        const search = $('#search-records').val();
        const dateFilter = $('#date-filter').val();
        const dateFrom = $('#date-from').val();
        const dateTo = $('#date-to').val();

        showLoading();
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'pd_get_driver_license_records',
                nonce: nonce,
                search: search,
                date_filter: dateFilter,
                date_from: dateFrom,
                date_to: dateTo
            },
            success: function(response) {
                hideLoading();
                if (response.success) {
                    renderTable(response.data);
                }
            }
        });
    }

    // Render table function
    function renderTable(data) {
        $tableBody.empty();
        data.forEach(item => {
            $tableBody.append(`
                <tr>
                    <td>${item.order_number}</td>
                    <td>${item.date}</td>
                    <td>${item.patient_name}</td>
                    <td>${item.cin}</td>
                    <td>${item.license_type}</td>
                    <td>${item.interest_status}</td>
                    <td>
                        <button class="button edit-record" data-id="${item.id}">
                            <span class="dashicons dashicons-edit"></span>
                        </button>
                        <button class="button delete-record" data-id="${item.id}">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </td>
                </tr>
            `);
        });
    }

    // Populate modal with record data
    function populateModal(record) {
        $('#record_id').val(record.id); // Include the ID in the modal
        $('#order_number').val(record.order_number);
        $('#date').val(record.date);
        $('#patient_name').val(record.patient_name);
        $('#cin').val(record.cin);
        $('#license_type').val(record.license_type);
        $('#interest_status').val(record.interest_status);
    }

    // Reset modal fields
    function resetModal() {
        $('#record-form')[0].reset();
        $('#record_id').val(''); // Clear the ID field for new records
    }
});
jQuery(document).ready(function($) {
    const editors = {};
    let editorsInitialized = false;
    
    // Initialize editors after TinyMCE is fully loaded
    function initializeEditors() {
        if (typeof tinyMCE === 'undefined') {
            console.error('TinyMCE not loaded');
            return;
        }

        ['certificate', 'letter', 'report'].forEach(type => {
            const editorId = 'editor_' + type;
            
            // Remove existing editor if any
            if (tinyMCE.get(editorId)) {
                tinyMCE.execCommand('mceRemoveEditor', false, editorId);
            }

            // Initialize new editor with minimal plugins
            tinyMCE.init({
                selector: '#' + editorId,
                height: 400,
                plugins: [
                    'lists link image table paste'
                ],
                toolbar: 'undo redo | formatselect | bold italic | ' +
                        'alignleft aligncenter alignright alignjustify | ' +
                        'bullist numlist | link image | table',
                menubar: false,
                statusbar: true,
                browser_spellcheck: true,
                contextmenu: false,
                paste_as_text: true,
                relative_urls: false,
                remove_script_host: false,
                convert_urls: true,
                setup: function(editor) {
                    editors[type] = editor;
                    editor.on('init', function() {
                        console.log('Editor initialized:', type);
                        editorsInitialized = true;
                        
                        // Set default content if editor is empty
                        if (!editor.getContent()) {
                            editor.setContent(getDefaultTemplate(type));
                        }
                    });
                }
            });
        });
    }

    // Helper function to get default template content
    function getDefaultTemplate(type) {
        const defaults = {
            certificate: `
                <div class="clinic-letter">
                    <h2>Medical Certificate</h2>
                    <p>Name: {name}</p>
                    <p>Date: {date}</p>
                    <div class="content"></div>
                    <div class="signature">
                        <p>Doctor's Signature: _________________</p>
                    </div>
                </div>
            `,
            letter: `
                <div class="clinic-letter">
                    <p>Date: {date}</p>
                    <p>Dear Sir/Madam,</p>
                    <p>Re: {name}</p>
                    <div class="content"></div>
                    <p>Sincerely,</p>
                    <p>Dr. _________________</p>
                </div>
            `,
            report: `
                <div class="clinic-letter">
                    <h2>Medical Report</h2>
                    <p>Patient: {name}</p>
                    <p>Date: {date}</p>
                    <div class="content"></div>
                    <div class="signature">
                        <p>Physician's Signature: _________________</p>
                        <p>Date: {date}</p>
                    </div>
                </div>
            `
        };
        return defaults[type] || '';
    }

    // Initialize editors on page load
    initializeEditors();

    // Template selection handler
    $('.template-selector').on('change', function() {
        const type = $(this).data('type');
        const templateId = $(this).val();
        
        if (!templateId) return;
        
        if (!editors[type] || !editors[type].initialized) {
            console.error('Editor not initialized for:', type);
            alert('Editor not ready. Please try again in a moment.');
            return;
        }

        // Show loading state
        editors[type].setContent('<p>Chargement du modèle...</p>');
        
        $.ajax({
            url: pdDocuments.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_template',
                nonce: pdDocuments.nonce,
                template_id: templateId,
                type: type
            },
            success: function(response) {
                console.log('Template load response:', response);
                if (response.success && response.data && response.data.content) {
                    editors[type].setContent(response.data.content);
                } else {
                    console.error('Template load error:', response);
                    alert('Error loading template: ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Impossible de charger le modèle. Veuillez réessayer.');
            }
        });
        // Debug log
console.log('Nonce passed in AJAX request:', pdDocuments.nonce);
    });

    // Save template handler
    $('.save-as-template').on('click', function() {
        const type = $(this).data('type');
        
        if (!editors[type] || !editors[type].initialized) {
            alert('L\'éditeur n\'est pas prêt. Veuillez réessayer dans un instant.');
            return;
        }

        const name = prompt('Entrez le nom du modèle :');
        if (!name) return;

        const content = editors[type].getContent();
        if (!content) {
            alert('Veuillez ajouter du contenu avant d\'enregistrer le modèle');
            return;
        }

        // Show loading state
        $(this).prop('disabled', true);
        
        $.ajax({
            url: pdDocuments.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_save_template',
                nonce: pdDocuments.nonce,
                type: type,
                name: name,
                content: content
            },
            success: function(response) {
                console.log('Save template response:', response);
                if (response.success) {
                    alert('Modèle enregistré avec succès');
                    location.reload(); // Refresh to update template list
                } else {
                    alert('Error saving template: ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Save template error:', {xhr, status, error});
                alert('Impossible d\'enregistrer le modèle. Veuillez réessayer.');
            },
            complete: function() {
                $('.save-as-template').prop('disabled', false);
            }
        });
    });

    // Tab switching with editor initialization check
    $('.pd-documents-tabs .tab-link').on('click', function() {
        const tab = $(this).data('tab');
        
        $('.tab-link, .pd-tab-content').removeClass('active');
        $(this).addClass('active');
        $('#' + tab).addClass('active');

        // Ensure editor is initialized for the active tab
        if (['certificate', 'letter', 'report'].includes(tab)) {
            if (!editors[tab] || !editors[tab].initialized) {
                console.log('Reinitializing editor for:', tab);
                initializeEditors();
            }
        }
    });

    // Preview document
    $('.preview-document').on('click', function() {
        const type = $(this).data('type');
        const content = replacePlaceholders(editors[type].getContent());
        
        showPreviewModal(content);
    });

    // Generate PDF
    $('.generate-document').on('click', function() {
        const type = $(this).data('type');
        const content = replacePlaceholders(editors[type].getContent());
        
        generatePDF(content);
    });

    // Helper functions
    function replacePlaceholders(content) {
        const values = {};
        $('.placeholder-input').each(function() {
            values[$(this).data('placeholder')] = $(this).val();
        });
        
        return content.replace(/\{([^}]+)\}/g, function(match, key) {
            return values[key] || match;
        });
    }

    function replaceTemplatePlaceholders(content) {
        const values = {};
        $('.placeholder-input').each(function() {
            values[$(this).data('placeholder')] = $(this).val();
        });
        
        // Default values if not set
        values.name = values.name || '[Name]';
        values.date = values.date || new Date().toLocaleDateString();
        
        return content.replace(/\{([^}]+)\}/g, function(match, key) {
            return values[key] || match;
        });
    }

    // Update placeholder values in real-time
    $('.placeholder-input').on('input', function() {
        const type = $('.tab-link.active').data('tab');
        const editor = editors[type];
        if (editor) {
            const content = editor.getContent();
            editor.setContent(replaceTemplatePlaceholders(content));
        }
    });

    function showPreviewModal(content) {
        $('.pd-modal-body').html(content);
        $('.pd-modal').show();
    }

    function generatePDF(content) {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Document</title>
                <style>
                    body { font-family: Arial; padding: 20px; }
                    @media print {
                        @page { margin: 2cm; }
                    }
                </style>
            </head>
            <body>
                ${content}
                <script>
                    window.onload = function() {
                        window.print();
                        window.onfocus = function() { window.close(); }
                    }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }

    // Modal close
    $('.pd-modal-close').on('click', function() {
        $('.pd-modal').hide();
    });
});

jQuery(document).ready(function($) {
    let editors = {};

    // Only keep modal code for bill and invoice
    function showModal(content) {
        $('.pd-modal').remove();
        
        const modalHTML = `
            <div class="pd-modal">
                <div class="pd-modal-content">
                    <button class="pd-modal-close">&times;</button>
                    <div class="pd-modal-body">${content}</div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Show modal with animation
        requestAnimationFrame(() => {
            $('.pd-modal').addClass('active');
        });

        // Add close handlers
        $('.pd-modal-close, .pd-modal').on('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    }

    function closeModal() {
        const $modal = $('.pd-modal');
        $modal.removeClass('active');
        setTimeout(() => $modal.remove(), 300);
    }

    // Bill handler
    $(document).on('click', '.pd-action.bill', function(e) {
        e.preventDefault();
        const data = {
            encounter_id: $(this).data('encounter'),
            patient_id: $(this).data('patient'),
            clinic_id: $(this).data('clinic')
        };
        
        showModal('<div class="loading">Loading bill details...</div>');
        
        $.ajax({
            url: pdEncounterData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_bill_details_v2',
                ...data,
                nonce: pdEncounterData.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('.pd-modal-body').html(response.data.html);
                } else {
                    $('.pd-modal-body').html(`
                        <div class="error">
                            <h3>Error Loading Bill</h3>
                            <p>${response.data?.message || 'Unknown error occurred'}</p>
                            <button class="button" onclick="closeModal()">Close</button>
                        </div>
                    `);
                }
            }
        });
    });

    // Invoice handler
    $(document).on('click', '.pd-action.invoice', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const $button = $(this);
        const data = {
            action: 'pd_get_invoice_v2',
            encounter_id: $button.data('encounter'),
            patient_id: $button.data('patient'),
            clinic_id: $button.data('clinic'),
            nonce: $button.data('nonce') // Get nonce from button data attribute
        };
        
        // Debug logging
        console.log('Invoice request data:', data);
        
        showModal('<div class="loading">Chargement des détails de la facture...</div>');
        
        $.ajax({
            url: pdEncounterData.ajaxurl,
            type: 'POST',
            data: data,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', data.nonce);
            },
            success: function(response) {
                console.log('Invoice response:', response);
                if (response.success) {
                    $('.pd-modal-body').html(response.data.html);
                } else {
                    $('.pd-modal-body').html(`
                        <div class="error">
                            <h3>Erreur lors du chargement de la facture</h3>
                            <p>${response.data?.message || 'Unknown error occurred'}</p>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('Invoice AJAX error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    error: error
                });
                $('.pd-modal-body').html(`
                    <div class="error">
                        <h3>Error Loading Invoice</h3>
                        <p>Failed to load invoice. Please try again.</p>
                        <p>Status: ${xhr.status} ${xhr.statusText}</p>
                        <p>Error: ${error}</p>
                    </div>
                `);
            }
        });
    });

    // Delete handler
    $(document).on('click', '.pd-action.delete', function(e) {
        e.preventDefault();
        if (!confirm('Etes-vous sûr de vouloir supprimer cette rencontre ?')) return;

        const appointmentId = $(this).data('appointment');
        
        $.ajax({
            url: pdEncounterData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_delete_encounter_v2',
                appointment_id: appointmentId,
                nonce: pdEncounterData.nonce
            },
            success: function(response) {
                if (response.success) {
                    $(`tr[data-appointment="${appointmentId}"]`).fadeOut(300, function() {
                        $(this).remove();
                    });
                }
            }
        });
    });

    // Filter handler
    $('.status-filter').on('change', function() {
        const status = $(this).val();
        
        $.ajax({
            url: pdEncounterData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_filter_encounters_v2',
                status: status,
                nonce: pdEncounterData.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('.pd-encounter-table tbody').html(response.data.html);
                }
            }
        });
    });

    // Print handler
    $(document).on('click', '.print-invoice', function(e) {
        e.preventDefault();
        const invoiceContent = $('.kc-invoice-modal').clone();
        
        // Remove action buttons from print view
        invoiceContent.find('.invoice-actions').remove();
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Invoice</title>
                <link rel="stylesheet" href="${pdEncounterData.printCss}">
                <style>
                    body { font-family: Arial, sans-serif; }
                    .kc-invoice-modal { padding: 20px; }
                    .invoice-header { margin-bottom: 30px; }
                    .invoice-items { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    .invoice-items th, .invoice-items td { padding: 8px; border: 1px solid #ddd; }
                    .text-right { text-align: right; }
                    .text-center { text-align: center; }
                    .clinic-info { text-align: center; }
                    .invoice-title { font-size: 30px; margin-bottom: 10px; text-align: center; }
                    .invoice-footer { margin-top: 30px; padding-top: 20px; float: right; }
                    .amount-statement {
          					  margin: 3cm 1cm;
        				}
                    @media print {
                        .invoice-actions { display: none; }
                        @page { margin: 0.5cm; }
                    }
                </style>
            </head>
            <body>
                ${invoiceContent.html()}
                <script>
                    window.onload = function() { 
                        window.print();
                        window.onafterprint = function() {
                            window.close();
                        }
                    }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    });

    // Add filter handling
    $(document).ready(function() {
        // Date filter change handler
        $('#date-filter').on('change', function() {
            const isCustom = $(this).val() === 'custom';
            $('.custom-date-range').toggle(isCustom);
        });

        // Search functionality with debounce
        let searchTimeout;
        $('#encounter-search').on('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                applyFilters();
            }, 500);
        });

        // Filter button click
        $('.pd-filter-button').on('click', function() {
            applyFilters();
        });

        function applyFilters() {
            const $container = $('.pd-encounter-list-container');
            const search = $('#encounter-search').val();
            const dateFilter = $('#date-filter').val();
            const dateFrom = $('#date-from').val();
            const dateTo = $('#date-to').val();
            const status = $('.status-filter').val();

            // Show loading state
            $container.addClass('loading');
            
            // Clear any existing error messages
            $('.notice-error').remove();

            $.ajax({
                url: pdEncounterData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'pd_filter_encounters_v2',
                    nonce: pdEncounterData.nonce,
                    search: search,
                    date_filter: dateFilter,
                    date_from: dateFrom,
                    date_to: dateTo,
                    status: status
                },
                success: function(response) {
                    if (response.success) {
                        const $tbody = $('.pd-encounter-table tbody');
                        
                        // Update table content with fade effect
                        $tbody.fadeOut(200, function() {
                            $tbody.html(response.data.html).fadeIn(200, function() {
                                // Reattach event handlers to new elements
                                attachActionHandlers();
                            });
                            
                            // Update results count
                            $('.results-count').text(
                                response.data.count + ' encounter' + 
                                (response.data.count !== 1 ? 's' : '') + ' found'
                            );
                        });
                    } else {
                        showError(response.data.message || 'Impossible d\'appliquer les filtres');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Filter request failed:', {xhr, status, error});
                    showError('Une erreur réseau s\'est produite');
                },
                complete: function() {
                    $container.removeClass('loading');
                }
            });
        }

        // Add function to reattach event handlers
        function reattachEventHandlers() {
            // Bill handler
            $('.pd-action.bill').off('click').on('click', function(e) {
                e.preventDefault();
                handleBillClick($(this));
            });

            // Invoice handler
            $('.pd-action.invoice').off('click').on('click', function(e) {
                e.preventDefault();
                handleInvoiceClick($(this));
            });

            // Delete handler
            $('.pd-action.delete').off('click').on('click', function(e) {
                e.preventDefault();
                handleDeleteClick($(this));
            });
        }

        // Add helper function to update URL parameters
        function updateUrlParameters(params) {
            const urlParams = new URLSearchParams(window.location.search);
            Object.entries(params).forEach(([key, value]) => {
                if (value) {
                    urlParams.set(key, value);
                } else {
                    urlParams.delete(key);
                }
            });
            window.history.replaceState({}, '', `${window.location.pathname}?${urlParams}`);
        }

        // Add error display function
        function showError(message) {
            const $error = $('<div class="notice notice-error is-dismissible"></div>')
                .text(message)
                .append('<button type="button" class="notice-dismiss"></button>');
            
            $('.pd-encounter-list-container').prepend($error);
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                $error.fadeOut(300, function() { $(this).remove(); });
            }, 5000);
            
            // Allow manual dismiss
            $error.find('.notice-dismiss').on('click', function() {
                $error.fadeOut(300, function() { $(this).remove(); });
            });
        }
    });

    // Add this function to handle action button events
    function attachActionHandlers() {
        // Invoice handler
        $('.pd-action.invoice').off('click').on('click', function(e) {
            e.preventDefault();
            const data = {
                encounter_id: $(this).data('encounter'),
                patient_id: $(this).data('patient'),
                clinic_id: $(this).data('clinic')
            };
            
            showModal('<div class="loading">Chargement des détails de la facture...</div>');
            
            $.ajax({
                url: pdEncounterData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'pd_get_invoice_v2',
                    ...data,
                    nonce: pdEncounterData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('.pd-modal-body').html(response.data.html);
                    } else {
                        $('.pd-modal-body').html(`
                            <div class="error">
                                <h3>Erreur lors du chargement de la facture</h3>
                                <p>${response.data?.message || 'Unknown error occurred'}</p>
                            </div>
                        `);
                    }
                }
            });
        });

        // Delete handler
        $('.pd-action.delete').off('click').on('click', function(e) {
            e.preventDefault();
            if (!confirm('Etes-vous sûr de vouloir supprimer cette rencontre ?')) return;

            const appointmentId = $(this).data('appointment');
            
            $.ajax({
                url: pdEncounterData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'pd_delete_encounter_v2',
                    appointment_id: appointmentId,
                    nonce: pdEncounterData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $(`tr[data-appointment="${appointmentId}"]`).fadeOut(300, function() {
                            $(this).remove();
                        });
                    }
                }
            });
        });
    }

    // Call attachActionHandlers on page load
    $(document).ready(function() {
        attachActionHandlers();
        // Initialize custom date range visibility
        $('.custom-date-range').toggle($('#date-filter').val() === 'custom');
        
        // Date filter change
        $('#date-filter').on('change', function() {
            $('.custom-date-range').toggle($(this).val() === 'custom');
            if ($(this).val() !== 'custom') {
                applyFilters();
            }
        });

        // Search with debounce
        let searchTimeout;
        $('#encounter-search').on('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(applyFilters, 500);
        });

        // Custom date range changes
        $('.custom-date-range input').on('change', function() {
            if ($('#date-from').val() && $('#date-to').val()) {
                applyFilters();
            }
        });

        // Status filter change
        $('.status-filter').on('change', function() {
            applyFilters();
        });

        // Filter button click
        $('.pd-filter-button').on('click', applyFilters);
    });
});
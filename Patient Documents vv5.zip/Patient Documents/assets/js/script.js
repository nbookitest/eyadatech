jQuery(document).ready(function($) {
    // Ensure pdData exists and is properly initialized
    if (typeof window.pdData === 'undefined') {
        console.error('pdData not initialized!');
        window.pdData = {
            debug: true,
            ajaxurl: typeof ajaxurl !== 'undefined' ? ajaxurl : '',
            nonce: '',
            patient_id: 0,
            encounter_id: 0
        };
    }

    // Debug logging
    console.log('Current pdData:', window.pdData);

    const editors = {};
    const initializedEditors = {};

    // Initialize TinyMCE editors with proper timing
    function initializeEditor(type) {
        const editorId = `editor_${type}`;
        
        // Remove existing editor if any
        if (tinyMCE.get(editorId)) {
            tinyMCE.execCommand('mceRemoveEditor', false, editorId);
        }

        // Initialize new editor
        tinyMCE.init({
            selector: `#${editorId}`,
            height: 400,
            plugins: [
                'lists link image charmap print anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code'
            ],
            toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image',
            setup: function(editor) {
                editors[type] = editor;
                editor.on('init', function() {
                    console.log(`Editor initialized for ${type}`);
                    
                    // Load default template if no content
                    if (!editor.getContent() && pdData?.defaultTemplates?.[type]) {
                        const content = replaceTemplatePlaceholders(pdData.defaultTemplates[type]);
                        editor.setContent(content);
                    }
                });
            }
        });
    }

    // Initialize editors when tab is clicked
    $('.tab-link').on('click', function() {
        const type = $(this).data('tab');
        $('.tab-link, .pd-tab-content').removeClass('active');
        $(this).addClass('active');
        $(`#${type}`).addClass('active');

        if (['certificate', 'letter', 'report'].includes(type)) {
            if (!editors[type] || !editors[type].initialized) {
                initializeEditor(type);
            }
        }
    });

    // Initialize editor for active tab on page load
    const activeType = $('.tab-link.active').data('tab');
    if (['certificate', 'letter', 'report'].includes(activeType)) {
        initializeEditor(activeType);
    }

    // Template selection handler
    $('.template-selector').on('change', function() {
        const type = $(this).data('type');
        const templateId = $(this).val();
        const editor = editors[type];
        
        if (!templateId || !editor) {
            console.error('Sélection de modèle non valide ou éditeur non prêt.');
            return;
        }

        // Show loading indicator
        editor.setProgressState(true);
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_template',
                nonce: pdData.nonce,
                template_id: templateId
            },
            success: function(response) {
                if (response.success && response.data?.content) {
                    editor.setContent(replaceTemplatePlaceholders(response.data.content));
                } else {
                    console.error('Template load failed:', response);
                    alert('Échec du chargement du modèle : ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s est produite. Veuillez réessayer.');
            },
            complete: function() {
                editor.setProgressState(false);
            }
        });

        // Debug log
    console.log('Nonce passed in AJAX request:', pdData.nonce);
    });

    // Save template handler
    $('.save-as-template').on('click', function() {
        const type = $(this).data('type');
        const editor = editors[type];
        
        if (!editor || !editor.initialized) {
            alert('L éditeur n est pas prêt. Veuillez réessayer dans un instant.');
            return;
        }

        const name = prompt('Entrez le nom du modèle :');
        if (!name) return;

        const content = editor.getContent();
        if (!content) {
            alert('Veuillez ajouter du contenu avant d enregistrer le modèle');
            return;
        }

        // Show loading state
        const $button = $(this);
        $button.prop('disabled', true).text('Saving...');

        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_save_template',
                nonce: pdData.nonce,
                type: type,
                name: name,
                content: content
            },
            success: function(response) {
                if (response.success) {
                    alert('Modèle enregistré avec succès');
                    // Refresh template list
                    location.reload();
                } else {
                    alert('Erreur lors de l enregistrement du modèle : ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Save template error:', {xhr, status, error});
                alert('Une erreur réseau s est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Enregistrer comme modèle');
            }
        });
    });

    // Helper function to replace placeholders
    function replaceTemplatePlaceholders(content) {
        if (!content) return '';

        return content.replace(/\{([^}]+)\}/g, function(match, key) {
            switch(key) {
                case 'patient_name': return pdData.patient_name || '[Patient Name]';
                case 'doctor_name': return pdData.doctor_name || '[Doctor Name]';
                case 'current_date': return pdData.current_date || new Date().toLocaleDateString();
                case 'encounter_date': return pdData.encounter_date || '[Encounter Date]';
                default: return match;
            }
        });
    }

    // Document save handler with fixed variable declarations
    $('.save-document').on('click', function() {
        const type = $(this).data('type');
        const editor = tinyMCE.get('editor_' + type);
        
        // Debug log
        console.log('Save attempt:', {
            type: type,
            editor: editor ? 'initialized' : 'not initialized',
            pdData: window.pdData
        });

        if (!editor) {
            alert('Editor not initialized!');
            return;
        }

        // Get IDs from multiple sources
        let patientId = window.pdData?.patient_id;
        let encounterId = window.pdData?.encounter_id;

        // If not in pdData, try getting from DOM
        if (!patientId || !encounterId) {
            const $wrapper = $(editor.getContainer()).closest('.document-wrapper');
            patientId = $wrapper.data('patient');
            encounterId = $wrapper.data('encounter');
        }

        // Final check for required IDs
        if (!patientId || !encounterId) {
            console.error('Missing required data:', {
                patient_id: patientId,
                encounter_id: encounterId,
                pdData: window.pdData
            });
            alert('Erreur : certaines informations obligatoires sont manquantes. Veuillez actualiser la page et réessayer.');
            return;
        }

        const content = editor.getContent();
        if (!content.trim()) {
            alert('Veuillez ajouter du contenu avant d enregistrer le document');
            return;
        }

        // Show loading state
        const $button = $(this);
        const originalText = $button.text();
        $button.prop('disabled', true).text('Saving...');

        // Make the AJAX call
        $.ajax({
            url: window.pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_save_document',
                nonce: window.pdData.nonce,
                patient_id: patientId,
                encounter_id: encounterId,
                type: type,
                content: content
            },
            success: function(response) {
                if (response.success) {
                    alert('Document enregistré avec succès');
                } else {
                    console.error('Save response:', response);
                    alert('Save failed: ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Erreur de connexion. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Print handler
    $('.print-document').on('click', function() {
        const type = $(this).data('type');
        const editor = editors[type];
        
        if (!editor) {
            alert('Éditeur non initialisé !');
            return;
        }

        const printContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${type.charAt(0).toUpperCase() + type.slice(1)}</title>
                <style>
                    ${editor.dom.doc.styleSheets[0].cssRules[0].cssText}
                </style>
            </head>
            <body>
                ${editor.getContent()}
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank');
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.print();
    });
  
  // Initialize consultation editors with fixed timing
    function initConsultationEditors() {
        if (typeof tinyMCE === 'undefined') {
            console.error('TinyMCE not loaded');
            return;
        }

        const consultationFields = ['reason', 'background', 'symptoms', 'current_treatment', 'interrogation'];
        
        consultationFields.forEach(field => {
            const editorId = 'editor_' + field;
            
            // Remove existing editor instance if any
            if (tinyMCE.get(editorId)) {
                tinyMCE.execCommand('mceRemoveEditor', false, editorId);
            }

            // Initialize new editor with specific settings
            tinyMCE.init({
                selector: '#' + editorId,
                height: 200,
                menubar: false,
                branding: false,
                elementpath: false,
                statusbar: false,
                relative_urls: false,
                remove_script_host: false,
                plugins: [
                    'lists link paste'
                ],
                toolbar: 'formatselect | bold italic | ' +
                        'bullist numlist | link',
                formats: {
                    bold: {inline: 'strong'},
                    italic: {inline: 'em'}
                },
                content_style: `
                    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; }
                    p { margin: 0; padding: 0; }
                `,
                setup: function(editor) {
                    editor.on('init', function() {
                        // Store editor instance
                        editors[editorId] = editor;
                        
                        // Get content from textarea
                        const content = $('#' + editorId).val();
                        if (content) {
                            editor.setContent(content);
                        }
                        
                        console.log('Consultation editor initialized:', editorId);
                    });

                    editor.on('change', function() {
                        editor.save();
                        $('#' + editorId).closest('.consultation-field').addClass('has-changes');
                    });
                }
            });
        });
    }

    // Initialize consultation form handlers
    function initConsultationForm() {
        const $form = $('#consultation-form');
        
        $form.on('submit', function(e) {
            e.preventDefault();
            
            const $button = $form.find('button[type="submit"]');
            const originalText = $button.text();
            
            // Collect data from all editors
            const data = {};
            ['reason', 'background', 'symptoms', 'current_treatment', 'interrogation'].forEach(field => {
                const editor = tinyMCE.get('editor_' + field);
                if (editor) {
                    data[field] = editor.getContent();
                }
            });

            // Show loading state
            $button.prop('disabled', true).text('Saving...');

            // Save consultation
            $.ajax({
                url: pdData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'pd_save_consultation',
                    nonce: pdData.nonce,
                    encounter_id: $form.find('input[name="encounter_id"]').val(),
                    patient_id: $form.find('input[name="patient_id"]').val(),
                    data: data
                },
                success: function(response) {
                    if (response.success) {
                        alert('Consultation enregistrée avec succès');
                        $('.consultation-field').removeClass('has-changes');
                    } else {
                        alert('Error: ' + (response.data?.message || 'Impossible d\'enregistrer la consultation'));
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', {xhr, status, error});
                    alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        });
    }

    // Initialize both editors and form handlers when document is ready
    $(document).ready(function() {
        // Wait a short moment to ensure TinyMCE is fully loaded
        setTimeout(function() {
            initConsultationEditors();
            initConsultationForm();
        }, 500);
    });

    // Re-initialize editors when consultation tab is clicked
    $('.tab-link[data-tab="info"]').on('click', function() {
        setTimeout(function() {
            initConsultationEditors();
        }, 300);
    });
  
   // Prescription form handler with explicit encounter_id
    $('#prescription-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const originalText = $button.text();
        
        // Show loading state
        $button.prop('disabled', true).text('Ajout...');
        
        const formData = new FormData(this);
        formData.append('action', 'pd_add_prescription');
        formData.append('nonce', pdData.nonce);
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    // Clear form
                    $form[0].reset();
                    // Refresh prescriptions list
                    reloadPrescriptionsList($form.find('[name="encounter_id"]').val());
                    // Optional: Show success message
                    alert('Prescription ajoutée avec succès');
                } else {
                    // Show specific error message if available
                    alert(response.data?.message || 'Impossible d\'ajouter une prescription');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Network error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Add function to reload prescriptions list
    function reloadPrescriptionsList(encounter_id) {
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_encounter_prescriptions',
                nonce: pdData.nonce,
                encounter_id: encounter_id
            },
            success: function(response) {
                if (response.success) {
                    $('.prescriptions-list').html(response.data.html);
                } else {
                    console.error('Échec du rechargement des ordonnances :', response);
                }
            }
        });
    }

    // Print single prescription
    $(document).on('click', '.print-prescription', function(e) {
        e.preventDefault();
        const prescriptionId = $(this).data('id');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_prescription_print',
                nonce: pdData.nonce,
                prescription_id: prescriptionId
            },
            success: function(response) {
                if (response.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Prescription</title>
                            <style>
                                body { font-family: Arial, sans-serif; padding: 20px; }
                                .prescription-print { max-width: 800px; margin: 0 auto; }
                                .clinic-header { text-align: center; margin-bottom: 30px; }
                                .patient-info { margin: 20px 0; }
                                .medication-details { margin: 30px 0; }
                                .prescription-footer { margin-top: 50px; }
                                @media print {
                                    @page { margin: 0.5cm; }
                                }
                            </style>
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() { 
                                    window.print();
                                    window.onafterprint = function() {
                                        window.close();
                                    }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error loading prescription: ' + response.data?.message);
                }
            }
        });
    });

    // Print all prescriptions
    $('.print-prescriptions').on('click', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_all_prescriptions_print',
                nonce: pdData.nonce,
                encounter_id: pdData.encounter_id
            },
            success: function(response) {
                if (response.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>All Prescriptions</title>
                            <style>
                               
                            </style>
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() { 
                                    window.print();
                                    window.onafterprint = function() {
                                        window.close();
                                    }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error loading prescriptions: ' + response.data?.message);
                }
            }
        });
    });

    // Print all prescriptions handler
    $(document).on('click', '.print-all-prescriptions', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const encounterId = $button.data('encounter');
        
        // Show loading state
        $button.prop('disabled', true).text('Preparing...');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_print_all_prescriptions',
                nonce: pdData.nonce,
                encounter_id: encounterId
            },
            success: function(response) {
                if (response.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Prescriptions</title>
                            <style>
                                
                            </style>
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() {
                                    window.print();
                                    window.onfocus = function() { window.close(); }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error: ' + (response.data?.message || 'Failed to load prescriptions'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Network error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Imprimer');
            }
        });
    });

    // Delete prescription
    $(document).on('click', '.delete-prescription', function(e) {
        e.preventDefault();
        
        if (!confirm('Etes-vous sûr de vouloir supprimer cette ordonnance ?')) {
            return;
        }

        const prescriptionId = $(this).data('id');
        const $row = $(this).closest('tr');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_delete_prescription',
                nonce: pdData.nonce,
                prescription_id: prescriptionId
            },
            success: function(response) {
                if (response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                        // Check if this was the last prescription
                        if ($('.prescription-table tbody tr').length === 0) {
                            $('.prescription-table').replaceWith(
                                '<p class="no-prescriptions">Aucune prescription ajoutée pour le moment.</p>'
                            );
                        }
                        // Hide print all button if less than 2 prescriptions remain
                        if ($('.prescription-table tbody tr').length < 2) {
                            $('.print-prescriptions').hide();
                        }
                    });
                } else {
                    alert('Error deleting prescription: ' + response.data?.message);
                }
            }
        });
    });

// Patients List functionality
jQuery(document).ready(function($) {
    // Handle patient deletion
    $('.pd-action.delete').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Etes-vous sûr de vouloir supprimer ce patient ? Cette action ne peut pas être annulée.')) {
            return;
        }
        
        const patientId = $(this).data('id');
        const $row = $(this).closest('tr');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_delete_patient',
                nonce: pdData.nonce,
                patient_id: patientId
            },
            success: function(response) {
                if (response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    alert('Error: ' + (response.data?.message || 'Failed to delete patient'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            }
        });
    });
});

// Initialize medication select
function initMedicationSelect() {
    $('.medication-select').select2({
        tags: true,
        createTag: function(params) {
            return {
                id: params.term,
                text: params.term,
                newTag: true
            };
        }
    }).on('select2:select', function(e) {
        const data = e.params.data;
        if (data.newTag) {
            // Save new medication to database
            $.ajax({
                url: pdData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'pd_add_medication',
                    nonce: pdData.nonce,
                    name: data.text
                },
                success: function(response) {
                    if (response.success) {
                        console.log('Nouveau médicament ajouté :', response.data);
                    } else {
                        console.error('Impossible d\'ajouter un médicament :', response.data?.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', {xhr, status, error});
                }
            });
        }
    });
}

$(document).ready(function() {
    initMedicationSelect();
});

// Driver's License Report handling
$('#driver-license-form').on('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'pd_save_driver_license_report');
    formData.append('nonce', pdData.nonce);
    
    const $form = $(this);
    const $button = $form.find('button[type="submit"]');
    const originalText = $button.text();
    
    $button.prop('disabled', true).text('Téléchargement en cours...');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                alert('Rapport téléchargé avec succès');
                location.reload(); // Refresh to show new file
            } else {
                alert('Error: ' + (response.data?.message || 'Upload failed'));
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX error:', {xhr, status, error});
            alert('Le téléchargement a échoué. Veuillez réessayer.');
        },
        complete: function() {
            $button.prop('disabled', false).text(originalText);
        }
    });
});

// Initialize ultrasound select with Select2
$('.ultrasound-select').select2({
    tags: true,
    createTag: function(params) {
        return {
            id: 'new:' + params.term,
            text: params.term,
            newTag: true
        };
    }
}).on('select2:select', function(e) {
    const data = e.params.data;
    if (data.newTag) {
        // Save new ultrasound type
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_add_ultrasound',
                nonce: pdData.nonce,
                name: data.text
            },
            success: function(response) {
                if (response.success) {
                    // Update the select option with new ID
                    const $option = $(`.ultrasound-select option[value="new:${data.text}"]`);
                    $option.val(response.data.id);
                }
            }
        });
    }
});

// Handle ultrasound form submission
$('#ultrasound-form').on('submit', function(e) {
    e.preventDefault();
    
    const $form = $(this);
    const $button = $form.find('button[type="submit"]');
    const originalText = $button.text();
    
    $button.prop('disabled', true).text('Adding...');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_add_patient_ultrasound',
            nonce: pdData.nonce,
            patient_id: $form.find('[name="patient_id"]').val(),
            encounter_id: $form.find('[name="encounter_id"]').val(),
            ultrasound_id: $form.find('[name="ultrasound_id"]').val()
        },
        success: function(response) {
            if (response.success) {
                location.reload(); // Reload to show new ultrasound
            } else {
                alert('Error: ' + (response.data?.message || 'Impossible d\'ajouter l\'échographie'));
            }
        },
        complete: function() {
            $button.prop('disabled', false).text(originalText);
        }
    });
});


// Handle ultrasound deletion
$(document).on('click', '.delete-ultrasound', function() {
    if (!confirm('Etes-vous sûr de vouloir supprimer cette échographie ?')) {
        return;
    }

    const $button = $(this);
    const id = $button.data('id');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_delete_ultrasound',
            nonce: pdData.nonce,
            id: id
        },
        success: function(response) {
            if (response.success) {
                $button.closest('tr').fadeOut(function() {
                    $(this).remove();
                    if ($('.ultrasound-table tbody tr').length === 0) {
                        $('.ultrasound-table').replaceWith(
                            '<p class="no-analyse-radio">Aucune analyse n\'a été demandée pour cette visite.</p>'
                        );
                    }
                });
            } else {
                alert('Error: ' + (response.data?.message || 'Impossible de supprimer l\'analyse'));
            }
        }
    });
});

 // Update print all ultrasounds handler
 $(document).on('click', '.print-all-ultrasounds', function() {
    const $button = $(this);
    const encounter_id = $button.data('encounter');
    
    // Disable button and show loading state
    $button.prop('disabled', true);
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_print_ultrasound',
            nonce: pdData.nonce,
            encounter_id: encounter_id
        },
        success: function(response) {
            if (response.success && response.data.html) {
                const printWindow = window.open('', '_blank');
                printWindow.document.write(response.data.html);
                printWindow.document.close();
                printWindow.print();
            } else {
                alert('Erreur: ' + (response.data?.message || 'Impossible de générer l\'impression'));
            }
        },
        error: function(xhr, status, error) {
            console.error('Print error:', {xhr, status, error});
            alert('Une erreur est survenue lors de l\'impression');
        },
        complete: function() {
            $button.prop('disabled', false);
        }
    });
});


 // Initialize analyse-radio select with Select2
 $('.analyse-radio-select').select2({
    tags: true,
    createTag: function(params) {
        return {
            id: 'new:' + params.term,
            text: params.term,
            newTag: true
        };
    }
}).on('select2:select', function(e) {
    const data = e.params.data;
    if (data.newTag) {
        // Save new analyse/radio type
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_add_analyse_radio',
                nonce: pdData.nonce,
                name: data.text
            },
            success: function(response) {
                if (response.success) {
                    // Update the select option with new ID
                    const $option = $(`.analyse-radio-select option[value="new:${data.text}"]`);
                    $option.val(response.data.id);
                }
            }
        });
    }
});

// Handle analyse-radio form submission
$('#analyse-radio-form').on('submit', function(e) {
    e.preventDefault();
    
    const $form = $(this);
    const $button = $form.find('button[type="submit"]');
    const originalText = $button.text();
    
    $button.prop('disabled', true).text('Adding...');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_add_patient_analyse_radio',
            nonce: pdData.nonce,
            patient_id: $form.find('[name="patient_id"]').val(),
            encounter_id: $form.find('[name="encounter_id"]').val(),
            analyse_radio_id: $form.find('[name="analyse_radio_id"]').val()
        },
        success: function(response) {
            if (response.success) {
                location.reload(); // Reload to show new analyse/radio
            } else {
                alert('Error: ' + (response.data?.message || 'Impossible d\'ajouter l\'analyse'));
            }
        },
        complete: function() {
            $button.prop('disabled', false).text(originalText);
        }
    });
});

// Handle analyse-radio deletion
$(document).on('click', '.delete-analyse-radio', function() {
    if (!confirm('Etes-vous sûr de vouloir supprimer cette analyse ?')) {
        return;
    }

    const $button = $(this);
    const id = $button.data('id');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_delete_analyse_radio',
            nonce: pdData.nonce,
            id: id
        },
        success: function(response) {
            if (response.success) {
                $button.closest('tr').fadeOut(function() {
                    $(this).remove();
                    if ($('.analyse-radio-table tbody tr').length === 0) {
                        $('.analyse-radio-table').replaceWith(
                            '<p class="no-analyse-radio">Aucune analyse n\'a été demandée pour cette visite.</p>'
                        );
                    }
                });
            } else {
                alert('Error: ' + (response.data?.message || 'Impossible de supprimer l\'analyse'));
            }
        }
    });
});

// Handle printing all analyse-radio
$(document).on('click', '.print-all-analyse-radio', function() {
    const encounter_id = $(this).data('encounter');
    
    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_print_analyse_radio',
            nonce: pdData.nonce,
            encounter_id: encounter_id
        },
        success: function(response) {
            if (response.success && response.data.html) {
                const printWindow = window.open('', '_blank');
                printWindow.document.write(response.data.html);
                printWindow.document.close();
                printWindow.print();
            } else {
                alert('Error: ' + (response.data?.message || 'Échec de la génération de la vue d\'impression'));
            }
        }
    });
});

// Handle medical report form submission
$('#medical-report-form').on('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'pd_save_medical_report');
    formData.append('nonce', pd_ajax.nonce);
    
    $.ajax({
        url: pd_ajax.url,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                alert('Rapport médical téléchargé avec succès');
                location.reload(); // Reload to show new file
            } else {
                alert(response.data.message || 'Impossible de télécharger le rapport');
            }
        },
        error: function() {
            alert('Network error occurred');
        }
    });
});

// Medical Reports Tab functionality
$(document).ready(function() {
    // Handle medical report downloads
    $('.medical-reports-list .download-report').on('click', function(e) {
        const $button = $(this);
        const url = $button.attr('href');
        
        // Log download attempt if debug is enabled
        if (pdData.debug) {
            console.log('Téléchargement du rapport médical :', url);
        }
        
        // You could add tracking or logging here if needed
    });
});

// Initialize Select2 for prescription form fields
$(document).ready(function() {
    // Initialize medication select
    $('.medication-select').select2({
        tags: true,
        placeholder: 'Sélectionnez ou saisissez le nom du médicament',
        allowClear: true
    });

    // Initialize dosage select
    $('.dosage-select').select2({
        tags: true,
        placeholder: 'Sélectionnez ou saisissez le dosage',
        allowClear: true
    });

    // Initialize frequency select
    $('.frequency-select').select2({
        tags: true,
        placeholder: 'Sélectionnez ou saisissez la fréquence',
        allowClear: true
    });

    // Initialize duration select
    $('.duration-select').select2({
        tags: true,
        placeholder: 'Sélectionnez ou saisissez la durée',
        allowClear: true
    });
});

});
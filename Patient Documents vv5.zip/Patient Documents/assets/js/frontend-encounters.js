jQuery(document).ready(function($) {
    // Initialize modal system
    const initModal = () => {
        // Remove existing modals
        $('.pd-modal').remove();

        // Create modal structure
        const modalHTML = `
            <div class="pd-modal">
                <div class="pd-modal-overlay"></div>
                <div class="pd-modal-content">
                    <button class="pd-modal-close">&times;</button>
                    <div class="modal-body"></div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);

        // Close modal handlers
        $('.pd-modal-overlay, .pd-modal-close').on('click', function() {
            $('.pd-modal').remove();
        });
    };

    // Filter encounters handler
    $('.pd-filter-button').on('click', function(e) {
        e.preventDefault();
        const status = $('.status-filter').val();
        
        $.ajax({
            url: pd_frontend.ajaxurl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'pd_filter_encounters',
                status: status,
                nonce: pd_frontend.nonce
            },
            success: function(response) {
                if(response.success) {
                    $('.encounter-list-content').html(response.data.html);
                }
            },
            error: function(xhr) {
                console.error('Filter error:', xhr.responseText);
            }
        });
    });

    // Delete encounter handler
    $(document).on('click', '.pd-action-button.delete', function(e) {
        e.preventDefault();
        if(!confirm('Are you sure you want to delete this encounter?')) return;
        
        const $row = $(this).closest('tr');
        const id = $(this).data('id');
        
        $.ajax({
            url: pd_frontend.ajaxurl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'pd_delete_encounter',
                appointment_id: id,
                nonce: pd_frontend.nonce
            },
            success: function(response) {
                if(response.success) {
                    $row.fadeOut(300, function() {
                        $(this).remove();
                    });
                }
            },
            error: function(xhr) {
                console.error('Delete error:', xhr.responseText);
            }
        });
    });

    // View patient handler
    $(document).on('click', '.pd-action-button.view', function(e) {
        e.preventDefault();
        const patientId = $(this).data('patient');
        
        $.ajax({
            url: pd_frontend.ajaxurl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'pd_get_patient_view',
                patient_id: patientId,
                nonce: pd_frontend.nonce
            },
            success: function(response) {
                if(response.success) {
                    initModal();
                    $('.modal-body').html(response.data.html);
                }
            },
            error: function(xhr) {
                console.error('View error:', xhr.responseText);
            }
        });
    });

    // View bill handler
    $(document).on('click', '.pd-action-button.bill', function(e) {
        e.preventDefault();
        const appointmentId = $(this).data('appointment');
        
        $.ajax({
            url: pd_frontend.ajaxurl,
            method: 'GET',
            dataType: 'json',
            data: {
                action: 'pd_get_bill_details',
                appointment_id: appointmentId,
                nonce: pd_frontend.nonce
            },
            success: function(response) {
                if(response.success) {
                    initModal();
                    $('.modal-body').html(response.data.html);
                }
            },
            error: function(xhr) {
                console.error('Bill error:', xhr.responseText);
            }
        });
    });

    // Initialize first modal structure
    initModal();
});
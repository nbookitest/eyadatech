
window.pdDebug = {
    logState: function() {
        console.group('Patient Documents Debug Info');
        console.log('pdData:', window.pdData);
        console.log('Editors:', tinyMCE.editors);
        console.log('Document Wrappers:', jQuery('.document-wrapper').length);
        console.log('Patient ID from DOM:', jQuery('.document-wrapper').first().data('patient'));
        console.log('Encounter ID from DOM:', jQuery('.document-wrapper').first().data('encounter'));
        console.groupEnd();
    },
    
    validateSaveData: function(type, patient_id, encounter_id) {
        console.group('Save Validation');
        console.log('Document Type:', type);
        console.log('Patient ID:', patient_id);
        console.log('Encounter ID:', encounter_id);
        console.log('Editor Content:', tinyMCE.get('editor_' + type)?.getContent().substring(0, 100) + '...');
        console.groupEnd();
        
        return !!(type && patient_id && encounter_id);
    }
};

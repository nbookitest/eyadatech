jQuery(document).ready(function($) {
    let editingId = null;
    
    // Load data on page load
    loadAccountingData();
    
    // Add New button click
    $('.pd-button.add-new').on('click', function() {
        editingId = null;
        $('#accounting-form')[0].reset();
        $('.pd-modal-title').text('Add New Facture');
        $('#accounting-form-modal').addClass('active');
    });
    
    // Close modal
    $('.pd-modal-close, .pd-button.cancel').on('click', function() {
        $('#accounting-form-modal').removeClass('active');
    });
    
    // Form submit
    $('#accounting-form').on('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            action: 'pd_save_accounting',
            nonce: pd_accounting.nonce,
            id: editingId,
            date: $('#date').val(),
            invoice_number: $('#invoice_number').val(),
            beneficiary: $('#beneficiary').val(),
            payment_method: $('#payment_method').val(),
            payment_reference: $('#payment_reference').val(),
            amount: $('#amount').val()
        };
        
        $.ajax({
            url: pd_accounting.ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#accounting-form-modal').removeClass('active');
                    loadAccountingData();
                } else {
                    alert(response.data.message);
                }
            }
        });
    });
    
    // Edit button click
    $(document).on('click', '.pd-action.edit', function() {
        const id = $(this).data('id');
        editingId = id;
        
        $.ajax({
            url: pd_accounting.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_accounting',
                nonce: pd_accounting.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    $('#date').val(data.date);
                    $('#invoice_number').val(data.invoice_number);
                    $('#beneficiary').val(data.beneficiary);
                    $('#payment_method').val(data.payment_method);
                    $('#payment_reference').val(data.payment_reference);
                    $('#amount').val(data.amount);
                    
                    $('.pd-modal-title').text('Edit Facture');
                    $('#accounting-form-modal').addClass('active');
                }
            }
        });
    });
    
    // Delete button click
    $(document).on('click', '.pd-action.delete', function() {
        if (!confirm('Etes-vous sûr de vouloir supprimer cette entrée ?')) return;
        
        const id = $(this).data('id');
        
        $.ajax({
            url: pd_accounting.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_delete_accounting',
                nonce: pd_accounting.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    loadAccountingData();
                }
            }
        });
    });
    
    // Print button click
    $('.pd-button.print').on('click', function() {
        window.print();
    });
    
    // Load accounting data
    function loadAccountingData() {
        $.ajax({
            url: pd_accounting.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_accounting_list',
                nonce: pd_accounting.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderTable(response.data);
                }
            }
        });
    }
    
    // Render table
    function renderTable(data) {
        const tbody = $('.pd-accounting-table tbody');
        tbody.empty();
        
        let total = 0;
        
        data.forEach(item => {
            total += parseFloat(item.amount);
            
            tbody.append(`
                <tr>
                    <td>${item.date}</td>
                    <td>${item.invoice_number}</td>
                    <td>${item.beneficiary}</td>
                    <td>${item.payment_method}</td>
                    <td>${item.payment_reference || ''}</td>
                    <td>${parseFloat(item.amount).toFixed(2)} MAD</td>
                    <td>
                        <button class="pd-action edit" data-id="${item.id}">
                            <span class="dashicons dashicons-edit"></span>
                        </button>
                        <button class="pd-action delete" data-id="${item.id}">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </td>
                </tr>
            `);
        });
        
        $('.total-amount').text(total.toFixed(2));
    }
});

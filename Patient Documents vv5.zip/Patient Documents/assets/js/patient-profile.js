jQuery(document).ready(function($) {
    // Tab switching
    $('.profile-tabs .tab-link').on('click', function(e) {
        e.preventDefault();
        const targetTab = $(this).data('tab');
        
        // Update active states
        $('.profile-tabs .tab-link').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').removeClass('active');
        $(`#${targetTab}`).addClass('active');
        
        // Update URL without page reload
        const currentUrl = new URL(window.location);
        currentUrl.searchParams.set('tab', targetTab);
        window.history.pushState({}, '', currentUrl);
    });

    // Consultation details toggle
    $('.consultation-item').on('click', function() {
        const $details = $(this).find('.consultation-details');
        $details.slideToggle(300);
        $(this).toggleClass('expanded');
    });

    // Prescription print handler
    $('.print-prescription').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const prescriptionId = $(this).data('id');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_prescription_print',
                nonce: pdData.nonce,
                prescription_id: prescriptionId
            },
            success: function(response) {
                if (response.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(response.data.html);
                    printWindow.document.close();
                    setTimeout(() => {
                        printWindow.print();
                    }, 500);
                }
            }
        });
    });

    // Document view handler
    $('.view-document').on('click', function(e) {
        e.preventDefault();
        const $button = $(this);
        const documentId = $button.data('id');
        
        // Show loading state
        $button.prop('disabled', true).text('Chargement...');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_document_content',
                nonce: pdData.nonce,
                document_id: documentId
            },
            success: function(response) {
                if (response.success) {
                    showDocumentModal(response.data);
                } else {
                    alert('Error: ' + (response.data?.message || 'Impossible de charger le document'));
                    console.error('Document load error:', response);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Voir');
            }
        });
    });

    // Updated modal function
    function showDocumentModal(data) {
        // Remove any existing modal
        $('.pd-modal').remove();
        
        const modal = $(`
            <div class="pd-modal">
                <div class="pd-modal-content">
                    <div class="pd-modal-header">
                        <h3>${data.type.charAt(0).toUpperCase() + data.type.slice(1)}</h3>
                        <span class="pd-modal-close">&times;</span>
                    </div>
                    <div class="pd-modal-body">
                        <div class="document-date">
                            Created: ${new Date(data.date).toLocaleDateString()}
                        </div>
                        <div class="document-content">
                            ${data.content}
                        </div>
                    </div>
                    <div class="pd-modal-footer">
                        <button class="print-document button">Imprimer</button>
                    </div>
                </div>
            </div>
        `).appendTo('body');

        // Show modal with animation
        requestAnimationFrame(() => {
            modal.addClass('active');
        });

        // Close modal handlers
        modal.find('.pd-modal-close').on('click', () => {
            modal.removeClass('active');
            setTimeout(() => modal.remove(), 300);
        });

        // Print handler
        modal.find('.print-document').on('click', function() {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>${data.type}</title>
                    <link rel="stylesheet" href="${pdData.printCss}">
                </head>
                <body>
                    ${data.content}
                    <script>
                        window.onload = function() {
                            window.print();
                            window.onfocus = function() { window.close(); }
                        }
                    </script>
                </body>
                </html>
            `);
            printWindow.document.close();
        });
    }

    // Add prescription handler with error handling
    $('#prescription-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const originalText = $button.text();
        
        $button.prop('disabled', true).text('Adding...');
        
        const formData = new FormData(this);
        formData.append('action', 'pd_add_prescription');
        formData.append('nonce', pdData.nonce);
        formData.append('encounter_id', pdData.encounter_id);
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (response.data?.message || 'Impossible d\'ajouter une prescription'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Print all prescriptions for encounter
    $('.print-encounter-prescriptions').on('click', function(e) {
        e.preventDefault();
        const $button = $(this);
        const encounterId = $button.data('encounter');
        
        // Show loading state
        $button.prop('disabled', true).text('Loading...');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_print_all_prescriptions',
                nonce: pdData.nonce,
                encounter_id: encounterId
            },
            success: function(response) {
                if (response.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Prescriptions</title>
                            <link rel="stylesheet" href="${pdData.printCss}">
                            <style>
                                body { font-family: Arial, sans-serif; padding: 20px; }
                                .prescription-print { 
                                    max-width: 800px;
                                    margin: 0 auto 30px;
                                    padding: 20px;
                                    border: 1px solid #ddd;
                                }
                                .clinic-header { text-align: center; margin-bottom: 30px; }
                                .patient-details { margin: 20px 0; }
                                .medication-details { margin: 30px 0; }
                                .prescription-footer { margin-top: 50px; text-align: right; }
                                table { width: 100%; border-collapse: collapse; }
                                th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
                                @media print {
                                    .prescription-print { border: none; }
                                    @page { margin: 0.5cm; }
                                }
                            </style>
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() {
                                    window.print();
                                    window.onfocus = function() { window.close(); }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error: ' + (response.data?.message || 'Failed to load prescriptions'));
                    console.error('Print error:', response);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Imprimer');
            }
        });
    });

    // Print ultrasounds for encounter
    $('.print-encounter-ultrasounds').on('click', function(e) {
        e.preventDefault();
        const $button = $(this);
        const encounterId = $button.data('encounter');
        
        // Show loading state
        $button.prop('disabled', true).text('Loading...');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_print_ultrasound',
                nonce: pdData.nonce,
                encounter_id: encounterId
            },
            success: function(response) {
                if (response.success && response.data.html) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Échographies</title>
                            <link rel="stylesheet" href="${pdData.printCss}">
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() {
                                    window.print();
                                    window.onfocus = function() { window.close(); }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error: ' + (response.data?.message || 'Échec du chargement des échographies'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Imprimer');
            }
        });
    });

    // Print analyses/radios for encounter
    $('.print-encounter-analyses').on('click', function(e) {
        e.preventDefault();
        const $button = $(this);
        const encounterId = $button.data('encounter');
        
        // Show loading state
        $button.prop('disabled', true).text('Chargement...');
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_print_analyse_radio',
                nonce: pdData.nonce,
                encounter_id: encounterId
            },
            success: function(response) {
                if (response.success && response.data.html) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Analyses</title>
                            <link rel="stylesheet" href="${pdData.printCss}">
                        </head>
                        <body>
                            ${response.data.html}
                            <script>
                                window.onload = function() {
                                    window.print();
                                    window.onfocus = function() { window.close(); }
                                }
                            </script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('Error: ' + (response.data?.message || 'Échec du chargement des analyses'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                alert('Une erreur réseau s\'est produite. Veuillez réessayer.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Print');
            }
        });
    });

    // Invoice handler
    $(document).on('click', '.pd-action.invoice', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Add this to prevent event bubbling
        
        const $button = $(this);
        const data = {
            encounter_id: $button.data('encounter'),
            patient_id: $button.data('patient'),
            clinic_id: $button.data('clinic'),
            action: 'pd_get_invoice_v2',
            nonce: pdData.nonce // Use the regular nonce
        };
        
        // Show loading state
        showModal('<div class="loading">Chargement des détails de la facture...</div>');
        
        // Debug log
        console.log('Sending invoice request with data:', data);
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: data,
            success: function(response) {
                console.log('Invoice response:', response); // Debug log
                if (response.success) {
                    $('.pd-modal-body').html(response.data.html);
                } else {
                    $('.pd-modal-body').html(`
                        <div class="error">
                            <h3>Error Loading Invoice</h3>
                            <p>${response.data?.message || 'Unknown error occurred'}</p>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('Invoice AJAX error:', {xhr, status, error});
                $('.pd-modal-body').html(`
                    <div class="error">
                        <h3>Error</h3>
                        <p>Impossible de charger la facture. Veuillez réessayer.</p>
                        <p>Error details: ${error}</p>
                    </div>
                `);
            }
        });
    });

    // Update the print handler for invoices
    $(document).on('click', '.print-invoice', function(e) {
        e.preventDefault();
        const invoiceContent = $('.kc-invoice-modal').clone();
        
        // Remove action buttons from print view
        invoiceContent.find('.invoice-actions').remove();
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Invoice</title>
                <link rel="stylesheet" href="${pdData.printCss}">
                <style>
                    body { 
                        font-family: Arial, sans-serif;
                        padding: 20px;
                        margin: 0;
                    }
                    .kc-invoice-modal { 
                        padding: 20px;
                        max-width: 800px;
                        margin: 0 auto;
                    }
                    .invoice-header { 
                        text-align: center;
                        margin-bottom: 30px;
                    }
                    .invoice-title { 
                        font-size: 24px;
                        margin-bottom: 20px;
                        text-align: center;
                    }
                    .amount-statement { 
                        margin: 40px 0;
                        line-height: 1.6;
                    }
                    .statement-text {
                        text-align: justify;
                    }
                    .invoice-footer { 
                        margin-top: 50px;
                        text-align: right;
                    }
                    .signature-section {
                        float: right;
                        text-align: center;
                        margin-top: 30px;
                    }
                    .signature-line {
                        border-top: 1px solid #000;
                        width: 200px;
                        margin-top: 50px;
                        text-align: center;
                    }
                    @media print {
                        @page { 
                            margin: 2cm;
                        }
                        body { 
                            print-color-adjust: exact;
                            -webkit-print-color-adjust: exact;
                        }
                        .invoice-actions { 
                            display: none;
                        }
                    }
                </style>
            </head>
            <body>
                ${invoiceContent.html()}
                <script>
                    window.onload = function() {
                        window.print();
                        window.onafterprint = function() {
                            window.close();
                        }
                    }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    });

    // Add modal functions if not already present
    function showModal(content) {
        $('.pd-modal').remove();
        
        const modalHTML = `
            <div class="pd-modal">
                <div class="pd-modal-content">
                    <button class="pd-modal-close">&times;</button>
                    <div class="pd-modal-body">${content}</div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        requestAnimationFrame(() => {
            $('.pd-modal').addClass('active');
        });

        $('.pd-modal-close, .pd-modal').on('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    }

    function closeModal() {
        const $modal = $('.pd-modal');
        $modal.removeClass('active');
        setTimeout(() => $modal.remove(), 300);
    }
});

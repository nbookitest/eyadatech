jQuery(document).ready(function($) {
    let currentDate = new Date();
    let currentView = 'calendar';
    
    // Initialize the dashboard
    function initDashboard() {
        if (currentView === 'calendar') {
            renderCalendar();
        } else {
            renderGrid();
        }
        attachEventHandlers();
        attachFilterHandlers();
    }

    // Render grid view
    function renderGrid() {
        const container = $('.view-container');
        container.empty();
        
        // Add grid container
        const gridContainer = $('<div>', {
            class: 'appointments-grid'
        });
        
        container.append(gridContainer);
        
        // Load appointments for grid view
        loadAppointments(true);
    }

    // Render calendar view
    function renderCalendar() {
        const calendarGrid = $('.calendar-grid');
        calendarGrid.empty();
        
        // Set first day of month
        const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
        
        // Update month display
        $('.current-month').text(
            currentDate.toLocaleString('default', { 
                month: 'long', 
                year: 'numeric' 
            })
        );
        
        // Create weekday headers
        const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        weekdays.forEach(day => {
            calendarGrid.append($('<div>', {
                class: 'weekday-header',
                text: day
            }));
        });
        
        // Add empty cells for days before first of month
        for (let i = 0; i < firstDay.getDay(); i++) {
            calendarGrid.append($('<div>', { class: 'calendar-cell empty' }));
        }
        
        // Create calendar cells
        for (let i = 1; i <= daysInMonth; i++) {
            const cellDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
            const cell = $('<div>', {
                class: 'calendar-cell',
                'data-date': cellDate.toISOString().split('T')[0]
            });
            
            cell.append($('<div>', {
                class: 'date-header',
                text: i
            }));
            
            cell.append($('<div>', {
                class: 'appointments-list'
            }));
            
            calendarGrid.append(cell);
        }
        
        // Load appointments
        loadAppointments();
    }

    // Load appointments from the server
    function loadAppointments(isGrid = false) {
        const container = isGrid ? $('.appointments-grid') : $('.calendar-grid');
        container.addClass('loading');
        
        const searchTerm = $('#patient-search').val();
        const dateFilter = $('#date-filter').val();
        
        $.ajax({
            url: pdData.ajaxurl,
            type: 'POST',
            data: {
                action: 'pd_get_appointments',
                nonce: pdData.nonce,
                month: currentDate.getMonth() + 1,
                year: currentDate.getFullYear(),
                search: searchTerm,
                date_filter: dateFilter
            },
            success: function(response) {
                container.removeClass('loading');
                if (response.success && Array.isArray(response.data)) {
                    if (isGrid) {
                        populateGrid(response.data);
                    } else {
                        populateAppointments(response.data);
                    }
                    updateResultsCount(response.data.length);
                } else {
                    showError(container, 'No appointments found');
                }
            },
            error: function(xhr, status, error) {
                container.removeClass('loading');
                showError(container, 'Error loading appointments');
                console.error('Ajax error:', {xhr, status, error});
            }
        });
    }

    // Add function to update results count
    function updateResultsCount(count) {
        $('.results-count').text(`Found ${count} appointment${count !== 1 ? 's' : ''}`);
    }

    // Add function to show errors
    function showError(container, message) {
        container.append(`
            <div class="error-message">
                ${message}
            </div>
        `);
    }

    // Populate grid view
    function populateGrid(appointments) {
        const grid = $('.appointments-grid');
        grid.empty();
        
        appointments.forEach(appointment => {
            const appointmentDate = new Date(appointment.next_appointment_date);
            const appointmentEl = createAppointmentElement(appointment, appointmentDate);
            grid.append(appointmentEl);
        });
    }


// Show modal
$('#open-appointment-modal').on('click', function(e) {
    e.preventDefault();
    $('#appointment-modal').show();
    $('<div>').addClass('pd-modal-overlay').appendTo('body');
});

// Close modal
$(document).on('click', '.pd-modal .close, .pd-modal-overlay', function() {
    $('#appointment-modal').hide();
    $('.pd-modal-overlay').remove();
});

// Form submission
$('#appointment-form').on('submit', function(e) {
    e.preventDefault();
    
    const formData = $(this).serializeArray().reduce((obj, item) => {
        obj[item.name] = item.value;
        return obj;
    }, {});

    $.ajax({
        url: pdData.ajaxurl,
        type: 'POST',
        data: {
            action: 'pd_save_appointment',
            nonce: pdData.nonce,
            ...formData
        },
        success: function(response) {
            if(response.success) {
                // Close modal
                $('#appointment-modal').hide();
                $('.pd-modal-overlay').remove();
                
                // Refresh calendar and grid
                if(currentView === 'calendar') {
                    loadAppointments();
                } else {
                    loadAppointments(true);
                }
                
                // Reset form
                $('#appointment-form')[0].reset();
            } else {
                alert('Error: ' + (response.data.message || 'Unknown error'));
            }
        },
        error: function() {
            alert('Network error occurred');
        }
    });
});


    // Create appointment element
    function createAppointmentElement(appointment, date) {
        console.log('Creating appointment element:', appointment);

        // Ensure required data exists
        if (!appointment.patient_name || !appointment.next_appointment_date) {
            console.error('Missing required appointment data:', appointment);
            return null;
        }

        // Format more_info
        let moreInfoText = '';
        if (appointment.more_info) {
            try {
                if (typeof appointment.more_info === 'object') {
                    moreInfoText = Array.isArray(appointment.more_info) 
                        ? appointment.more_info.join(', ')
                        : Object.values(appointment.more_info).join(', ');
                } else if (typeof appointment.more_info === 'string') {
                    // Try to parse if it's a JSON string
                    try {
                        const parsed = JSON.parse(appointment.more_info);
                        moreInfoText = typeof parsed === 'object' 
                            ? Object.values(parsed).join(', ')
                            : parsed;
                    } catch (e) {
                        moreInfoText = appointment.more_info;
                    }
                }
            } catch (e) {
                console.error('Error formatting more_info:', e);
                moreInfoText = '';
            }
        }

        return $('<div>', {
            class: 'appointment',
            html: `
                <div class="patient-info">
                    <span class="patient-name">${appointment.patient_name}</span>
                    <span class="appointment-date">${date.toLocaleDateString()}</span>
                    ${moreInfoText ? `<span class="more-info">${moreInfoText}</span>` : ''}
                </div>
                <div class="appointment-actions">
                    <a href="${appointment.appointment_link}" 
                       class="add-appointment-btn" 
                       target="_blank"
                       title="Add Appointment">
                        <span class="dashicons dashicons-plus-alt"></span>
                    </a>
                    <button class="delete-appointment" 
                            data-encounter="${appointment.encounter_id}"
                            data-patient="${appointment.patient_id}"
                            data-date="${appointment.next_appointment_date}"
                            title="Delete Appointment">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                </div>
            `
        });
    }

    // Populate calendar appointments
    function populateAppointments(appointments) {
        console.log('Populating appointments:', appointments);
        
        // Clear existing appointments
        $('.calendar-cell .appointments-list').empty();

        appointments.forEach(appointment => {
            if (!appointment.next_appointment_date) {
                console.error('Missing next_appointment_date:', appointment);
                return;
            }

            const date = new Date(appointment.next_appointment_date);
            const dateStr = date.toISOString().split('T')[0];
            const cell = $(`.calendar-cell[data-date="${dateStr}"]`);
            
            if (cell.length) {
                const appointmentEl = createAppointmentElement(appointment, date);
                if (appointmentEl) {
                    cell.find('.appointments-list').append(appointmentEl);
                }
            } else {
                console.warn('No cell found for date:', dateStr);
            }
        });

        // Add delete handler
        $('.delete-appointment').click(function() {
            const encounterId = $(this).data('encounter');
            const patientId = $(this).data('patient');
            const date = $(this).data('date');
            
            if (confirm('Are you sure you want to delete this appointment?')) {
                $.ajax({
                    url: pdData.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'pd_delete_appointment',
                        nonce: pdData.nonce,
                        encounter_id: encounterId,
                        patient_id: patientId,
                        date: date
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert('Failed to delete appointment');
                        }
                    }
                });
            }
        });
    }

    // Event Handlers
    function attachEventHandlers() {
        // View toggle
        $('.view-toggle').click(function() {
            currentView = $(this).data('view');
            $('.view-toggle').removeClass('active');
            $(this).addClass('active');
            initDashboard();
        });
        
        // Month navigation
        $('.prev-month').click(() => {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
        });
        
        $('.next-month').click(() => {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
        });
        
        // Add new appointment
        $('.add-appointment').click(() => {
            $('#appointment-modal').show();
        });
        
        // Modal close
        $('.pd-modal .close').click(function() {
            $(this).closest('.pd-modal').hide();
        });
        
        // Appointment form submission
        $('#appointment-form').submit(function(e) {
            e.preventDefault();
            saveAppointment($(this));
        });
    }

    // Add filter handlers
    function attachFilterHandlers() {
        $('#patient-search, #date-filter').on('change', function() {
            loadAppointments(currentView === 'grid');
        });
    }

    // Initialize the dashboard
    initDashboard();
});

-- Ultrasound Tables
CREATE TABLE IF NOT EXISTS wp_kc_ultrasounds (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    description text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS wp_kc_patient_ultrasounds (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    patient_id bigint(20) NOT NULL,
    encounter_id bigint(20) NOT NULL,
    ultrasound_id bigint(20) NOT NULL,
    result text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY patient_id (patient_id),
    KEY encounter_id (encounter_id),
    KEY ultrasound_id (ultrasound_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Analyse & Radio Tables
CREATE TABLE IF NOT EXISTS wp_kc_analyse_radio (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    description text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS wp_kc_patient_analyse_radio (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    patient_id bigint(20) NOT NULL,
    encounter_id bigint(20) NOT NULL,
    analyse_radio_id bigint(20) NOT NULL,
    result text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY patient_id (patient_id),
    KEY encounter_id (encounter_id),
    KEY analyse_radio_id (analyse_radio_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

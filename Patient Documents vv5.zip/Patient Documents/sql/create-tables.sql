CREATE TABLE IF NOT EXISTS `wp_kc_medical_consultations` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `encounter_id` bigint(20) NOT NULL,
    `patient_id` bigint(20) NOT NULL,
    `reason` text,
    `background` text,
    `symptoms` text,
    `current_treatment` text,
    `interrogation` text,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `encounter_patient` (`encounter_id`, `patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add indexes to medical consultations
ALTER TABLE `wp_kc_medical_consultations`
DROP INDEX `patient_encounter`,
ADD INDEX `encounter_id` (`encounter_id`);

-- Add foreign key for consultations
ALTER TABLE `wp_kc_medical_consultations`
ADD CONSTRAINT `fk_consultation_encounter` 
FOREIGN KEY (`encounter_id`) REFERENCES `wp_kc_patient_encounters` (`id`)
ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS `wp_kc_patient_documents` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `patient_id` bigint(20) unsigned NOT NULL,
    `encounter_id` bigint(20) NOT NULL,
    `document_type` varchar(50) NOT NULL,
    `content` longtext,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `encounter_type` (`encounter_id`, `document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update patient documents table
ALTER TABLE `wp_kc_patient_documents`
ADD INDEX `encounter_id` (`encounter_id`),
ADD INDEX `patient_id` (`patient_id`),
ADD CONSTRAINT `fk_document_encounter` 
FOREIGN KEY (`encounter_id`) REFERENCES `wp_kc_patient_encounters` (`id`)
ON DELETE CASCADE,
ADD CONSTRAINT `fk_document_patient`
FOREIGN KEY (`patient_id`) REFERENCES `wp_users` (`ID`)
ON DELETE CASCADE;

-- Add encounter_date to encounters table if not exists
ALTER TABLE `wp_kc_patient_encounters` 
ADD COLUMN IF NOT EXISTS `encounter_date` datetime DEFAULT CURRENT_TIMESTAMP;

-- Add clinic_id to encounters table if not exists
ALTER TABLE `wp_kc_patient_encounters`
ADD COLUMN IF NOT EXISTS `clinic_id` bigint(20) unsigned NOT NULL;

CREATE TABLE IF NOT EXISTS `wp_kc_prescriptions` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `encounter_id` bigint(20) NOT NULL,
    `patient_id` bigint(20) NOT NULL,
    `medication_name` varchar(255) NOT NULL,
    `dosage` varchar(100),
    `frequency` varchar(100),
    `duration` varchar(100),
    `instructions` text,
    `doctor_id` bigint(20) NOT NULL,
    `clinic_id` bigint(20) NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `encounter_patient` (`encounter_id`, `patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update prescriptions table indexes
ALTER TABLE `wp_kc_prescriptions` 
DROP INDEX `patient_encounter`,
ADD INDEX `encounter_id` (`encounter_id`);

-- Add foreign key constraints
ALTER TABLE `wp_kc_prescriptions`
ADD CONSTRAINT `fk_prescription_encounter` 
FOREIGN KEY (`encounter_id`) REFERENCES `wp_kc_patient_encounters` (`id`)
ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS `wp_kc_document_templates` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `document_type` varchar(50) NOT NULL,
    `template_name` varchar(255) NOT NULL,
    `content` longtext NOT NULL,
    `is_template` tinyint(1) NOT NULL DEFAULT '1',
    `created_by` bigint(20) unsigned NOT NULL,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    KEY `document_type` (`document_type`),
    KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `wp_kc_medications` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `created_by` bigint(20) unsigned NOT NULL,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `name` (`name`),
    KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `wp_kc_accounting` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `date` date NOT NULL,
    `invoice_number` varchar(50) NOT NULL,
    `beneficiary` varchar(255) NOT NULL,
    `payment_method` varchar(50) NOT NULL,
    `payment_reference` varchar(100) DEFAULT NULL,
    `amount` decimal(10,2) NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `invoice_number` (`invoice_number`),
    KEY `date` (`date`),
    KEY `beneficiary` (`beneficiary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ...existing code... */

CREATE TABLE IF NOT EXISTS `wp_kc_medical_reports` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `patient_id` bigint(20) NOT NULL,
    `encounter_id` bigint(20) NOT NULL,
    `file_name` varchar(255) NOT NULL,
    `file_path` varchar(255) NOT NULL,
    `file_type` varchar(50) NOT NULL,
    `uploaded_by` bigint(20) NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `patient_encounter` (`patient_id`, `encounter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ...existing code... */

CREATE TABLE IF NOT EXISTS `wp_kc_driver_license_records` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `order_number` varchar(50) NOT NULL,
    `date` date NOT NULL,
    `patient_name` varchar(255) NOT NULL,
    `cin` varchar(50) NOT NULL,
    `license_type` varchar(10) NOT NULL,
    `interest_status` varchar(50) NOT NULL, /* Added this line */
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `order_number` (`order_number`),
    KEY `date` (`date`),
    KEY `cin` (`cin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

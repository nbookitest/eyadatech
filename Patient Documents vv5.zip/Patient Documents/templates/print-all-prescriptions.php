<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Medical Prescription</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    /* General Reset */
    body {
      margin: 0;
      font-family: 'Arial', sans-serif;
      line-height: 1.6;
      color: #333;
    }

    .prescription {
      display: flex;
      flex-direction: column;
      min-height: 100vh; /* Ensure the container takes up full page height */
      max-width: 900px;
      margin: 0 auto;
      font-size: 14px;
      text-transform: capitalize;
      position: relative; /* Allow absolute positioning of elements */
    }

    /* Fixed Header for Print */
    header {
      background-color: white;
      border-bottom: 1px solid #ccc;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }

    .header-left {
      text-align: left;
      width: 45%;
    }

    .header-right {
      text-align: right;
      width: 43%;
    }

    .header-left p {
      font-size: 8px;
      margin: 0;
    }
    .header-right p {
      font-size: 10px;
      margin: 0;
    }

    .header-left h3, .header-right h3 {
      margin: 0 0 3px 0;
      font-size: 14px;
    }

    .header-left h1, .header-right h1 {
      margin: 0;
      font-size: 18px;
    }

    .logo {
      text-align: center;
    }

    .logo img {
      width: 70px;
    }

    /* Date */
    .date {
      text-align: center;
      margin-top: 0mm;
      margin-bottom: 0px;
      font-size: 14px;
    }

    /* Patient Info */
    .patient-info {
      text-align: center;
      margin-bottom: 0px;
      margin-top: -18px;
    }

    .patient-details {
      font-size: 18px;
      font-weight: 600;
      text-transform: capitalize;
    }

    /* Prescription Items */
    .prescription-items {
      flex: 1; /* Allow content to grow and push the footer down */
      margin-top: 1mm; /* Space for fixed header */
      margin-bottom: -30mm; /* Space for fixed footer */
    }

    .item {
      display: flex;
      align-items: flex-start;
      margin-bottom: 10px;
    }

    .number {
      margin-right: 10px;
      font-weight: bold;
    }

    .medication p {
      margin: 0;
    }

    /* Fixed Footer for Print */
    footer {
      background-color: white;
      border-top: 1px solid #ccc;
      display: flex;
      justify-content: center;
      align-items: center;
      
      position: absolute; /* Fix footer at the bottom */
      bottom: 0;
      left: 0;
      right: 0;
    }

    .address {
      text-align: left;
      font-size: 11px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }

    .address p {
      margin: 0;
    }

    .contact-left, .contact-right {
      margin-left: 10px;
      display: flex;
      gap: 10px;
    }

    .qr-code {
      width: 50px;
    }

    /* Print Styles */
    @media print {
      body {
        margin: 0;
      }

      .page-break {
        page-break-after: always;
      }

      header, footer {
        position: relative;
      }
    

      .prescription {
        page-break-inside: avoid; /* Prevent breaking inside a prescription block */
      }
    }
  </style>
</head>
<body>
  <?php
  $counter = 1;
  $items_per_page = 8;

  // Split prescriptions into chunks of 7 items per page
  $prescription_chunks = array_chunk($prescriptions, $items_per_page);

  foreach ($prescription_chunks as $chunk) {
  ?>
    <div class="prescription">
      <!-- Fixed Header -->
      <header>
        <div class="header-left">
          <h1>Dr. <?php echo esc_html($encounter->doctor_name); ?></h1>
          <h3>Médecin généraliste</h3>
          <p>Diplome d'etudes specialisees en gynecologie Médicale</p>
          <p>Suivie de Grossesse et infertilite de couple de université de bordeaux France.</p>
          <p>Diplome d'echographie</p>
          <p>ECG, suivi de diabete</p>
          <p>Medecine esthetique Medecine agréée pour la visite médicale d'aptitude a la conduite.</p>
        </div>
        <div class="logo">
          <p>بسم الله الشافي</p>
          <img src="https://static.neopse.com/medias/p/996/site/6c/61/17/6c61172002f71961e7d773f4882267b56f0d70aa.png?v=v1" alt="Medical Logo">
        </div>
        <div class="header-right">
          <h1>الدكتورة بياض سامية</h1>
          <h3>طبيبة عامة</h3>
          <p> دبلوم الدراسات المتخصصة في طب النساء</p>
          <p> تتبع الحمل وعقم الزوجين من جامعة بوردو في فرنسا</p>
          <p> دبلوم الفحص بالصدى، تخطيط القلب.</p>
          <p> تتبع السكري</p>
          <p>طب التجميل</p>
          <p> طبيبة معتمدة للفحص الطبي للقدرة على السياقة</p>
        </div>
      </header>

      <!-- Date -->
      <p class="date">Temara le <?php echo date('d/m/Y', strtotime($encounter->encounter_date)); ?> تمارة في</p>

      <!-- Patient Info -->
      <div class="patient-info">
        <div class="patient-details">
          <p>Mr/Mme : <?php echo esc_html($encounter->patient_name); ?></p>
        </div>
      </div>

      <!-- Prescription Items -->
      <div class="prescription-items">
        <?php foreach ($chunk as $prescription): ?>
          <div class="item">
            <span class="number"><?php echo esc_html($counter); ?>.</span>
            <div class="medication">
              <p><?php echo esc_html($prescription->medication_name); ?></p>
              <p><?php echo esc_html($prescription->dosage); ?> <?php echo esc_html($prescription->frequency); ?> pdt <?php echo esc_html($prescription->duration); ?></p>
            </div>
          </div>
          <?php $counter++; ?>
        <?php endforeach; ?>
      </div>

      <!-- Fixed Footer -->
      <footer>
        <?php 
        global $wpdb;
        $clinic = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT telephone_no, specialties FROM wp_kc_clinics WHERE id = %d",
                $encounter->clinic_id
            )
        );

        $specialties_labels = '';
        if ($clinic && !empty($clinic->specialties)) {
            $decoded_specialties = json_decode($clinic->specialties, true);
            if (is_array($decoded_specialties)) {
                $specialties_labels = array_column($decoded_specialties, 'label');
                $specialties_labels = implode(', ', $specialties_labels);
            }
        }
        ?>
        <div class="address">
          <p class="arabic-text"><i class="fa-solid fa-location-dot"></i> حي المغرب العربي الرقم 3479، الطابق الاول المسيرة 2، تمارة </p>
          <p><i class="fa-solid fa-location-dot"></i> <?php echo esc_html($encounter->clinic_address); ?></p>
          <div class="contact-left">
            <p><i class="fa-solid fa-phone"></i> <?php echo esc_html($clinic->telephone_no); ?></p>
            <p><i class="fa-brands fa-whatsapp"></i> <?php echo esc_html($clinic->telephone_no); ?></p>
          </div>
        </div>
        <div class="contact-info">
          <div class="contact-right">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/1200px-QR_code_for_mobile_English_Wikipedia.svg.png" alt="QR Code" class="qr-code">
          </div>
        </div>
      </footer>

      <!-- Page Break -->
      <?php if ($chunk !== end($prescription_chunks)): ?>
        <div class="page-break"></div>
      <?php endif; ?>
    </div>
  <?php } ?>
</body>
</html>
<?php
if (!defined('ABSPATH')) exit;

// Get patient ID from URL
$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
if (!$patient_id) {
    wp_die('Invalid patient ID');
}

// Get database instance
$db = PD_Database::get_instance();

// Get patient data
$patient = $db->get_patient_details($patient_id);
if (!$patient) {
    wp_die('Patient not found');
}

// Get all data for this patient
$encounters = $db->get_patient_encounters($patient_id);
$prescriptions = $db->get_patient_prescriptions($patient_id);
$documents = $db->get_patient_all_documents($patient_id);

// Get current active tab
$current_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'consultations';

// Fetch custom form data for the patient
$custom_fields = array();
if ($patient_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'kc_custom_fields_data';
    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT field_id, fields_data 
             FROM $table_name 
             WHERE module_id = %d AND field_id IN (1, 2, 3, 6, 8, 11)",
            $patient_id
        ),
        ARRAY_A
    );

    // Map field_id to form_data
    foreach ($results as $row) {
        $custom_fields[$row['field_id']] = maybe_unserialize($row['fields_data']);
    }
}


// Function to calculate age from date of birth
function calculate_age($dob) {
    // Ensure the DOB is not empty
    if (empty($dob)) {
        return 'N/A'; // Return 'N/A' if DOB is not provided
    }

    // Convert the DOB string to a DateTime object
    $birth_date = new DateTime($dob);
    $current_date = new DateTime('now'); // Get the current date

    // Calculate the difference between the two dates
    $age = $birth_date->diff($current_date)->y;

    return $age; // Return the calculated age
}

wp_enqueue_style('pd-patient-profile', PD_PLUGIN_URL . 'assets/css/patient-profile.css');

?>

<div class="patient-profile-wrapper">
    <!-- Profile Header -->
    <div class="profile-header">
        <h2>Profil médical de <?php echo esc_html($patient->display_name); ?></h2>
        <div class="patient-info-grid">
            <div class="info-item">
                <label>Phone</label>
                <span><?php echo esc_html($patient->phone); ?></span>
            </div>
            <div class="info-item">
                    <label>CIN</label>
                    <span><?php echo isset($custom_fields[1]) ? esc_html($custom_fields[1]) : 'N/A'; ?></span>
                </div>
            <div class="info-item">
                <label>Genre</label>
                <span><?php echo esc_html(ucfirst($patient->gender)); ?></span>
            </div>
            <div class="info-item">
                <label>Date de naissance</label>
                <span><?php echo esc_html($patient->dob); ?></span>
            </div>
            <div class="info-item">
    <label>Age</label>
    <span><?php echo calculate_age($patient->dob); ?> years</span>
</div>
            
          
           <div class="info-item">
                    <label>Mutuelle</label>
                    <span><?php echo isset($custom_fields[2]) ? esc_html($custom_fields[2]) : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                    <label>Situation</label>
                    <span><?php echo isset($custom_fields[3]) ? esc_html($custom_fields[3]) : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                    <label>Poids</label>
                    <span><?php echo isset($custom_fields[6]) ? esc_html($custom_fields[6]) . ' kg' : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                    <label>Taille</label>
                    <span><?php echo isset($custom_fields[8]) ? esc_html($custom_fields[8]) . ' cm' : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                    <label>Tension</label>
                    <span><?php echo isset($custom_fields[11]) ? esc_html($custom_fields[11]) . ' mmHg' : 'N/A'; ?></span>
                </div>
                <div class="info-item">
                <label>Total Visits</label>
                <span><?php echo count($encounters); ?></span>
            </div>
          
          
        </div>
    </div>

    <!-- Tabs Navigation -->
    <div class="profile-tabs">
        <button class="tab-link <?php echo $current_tab === 'consultations' ? 'active' : ''; ?>" 
                data-tab="consultations">Consultations</button>
        <button class="tab-link <?php echo $current_tab === 'prescriptions' ? 'active' : ''; ?>" 
                data-tab="prescriptions">Ordonnances</button>
        <button class="tab-link <?php echo $current_tab === 'ultrasounds' ? 'active' : ''; ?>" 
                data-tab="ultrasounds">Examen Radiologique</button>
        <button class="tab-link <?php echo $current_tab === 'analyse-radio' ? 'active' : ''; ?>" 
                data-tab="analyse-radio">Examen Biologique</button>
        <button class="tab-link <?php echo $current_tab === 'documents' ? 'active' : ''; ?>" 
                data-tab="documents">Documents</button>
        <button class="tab-link <?php echo $current_tab === 'medical-reports' ? 'active' : ''; ?>" 
                data-tab="medical-reports">Rapports médicaux</button>
    </div>

    <!-- Consultations Tab -->
    <div id="consultations" class="consultations-display tab-content <?php echo $current_tab === 'consultations' ? 'active' : ''; ?>">
        <?php if (!empty($encounters)): ?>
            <?php foreach ($encounters as $encounter): ?>
                <div class="consultation-item">
                    <div class="consultations-header">
                        <div class="consultation-header-content">
                            <h4><?php echo date('F j, Y', strtotime($encounter->encounter_date)); ?></h4>
                            <?php 
                            if (defined('WP_DEBUG') && WP_DEBUG) {
                                error_log("Service for encounter {$encounter->id}: " . 
                                         print_r($encounter->service_name, true));
                            }
                            ?>
                            <?php if (!empty($encounter->service_name)): ?>
                                <span class="service">Service: <?php echo esc_html($encounter->service_name); ?></span>
                            <?php else: ?>
                                <span class="service">Service: N/A</span>
                            <?php endif; ?>
                        </div>
                        <div class="consultation-actions">
                            <a href="<?php echo esc_url(add_query_arg(
                                array(
                                    'patient_id' => $patient->ID,
                                    'encounter_id' => $encounter->id // or $encounter->encounter_id depending on your DB structure
                                ),
                                home_url('/patient-view-page/')
                            )); ?>" 
                               class="pd-action edit" 
                               target="_blank"
                               title="Edit Encounter">
                                <span class="dashicons dashicons-edit"></span>
                                Edit
                            </a>
                             <!-- View Invoice Button -->
                         <button class="pd-action invoice" 
                              data-encounter="<?php echo esc_attr($encounter->id); ?>"
                              data-patient="<?php echo esc_attr($patient->ID); ?>"
                              data-clinic="<?php echo esc_attr($encounter->clinic_id); ?>"
                              type="button">
                               <span class="dashicons dashicons-media-text"></span>
                                    Facture
                                      </button>
                        </div>
                    </div>
                    <div class="consultation-details">
                        <?php if ($encounter->reason): ?>
                            <div class="detail-item">
                                <strong>Motif de consultation:</strong>
                                <div><?php echo wp_kses_post($encounter->reason); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($encounter->symptoms): ?>
                            <div class="detail-item">
                                <strong>Symptômes:</strong>
                                <div><?php echo wp_kses_post($encounter->symptoms); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($encounter->background): ?>
                            <div class="detail-item">
                                <strong>Antécédents:</strong>
                                <div><?php echo wp_kses_post($encounter->background); ?></div>
                            </div>
                        <?php endif; ?>

                        <?php if ($encounter->current_treatment): ?>  <!-- Changed from background to current_treatment -->
                            <div class="detail-item">
                                <strong>Traitment en cours:</strong>
                                <div><?php echo wp_kses_post($encounter->current_treatment); ?></div>
                            </div>
                        <?php endif; ?>

                        <?php if ($encounter->interrogation): ?>  <!-- Changed from background to interrogation -->
                            <div class="detail-item">
                                <strong>Modèle d'interrogatoire:</strong>
                                <div><?php echo wp_kses_post($encounter->interrogation); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucune consultation trouvée.</p>
        <?php endif; ?>
    </div>

    <!-- Prescriptions Tab -->
    <div id="prescriptions" class="prescriptions-display tab-content <?php echo $current_tab === 'prescriptions' ? 'active' : ''; ?>">
        <?php 
        // Group prescriptions by encounter
        $prescriptions_by_encounter = [];
        foreach ($prescriptions as $prescription) {
            $encounter_id = $prescription->encounter_id;
            if (!isset($prescriptions_by_encounter[$encounter_id])) {
                $prescriptions_by_encounter[$encounter_id] = [
                    'date' => $prescription->encounter_date,
                    'doctor' => $prescription->doctor_name,
                    'clinic' => $prescription->clinic_name,
                    'prescriptions' => []
                ];
            }
            $prescriptions_by_encounter[$encounter_id]['prescriptions'][] = $prescription;
        }
        
        if (!empty($prescriptions_by_encounter)): 
            foreach ($prescriptions_by_encounter as $encounter_id => $encounter_data): ?>
                <div class="encounter-prescriptions">
                    <div class="encounter-header">
                        <h3>Rencontre sur <?php echo date('F j, Y', strtotime($encounter_data['date'])); ?></h3>
                      <button class="print-encounter-prescriptions button" 
                                    data-encounter="<?php echo esc_attr($encounter_id); ?>">
                                    Imprimer
                            </button>
                    </div>
                
                    <div class="prescriptions-list">
                        <table class="prescription-table">
                            <thead>
                                <tr>
                                    <th>Médicament</th>
                                    <th>Dosage</th>
                                    <th>Frquence</th>
                                    <th>Durée</th>
                                    <th>Instructions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($encounter_data['prescriptions'] as $prescription): ?>
                                    <tr>
                                        <td><?php echo esc_html($prescription->medication_name); ?></td>
                                        <td><?php echo esc_html($prescription->dosage); ?></td>
                                        <td><?php echo esc_html($prescription->frequency); ?></td>
                                        <td><?php echo esc_html($prescription->duration); ?></td>
                                        <td><?php echo nl2br(esc_html($prescription->instructions)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach;
        else: ?>
            <p>Aucune ordonnance trouvée.</p>
        <?php endif; ?>
    </div>

    <!-- Ultrasounds Tab -->
    <div id="ultrasounds" class="tab-content <?php echo $current_tab === 'ultrasounds' ? 'active' : ''; ?>">
        <?php 
        // Group ultrasounds by encounter
        $ultrasounds_by_encounter = [];
        foreach ($encounters as $encounter) {
            $encounter_ultrasounds = $db->get_patient_ultrasounds($encounter->id);
            if (!empty($encounter_ultrasounds)) {
                $ultrasounds_by_encounter[$encounter->id] = [
                    'date' => $encounter->encounter_date,
                    'doctor' => $encounter->doctor_name,
                    'clinic' => $encounter->clinic_name,
                    'ultrasounds' => $encounter_ultrasounds
                ];
            }
        }
        
        if (!empty($ultrasounds_by_encounter)): 
            foreach ($ultrasounds_by_encounter as $encounter_id => $encounter_data): ?>
                <div class="encounter-ultrasounds">
                    <div class="encounter-header">
                        <h3>Rencontre du <?php echo date('j F Y', strtotime($encounter_data['date'])); ?></h3>
                        <button class="print-encounter-ultrasounds button" 
                                    data-encounter="<?php echo esc_attr($encounter_id); ?>">
                                    Imprimer
                            </button>
                    </div>
                    
                    <div class="ultrasounds-list">
                        <table class="ultrasound-table">
                            <thead>
                                <tr>
                                    <th>Type d'Examen Radiologique</th>
                                    <th>Date de demande</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($encounter_data['ultrasounds'] as $ultrasound): ?>
                                    <tr>
                                        <td><?php echo esc_html($ultrasound->ultrasound_name); ?></td>
                                        <td><?php echo date('j F Y', strtotime($ultrasound->created_at)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        
                    </div>
                </div>
            <?php endforeach;
        else: ?>
            <p>Aucune Examen Radiologique trouvée.</p>
        <?php endif; ?>
    </div>

    <!-- Analyses/Radio Tab -->
    <div id="analyse-radio" class="tab-content <?php echo $current_tab === 'analyse-radio' ? 'active' : ''; ?>">
        <?php 
        // Group analyses/radios by encounter
        $analyses_by_encounter = [];
        foreach ($encounters as $encounter) {
            $encounter_analyses = $db->get_patient_analyse_radio($encounter->id);
            if (!empty($encounter_analyses)) {
                $analyses_by_encounter[$encounter->id] = [
                    'date' => $encounter->encounter_date,
                    'doctor' => $encounter->doctor_name,
                    'clinic' => $encounter->clinic_name,
                    'analyses' => $encounter_analyses
                ];
            }
        }
        
        if (!empty($analyses_by_encounter)): 
            foreach ($analyses_by_encounter as $encounter_id => $encounter_data): ?>
                <div class="encounter-analyses">
                    <div class="encounter-header">
                        <h3>Rencontre du <?php echo date('j F Y', strtotime($encounter_data['date'])); ?></h3>
                         <button class="print-encounter-analyses button" 
                                    data-encounter="<?php echo esc_attr($encounter_id); ?>">
                                    Imprimer
                            </button>
                    </div>
                    
                    <div class="analyses-list">
                        <table class="analyse-radio-table">
                            <thead>
                                <tr>
                                    <th>Type d'Examen Biologique</th>
                                    <th>Date de demande</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($encounter_data['analyses'] as $analyse): ?>
                                    <tr>
                                        <td><?php echo esc_html($analyse->analyse_radio_name); ?></td>
                                        <td><?php echo date('j F Y', strtotime($analyse->created_at)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                       
                    </div>
                </div>
            <?php endforeach;
        else: ?>
            <p>Aucune Examen Biologique trouvée.</p>
        <?php endif; ?>
    </div>

    <!-- Documents Tab -->
    <div id="documents" class="tab-content <?php echo $current_tab === 'documents' ? 'active' : ''; ?>">
        <?php if (!empty($documents)): ?>
            <?php foreach ($documents as $document): ?>
                <div class="document-item">
                    <div class="document-info">
                        <h4><?php echo esc_html(ucfirst($document->document_type)); ?></h4>
                        <span class="date"><?php echo date('F j, Y', strtotime($document->created_at)); ?></span>
                    </div>
                    <div class="document-actions">
                        <button class="view-document button" data-id="<?php echo esc_attr($document->id); ?>">
                        Voir
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucun document trouvé.</p>
        <?php endif; ?>
    </div>

    <!-- Medical Reports Tab -->
    <div id="medical-reports" class="tab-content <?php echo $current_tab === 'medical-reports' ? 'active' : ''; ?>">
    <?php 
    $medical_reports = $db->get_medical_reports($patient_id);
    
    if (!empty($medical_reports)): ?>
        <div class="medical-reports-list">
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>Nom de fichier</th>
                        <th>Type</th>
                        <th>Date de télchargement</th>
                        <th>Téléchargé par</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($medical_reports as $report): ?>
                        <tr>
                            <td><?php echo esc_html($report->file_name); ?></td>
                            <td>
                                <span class="file-type <?php echo esc_attr(strtolower($report->file_type)); ?>">
                                    <?php echo esc_html(strtoupper($report->file_type)); ?>
                                </span>
                            </td>
                            <td><?php echo date('F j, Y', strtotime($report->created_at)); ?></td>
                            <td><?php echo esc_html($report->uploaded_by_name); ?></td>
                            <td>
                                <a href="<?php echo esc_url($report->file_path); ?>" 
                                   class="button download-report" 
                                   target="_blank" 
                                   download>
                                    <span class="dashicons dashicons-download"></span>
                                    Télécharger
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="no-reports-message">
            <p>Aucun rapport médical disponible pour ce patient.</p>
        </div>
    <?php endif; ?>
</div>

</div>

<?php
/*
Template Name: Patient View Template
*/

if (!defined('ABSPATH')) exit;

// Load header
get_header();

// Security check
if (!is_user_logged_in() || !current_user_can('edit_posts')) {
    wp_die('Access denied');
}

// Get parameters
$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
$encounter_id = isset($_GET['encounter_id']) ? intval($_GET['encounter_id']) : 0;

if (!$patient_id || !$encounter_id) {
    wp_die('Invalid parameters');
}

// Get database instance
$db = PD_Database::get_instance();

// Get specific encounter data
$encounter = $db->get_encounter_details($patient_id, $encounter_id);
if (!$encounter) {
    wp_die('Encounter not found or does not belong to this patient');
}

// Debug output
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Loading encounter view:');
    error_log('Patient ID: ' . $patient_id);
    error_log('Encounter ID: ' . $encounter_id);
    error_log('Encounter data: ' . print_r($encounter, true));
}

// Get required data
$patient = $db->get_patient_details($patient_id);

if (!$patient || !$encounter) {
    wp_die('Patient or encounter not found');
}

// Enqueue required scripts and styles
wp_enqueue_style('dashicons');
wp_enqueue_editor();
wp_enqueue_media();

// Add TinyMCE settings filter
add_filter('tiny_mce_before_init', function($settings) {
    $settings['content_css'] = PD_PLUGIN_URL . 'assets/css/editor-style.css';
    $settings['content_style'] = "
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            padding: 10px;
        }
    ";
    return $settings;
});

// Initialize pdData before enqueueing scripts
$pdData = array(
    'ajaxurl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('pd-nonce'),
    'patient_id' => $patient_id,
    'encounter_id' => $encounter_id,
    'patient_name' => $patient->display_name,
    'doctor_name' => $encounter->doctor_name,
    'encounter_date' => date('Y-m-d', strtotime($encounter->encounter_date)),
    'current_date' => date('Y-m-d'),
    'debug' => defined('WP_DEBUG') && WP_DEBUG
);

// Enqueue scripts in correct order
wp_register_script('pd-debug', 
    PD_PLUGIN_URL . 'assets/js/debug.js',
    array('jquery'),
    filemtime(PD_PLUGIN_PATH . 'assets/js/debug.js'),
    true
);

wp_register_script('pd-script', 
    PD_PLUGIN_URL . 'assets/js/script.js',
    array('jquery', 'tinymce', 'pd-debug'),
    filemtime(PD_PLUGIN_PATH . 'assets/js/script.js'),
    true
);

// Enqueue scripts
wp_enqueue_script('pd-debug');
wp_enqueue_script('pd-script');

// Localize script with data
wp_localize_script('pd-script', 'pdData', $pdData);

// Debug output if needed
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Patient View Data: ' . print_r($pdData, true));
}
?>

<div class="wrap">
    <div class="pd-patient-view-container">
        <?php 
        // Include the main template
        include PD_PLUGIN_PATH . 'includes/templates/patient-view.php';
        ?>
    </div>
</div>

<?php 
// Add script to verify pdData initialization
?>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    if (typeof window.pdData === 'undefined') {
        console.error('pdData not initialized!');
    } else {
        console.log('pdData initialized:', window.pdData);
    }
});
</script>

<?php
get_footer();
?>

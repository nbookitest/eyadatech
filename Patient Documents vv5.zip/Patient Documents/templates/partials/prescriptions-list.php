<?php if (!defined('ABSPATH')) exit; ?>

<h3>Prescriptions actuelles pour cette visite</h3>
<?php if(!empty($prescriptions)): ?>
    <table class="prescription-table">
        <thead>
            <tr>
                <th>Medication</th>
                <th>Dosage</th>
                <th>Fréquence</th>
                <th>Durée</th>
                <th>Instructions</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($prescriptions as $prescription): ?>
                <tr>
                    <td><?php echo esc_html($prescription->medication_name); ?></td>
                    <td><?php echo esc_html($prescription->dosage); ?></td>
                    <td><?php echo esc_html($prescription->frequency); ?></td>
                    <td><?php echo esc_html($prescription->duration); ?></td>
                    <td><?php echo esc_html($prescription->instructions); ?></td>
                    <td>
                        <button class="button delete-prescription" 
                                data-id="<?php echo esc_attr($prescription->id); ?>">
                                Supprimer
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <!-- Print All Button -->
    <div class="prescription-actions">
        <button class="button print-all-prescriptions" 
                data-encounter="<?php echo esc_attr($encounter_id); ?>">
                Imprimer
        </button>
    </div>
<?php else: ?>
    <p class="no-prescriptions">Aucune ordonnance n'a été ajoutée pour cette visite pour le moment.</p>
<?php endif; ?>

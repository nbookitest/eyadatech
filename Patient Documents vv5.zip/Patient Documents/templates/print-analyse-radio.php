<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>Demande d'Analyses et Radios</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <style>
    /* ---------------------
       Basic Resets
    ---------------------- */
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      line-height: 1.4;
      color: #333;
    }
    /* ---------------------
       A5 Page Setup for Print
    ---------------------- */
    @media print {
      @page {
        size: A5;
        margin: 5mm; /* Adjust margins as needed */
      }
    }
    /* ---------------------
       Container
    ---------------------- */
    .analyse-radio-request {
      width: 100%;
      position: relative;
      margin: 0 auto;
      text-transform: capitalize;
      font-size: 14px;
      display: flex;
      flex-direction: column;
      min-height: 100%;
    }
    /* ---------------------
       Header (Clinic Info)
    ---------------------- */
    header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      background: #fff;
      padding: 5px 0;
    }
    .header-left {
      width: 40%;
      padding-left: 5px;
    }
    .header-left h1 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
    }
    .header-left h3 {
      margin: 3px 0;
      font-size: 12px;
    }
    .header-left p {
      margin: 0;
      font-size: 8px;
    }
    .header-right {
      width: 48%;
      text-align: right;
      padding-right: 5px;
    }
    .header-right h1 {
      margin: 0;
      font-size: 17px;
      font-weight: 600;
    }
    .header-right h3 {
      margin: 3px 0;
      font-size: 14px;
    }
    .header-right p {
      margin: 0;
      font-size: 10px;
    }
    /* ---------------------
       Centered Block
       Contains:
         - Title
         - Date & Patient Info
         - Divider follows
    ---------------------- */
    .center-block {
      text-align: center;
      margin-top: 2px;
      z-index: 80;
    }
    .center-block .date {
      text-align: center;
      margin-top: 35px;
      margin-bottom: 10px;
    }
    .center-block h2 {
      margin: 0;
      font-size: 14px;
      font-weight: bold;
    }
    .center-block img {
      width: 50px;
      margin: 5px 0;
    }
    .date-patient {
      margin: 10px 0;
    }
    .date {
      margin: 0;
      font-size: 12px;
    }
    .patient-info {
      margin: 0;
      font-size: 16px;
      font-weight: bold;
    }
    .divider {
      margin: 5px auto;
      width: 95%;
      border: none;
      border-top: 1px solid #ccc;
    }
    /* ---------------------
       Analyse/Radio Items
    ---------------------- */
    .analyse-radio-items {
      flex: 1;
      margin: 5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 8px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background-color: #f5f5f5;
    }
    /* ---------------------
       Footer
    ---------------------- */
    footer {
      display: flex;
      justify-content: center;
      align-items: center;
      background: #fff;
      padding: 5px;
      position: relative;
      font-size: 11px;
    }
    .address {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 3px;
    }
    .address p {
      margin: 0;
      line-height: 1.3;
    }
    .contact-left {
      display: flex;
      gap: 10px;
      margin-top: 3px;
    }
    .contact-left p {
      margin: 0;
    }
    .contact-right {
      margin-right: 5px;
    }
    .qr-code {
      width: 50px;
    }
    /* ---------------------
       Print-Specific
       Fixed Header/Footer
    ---------------------- */
    @media print {
      header, footer {
        position: fixed;
        left: 0;
        right: 0;
        background: #fff;
      }
      header {
        top: 0;
      }
      footer {
        bottom: 0;
      }
      .analyse-radio-items {
        margin-top: 40px;  /* Reserve space for header */
        margin-bottom: 40px; /* Reserve space for footer */
      }
      table tr {
        page-break-inside: avoid;
      }
      .page-break {
        page-break-after: always;
      }
    }
  </style>
</head>
<body>
<?php
if (empty($analyse_radios) || empty($encounter)) {
    echo '<p>Aucune donnée disponible.</p>';
} else {
?>
  <div class="analyse-radio-request">
    <!-- Header -->
    <header>
      <div class="header-left">
        <h1>Dr. <?php echo esc_html($encounter->doctor_name ?? 'Nom du médecin non spécifié'); ?></h1>
        <h3>Médecin généraliste</h3>
        <p>Diplome d'etudes specialisees en gynecologie Médicale</p>
        <p>Suivie de Grossesse et infertilite de couple de l'Université de Bordeaux (France)</p>
        <p>Diplome d'echographie, ECG</p>
        <p>Suivi de diabete, Medecine esthetique</p>
        <p>Médecine agrée pour la visite médicale d'aptitude</p>
      </div>
      <div class="header-right">
        <h1>الدكتورة وداد الشمسي</h1>
        <h3>طبببة عامة</h3>
        <p>دبلوم الدراسات المتخصصة في طب النساء</p>
        <p>تتبع الحمل وعقم الزوجين من جامعة بوردو فرنسا</p>
        <p>دبلوم الفحص بالصدى، تخطيط القلب</p>
        <p>تتبع السكري، طب التجميل</p>
        <p>طبيبة معتمدة للفحص الطبي للقدرة على السياقة</p>
      </div>
    </header>
    <!-- Center Block -->
    <div class="center-block">
      <p>بسم الله الشافي</p>
      <img src="https://static.neopse.com/medias/p/996/site/6c/61/17/6c61172002f71961e7d773f4882267b56f0d70aa.png?v=v1" alt="Medical Logo" />
      <!-- Date and Patient Info -->
      <div class="date-patient">
        <p class="date">Date: <?php echo date('d/m/Y'); ?></p>
        <p class="patient-info">Patient: <?php echo esc_html($encounter->patient_name ?? 'Nom du patient non spécifié'); ?></p>
      </div>
    </div>
    <hr class="divider" />
    <!-- Analyse/Radio Items -->
   <div class="analyse-radio-items">
  <?php 
  $counter = 1;
  foreach ($analyse_radios as $ar): 
  ?>
    <div class="item">
      <span class="number"><?php echo esc_html($counter); ?>.</span>
      <div class="analyse-radio">
        <p><?php echo esc_html($ar->analyse_radio_name ?? 'Nom de l\'analyse/radio non spécifié'); ?></p>
      </div>
    </div>
    <?php $counter++; ?>
  <?php endforeach; ?>
</div>
    <!-- Footer -->
    <footer>
      <?php 
      global $wpdb;
      $clinic = $wpdb->get_row(
        $wpdb->prepare(
          "SELECT telephone_no, specialties FROM wp_kc_clinics WHERE id = %d",
          $encounter->clinic_id
        )
      );
      $specialties_labels = '';
      if ($clinic && !empty($clinic->specialties)) {
        $decoded_specialties = json_decode($clinic->specialties, true);
        if (is_array($decoded_specialties)) {
          $specialties_labels = array_column($decoded_specialties, 'label');
          $specialties_labels = implode(', ', $specialties_labels);
        }
      }
      ?>
      <div class="address">
      <p> الطابق الاول الشقة 12 عمارة ب، حي النصر ، اقامة الفتح - تمارة</p>
      <p><?php echo esc_html($encounter->clinic_address ?? 'Adresse non spécifiée'); ?></p>
        <div class="contact-left">
          <p>Tel: <?php echo esc_html($clinic->telephone_no ?? 'Numéro de téléphone non spécifié'); ?> :الهاتف</p>
        </div>
      </div>
      <div class="contact-right">
        <img src="https://drouidad.nbooki.com/wp-content/uploads/2025/03/Untitled-design-2.png" alt="QR Code" class="qr-code" />
      </div>
    </footer>
  </div>
<?php } ?>
</body>
</html>